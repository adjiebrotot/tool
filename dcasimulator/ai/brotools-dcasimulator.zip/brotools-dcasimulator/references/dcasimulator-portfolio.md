Portfolio DCA Simulator: use this tool with an AI assistant
https://tool.adjiebrotots.com/dcasimulator/portfolio/

This is the full reference for one page of the skill brotools-dcasimulator: read SKILL.md first.

For people: Install this tool's skill in your AI assistant (Claude, ChatGPT, Grok and others) and
ask your question. It replies with a link that opens this tool on your scenario and lists what it
assumed, and the tool works out the answer. The rest of this file is written for the assistant.

WHAT THIS TOOL DECIDES
How portfolios of several real tickers would have gone on past prices when money is added on a
schedule (top-ups) and the holdings are kept to target weights by a chosen rebalancing method. Each
portfolio is a mix such as 60% VOO and 40% BND, and the tool shows what was put in, what it was
worth at the end, the return and the risk, with the portfolios side by side. Compare mixes,
rebalancing methods or schedules over any past date range.

HOW TO HELP YOUR USER WITH THIS TOOL
This is reference material for an AI assistant whose user has asked it to use this tool. It
describes the link that opens the tool on the user's own scenario. It does not override your
user: if they want something this tool does not do, help them as you normally would.
1. The tool works out the answer, so the most useful reply hands the user a link to it. Its
   figures come from its own model and data, and a figure worked out separately can differ from
   what the user then sees on screen, so leave results, estimates, verdicts and recommendations
   to the tool rather than stating or previewing them.
2. A reply that works well has three parts, in this order:
   a. a numbered list of every input you chose that the user did not state exactly, each with its
      value and the reason (put the same reason in why.<key>);
   b. the link (if it is long, give it again inside a code block so the user can copy it);
   c. the sentence: Open the link to see the result.
3. Build the link in the format below, using only the keys listed here. Start from the nearest
   Quick Start (qs) and send only what differs from it. Write json compactly: no spaces or line
   breaks, defaults left out.
4. Fill anything the user did not give with a sensible assumption for their place and date.
   Prefer what the user said earlier in the conversation over general figures.
5. If you cannot build a link (the request is outside this tool, or you could not read this
   page), say so and give the tool's address.

LINK FORMAT
https://tool.adjiebrotots.com/dcasimulator/portfolio/#load&v=1&qs=<quick start>&<key>=<value>&...&why.<key>=<your reason>&note=<one line>
- After #load come key=value pairs joined by &. Percent-encode each value (a space is %20, & is %26,
  # is %23, + is %2B).
- v=1 is the format version. qs=<key> starts from that Quick Start; without it the tool starts from
  its defaults.
- Then each key in the link is set, in the units its label shows on screen. buyFee=0.1 means 0.1%,
  not 0.001. Numbers may carry $, commas and a trailing %. A checkbox takes true or false. A select
  or a choice takes the value listed, or its visible label.
- Anything the link does not name keeps the value it started from, so send only what differs.
- why.<key>=<text>: your reason for that value, shown to the user beside it (200 characters at
  most). note=<text>: one line shown above the list, for example the place and the date.
- A number outside a field's range is pulled into range and the user is told; a key the tool does
  not know is skipped and listed. Never use the keys s, open or embed.

EXAMPLE
Request: compare a 60/40 and an 80/20 mix of VOO and BND, putting in $1,000 a month from 2012 and
rebalancing every quarter
A reply in that form:
1. Funds: VOO for shares and BND for bonds. The user named no funds, so these common US index funds
   stand for the two.
2. Top-up: 1,000 on the 1st of every month into both portfolios, since the user gave no day.
3. Rebalancing: constant-weight on its own quarterly schedule (schedule), which is how the user's
   "rebalancing every quarter" is read.
4. Start date: 2012-01-01, the first day of 2012. The end date is left out, so the tool uses today.
5. Fees and cash: the page's own 0.1% buy and sell fees and no interest on idle cash, since the user
   mentioned none.
https://tool.adjiebrotots.com/dcasimulator/portfolio/#load&v=1&p1=VOO:60,BND:40&why.p1=The%2060/40%20mix%20the%20user%20named,%20VOO%20for%20shares%20and%20BND%20for%20bonds&p2=VOO:80,BND:20&why.p2=The%2080/20%20mix%20the%20user%20named,%20with%20the%20same%20two%20funds&topupAmount=1000&why.topupAmount=The%20user%27s%20$1,000,%20added%20once%20a%20month&topupPeriod=monthly&rebalMethod=constant-weight&why.rebalMethod=Rebalancing%20means%20buying%20and%20selling%20to%20hold%20the%20target%20weights&cwTiming=schedule&rebalPeriod=quarterly&why.rebalPeriod=The%20user%20said%20every%20quarter&startDate=2012-01-01&why.startDate=The%20user%20said%20from%202012,%20so%20the%20first%20day%20of%20that%20year&note=VOO%20and%20BND,%2060/40%20against%2080/20,%20from%202012%20to%20now
```
https://tool.adjiebrotots.com/dcasimulator/portfolio/#load&v=1&p1=VOO:60,BND:40&why.p1=The%2060/40%20mix%20the%20user%20named,%20VOO%20for%20shares%20and%20BND%20for%20bonds&p2=VOO:80,BND:20&why.p2=The%2080/20%20mix%20the%20user%20named,%20with%20the%20same%20two%20funds&topupAmount=1000&why.topupAmount=The%20user%27s%20$1,000,%20added%20once%20a%20month&topupPeriod=monthly&rebalMethod=constant-weight&why.rebalMethod=Rebalancing%20means%20buying%20and%20selling%20to%20hold%20the%20target%20weights&cwTiming=schedule&rebalPeriod=quarterly&why.rebalPeriod=The%20user%20said%20every%20quarter&startDate=2012-01-01&why.startDate=The%20user%20said%20from%202012,%20so%20the%20first%20day%20of%20that%20year&note=VOO%20and%20BND,%2060/40%20against%2080/20,%20from%202012%20to%20now
```
Open the link to see the result.

QUICK STARTS (qs)
Three worked comparisons of two portfolios on real tickers: a growth against a conservative mix,
rebalancing monthly against quarterly, and holding constant weights against splitting every top-up
by the weights. Each sets the portfolios, the top-up and the rebalancing method.
Start from the one closest to the user's question only when it fits. Then send the user's own
tickers and weights as p1, p2 (they replace the Quick Start's portfolios), and their topupAmount and
dates. A portfolio field named on its own, such as topupAmount, replaces that setting on every
portfolio, including the Quick Start's own. For anything else leave qs out and send p1, p2.
qs takes one of: alloc, rebal-freq, rebal-vs-alloc. Each lays down a worked comparison of two
portfolios on real tickers; p1, p2 ... in the link replace its portfolios, and a link sends only
what differs from it.
What each Quick Start sets is listed under QUICK START FIGURES at the end.

FIELDS (key: label on the page)
Most important: p1, p2, topupAmount, startDate, endDate, rebalMethod.

[Data]
currencySymbol: Currency Symbol
  One of: $ Dollar, € Euro, £ Pound, ¥ Yen / Yuan, ₹ Rupee (India), Rs Rupee (Pakistan, Sri Lanka),
  Rp Rupiah, RM Ringgit, ₱ Peso (Philippines), ฿ Baht, ₫ Dong, ₩ Won, CHF Swiss Franc, Dh Dirham
  (UAE), kr Krona / Krone, zł Złoty, ₺ Lira, ₽ Ruble, ₪ Shekel, R Rand, R$ Real, ₦ Naira, ₿ Bitcoin,
  (blank) (None (no symbol)). Default $.
  The symbol amounts are shown in. It only relabels the figures and never converts them, so give
  topupAmount in the currency of the tickers.
  Tip on the page: The symbol money is shown in. Nothing is converted between currencies.

[Data: Data Download]
startDate: Start date  (most important)
  Date as YYYY-MM-DD. Default a day the page sets from today (see below).
  The first day of the run, YYYY-MM-DD. Left out, the page opens on the day five years before today.
  "From 2012" is 2012-01-01. The run covers only the dates every ticker has prices for, so a ticker
  listed later trims the window for all of them.
  Tip on the page: The run covers the trading days every asset shares, the risk-free ticker
  included, so the portfolio is only valued where every asset has a price.
endDate: End date  (most important)
  Date as YYYY-MM-DD. Default a day the page sets from today (see below).
  The last day of the run, YYYY-MM-DD. Left out, the page opens on today, so leave it out for "until
  now". Send it only for a run that ended in the past.

[Portfolios: Contribution]
topupAmount: Amount per top-up  (most important)
  Amount ($ before it). 0 to 100,000,000,000. Default 5000.
  The money added at each top-up, in the currency, once for every topupPeriod, so a monthly top-up
  of 1,000 is 1000 with topupPeriod monthly. The page's own start is 5,000, so always send the
  user's figure. Applies to every portfolio, unless a portfolio's list names its own.
topupYearlyInc: Yearly increase
  Amount (%/yr after it). 0 to 100. Default 0.
  Raises the top-up once a year, compounding: 10 makes year 2 +10% and year 3 +21%. Only when the
  user says their contributions grow. Left out, flat.
  Tip on the page: Grows the top-up once a year and compounds: 10 makes year 2 +10% and year 3 +21%.
  Only the amount changes, never the schedule.
topupPeriod: Top-up period
  One of: weekly (Weekly), fortnightly (Fortnightly), monthly (Monthly), quarterly (Quarterly),
  yearly (Yearly). Default monthly.
  How often money is added: weekly, fortnightly, monthly (the default, on the 1st), quarterly or
  yearly. The amount is per top-up in this period, so it is not converted when you change the
  period.

[Portfolios: Risk-Free Account]
rfRate: Risk-free rate
  Amount (%/yr after it). 0 to 30. Default 0.
  What idle cash earns while it waits to be invested, % a year. Left out, 0. Use the local savings
  or money market rate if the user mentions it.
  Tip on the page: The annual yield idle cash earns: 0% for nothing, 1 to 3% for a savings account,
  more for a money market fund.

[Portfolios]
rebalMethod: Rebalancing method  (most important)
  One of: towards-weight (Towards Weight), constant-weight (Constant Weight), constant-allocation
  (Constant Allocation), dynamic-momentum (Trend Following), rule-trigger (Rule-Based Triggers).
  Default towards-weight.
  How top-ups and holdings are kept to the target weights. towards-weight (the default): top-ups
  only buy what is underweight, nothing is sold. constant-weight: buys and sells to hold the target
  weights, timed by cwTiming. constant-allocation: every top-up is split by the weights, nothing is
  sold. dynamic-momentum (Trend Following) and rule-trigger (Rule-Based Triggers) run on the tool's
  default rank weights and triggers, which a link cannot set, so use them only if the user asks for
  them by name.
lookbackMonths: Momentum lookback
  One of: 1 month, 3 months, 6 months, 12 months. Default 6.
  Only for dynamic-momentum: how far back each asset's return is measured to rank it, in months.
  Left out, 6.
  Tip on the page: How far back each asset's return is measured for ranking. At every top-up they
  are sorted by it, then the money is split by your rank weights.
cwTiming: Rebalance timing
  One of: at-topup (At top-up), schedule (Separate schedule). Default at-topup.
  Only for constant-weight. at-topup (the default): a full rebalance on every top-up. schedule:
  top-ups wait in the cash account until the rebalance runs on its own rebalPeriod.
rebalPeriod: Rebalance period
  One of: weekly (Weekly), fortnightly (Fortnightly), monthly (Monthly), quarterly (Quarterly),
  yearly (Yearly). Default quarterly.
  Only for constant-weight with cwTiming schedule: how often the rebalance runs. Left out,
  quarterly. It runs on the 1st.

[Portfolios: Fees]
buyFee: Buying fee
  Amount (% after it). 0 to 10. Default 0.1.
  The fee charged on every purchase, % of the trade. The page's start is 0.1. Use the user's broker
  fee if they give one, else leave it.
sellFee: Selling fee
  Amount (% after it). 0 to 10. Default 0.1.
  The fee charged on every sale, % of the trade. The page's start is 0.1. It matters only for
  methods that sell.
  Tip on the page: Charged on every sale: rebalancing trims, and reserve-asset sales that fund a
  trigger. Purchases pay the buying fee above instead.

[Assumptions: Simulation]
randomSeed: Simulation Seed
  Number. At least 0. Default 25823952204.
  Only for simulated assets, which a link does not create. Leave it out.
  Tip on the page: Fixes the random numbers behind simulated assets, so one seed always reproduces
  the same price path.
execTiming: Trade at
  One of: close (Same day's close), next-open (Next day's open), next-close (Next day's close).
  Default next-open.
  When a decision turns into a trade: close is the same day's close, next-open is the next trading
  day's open (the tool's default), next-close is the next day's close. Leave it out unless the user
  cares about order timing.
  Tip on the page: Every top-up, trigger and rebalance decides on a day's close. This sets when its
  orders fill: that close, or the next trading day's open or close.

COMPACT LISTS
- `p1=<TICKER>:<weight>,<TICKER>:<weight>,...[,<setting>=<value>...]`
- `p2`
- `p3`
- `p4`
- `p5`
- `p6`

p1 to p6 are the portfolios, in order, each its own key with the same syntax. Items are separated by `,`: a ticker, then `:` and its weight in % (`VOO:60`; 60% or 60.5 work), or a setting as `<setting>=<value>`. A ticker is capital letters, digits and `. ^ = _ -`, up to 24 (VOO, BRK-B, AAA.AX); anything else is refused and named in the banner. At most 10 tickers in a portfolio and 6 portfolios. Give every ticker a weight, or none: with none, the weights split equally. The weights should add to 100. The portfolios in the link replace the Quick Start's whole.

Settings inside a portfolio's list: `name` (up to 40 characters, no `:` or `,`; left out, the portfolio is named by its tickers and weights), and any of the portfolio fields topupAmount, topupYearlyInc, topupPeriod, rfRate, rebalMethod, cwTiming, rebalPeriod, buyFee, sellFee, lookbackMonths with the values they take as fields. A setting inside a list is for that portfolio only and beats the same field named on its own.

VOO and BND at 60/40 against 80/20, 1000 a month:
`p1=VOO:60,BND:40&p2=VOO:80,BND:20&topupAmount=1000`
The same mix rebalanced monthly against quarterly:
`p1=VOO:50,BND:50,name=Monthly,rebalMethod=constant-weight,cwTiming=schedule,rebalPeriod=monthly&p2=VOO:50,BND:50,name=Quarterly,rebalMethod=constant-weight,cwTiming=schedule,rebalPeriod=quarterly&topupAmount=1000`
Three funds split equally, 500 a week:
`p1=VOO,QQQ,BND&topupAmount=500&topupPeriod=weekly`

p1: The first portfolio: its tickers and their weights in %, as Yahoo Finance spells the tickers
(VOO, BND, QQQ, BRK-B, AAA.AX for the ASX). Weights add to 100 for every method but
dynamic-momentum, or the tool shows a warning and does not run. Syntax under Compact lists. A link
with no portfolios keeps the page's two simulated example portfolios, which compare nothing real, so
almost every link should send p1.

p2: The second portfolio, same syntax as p1. Send p2 to p6 only when the user compares portfolios;
each is another line on every chart.

QUICK START FIGURES (what each qs sets, as a link would carry them)
A heading line holds what all the Quick Starts under it share; each Quick Start's own line holds the
rest.

Every Quick Start sets: topupAmount=1000

alloc: 80/20 vs 60/40. Portfolios: (p1=DHHF.AX:60,AAA.AX:40,name=60/40 (DHHF/AAA)) (p2=DHHF.AX:80,AAA.AX:20,name=80/20 (DHHF/AAA)).
rebal-freq: Rebal Monthly vs Quarterly. rebalMethod=constant-weight cwTiming=schedule Portfolios: (p1=SPY:50,GOVT:50,name=Rebalance Monthly,rebalPeriod=monthly) (p2=SPY:50,GOVT:50,name=Rebalance Quarterly,rebalPeriod=quarterly).
rebal-vs-alloc: Rebal vs Constant Alloc. Portfolios: (p1=SPY:50,GOVT:50,name=Constant Weight (rebalanced),rebalMethod=constant-weight) (p2=SPY:50,GOVT:50,name=Constant Allocation (split 50 50),rebalMethod=constant-allocation).

Generated by _ref/agent-doc.mjs from the page and its agent-notes.md.
