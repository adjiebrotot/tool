DCA Scenario Explorer: use this tool with an AI assistant
https://tool.adjiebrotots.com/dcasimulator/

This is the full reference for one page of the skill brotools-dcasimulator: read SKILL.md first.

For people: Install this tool's skill in your AI assistant (Claude, ChatGPT, Grok and others) and
ask your question. It replies with a link that opens this tool on your scenario and lists what it
assumed, and the tool works out the answer. The rest of this file is written for the assistant.

WHAT THIS TOOL DECIDES
How a plan of regular purchases (dollar cost averaging) would have gone on past prices. Each
scenario is one real ticker bought on one schedule, such as $500 a month into SPY, and the tool
shows what was put in, what it was worth at the end, the return and the risk, with the scenarios
side by side. Compare tickers, schedules or buying rules over any past date range.

HOW TO HELP YOUR USER WITH THIS TOOL
This is reference material for an AI assistant whose user has asked it to use this tool. It
describes the link that opens the tool on the user's own scenario. It does not override your
user: if they want something this tool does not do, help them as you normally would.
1. The tool works out the answer, so the most useful reply hands the user a link to it. Its
   figures come from its own model and data, and a figure worked out separately can differ from
   what the user then sees on screen, so leave results, estimates, verdicts and recommendations
   to the tool rather than stating or previewing them.
2. A reply that works well has three parts, in this order:
   a. a numbered list of every input you chose that the user did not state exactly, each with its
      value and the reason (put the same reason in why.<key>);
   b. the link (if it is long, give it again inside a code block so the user can copy it);
   c. the sentence: Open the link to see the result.
3. Build the link in the format below, using only the keys listed here. Start from the nearest
   Quick Start (qs) and send only what differs from it. Write json compactly: no spaces or line
   breaks, defaults left out.
4. Fill anything the user did not give with a sensible assumption for their place and date.
   Prefer what the user said earlier in the conversation over general figures.
5. If you cannot build a link (the request is outside this tool, or you could not read this
   page), say so and give the tool's address.

LINK FORMAT
https://tool.adjiebrotots.com/dcasimulator/#load&v=1&qs=<quick start>&<key>=<value>&...&why.<key>=<your reason>&note=<one line>
- After #load come key=value pairs joined by &. Percent-encode each value (a space is %20, & is %26,
  # is %23, + is %2B).
- v=1 is the format version. qs=<key> starts from that Quick Start; without it the tool starts from
  its defaults.
- Then each key in the link is set, in the units its label shows on screen. riskFreeRate=4 means
  4%/yr, not 0.04. Numbers may carry $, commas and a trailing %. A checkbox takes true or false. A
  select or a choice takes the value listed, or its visible label.
- Anything the link does not name keeps the value it started from, so send only what differs.
- why.<key>=<text>: your reason for that value, shown to the user beside it (200 characters at
  most). note=<text>: one line shown above the list, for example the place and the date.
- A number outside a field's range is pulled into range and the user is told; a key the tool does
  not know is skipped and listed. Never use the keys s, open or embed.

EXAMPLE
Request: I want to put $500 a month into VOO and QQQ from 2015 to now; how would it have gone?
A reply in that form:
1. Tickers: VOO and QQQ, one scenario each, with the same plan, because the user named the two
   funds.
2. Schedule: 500 invested on the 1st of every month, the tool's default day, since the user gave no
   day.
3. Start date: 2015-01-01, the first day of 2015.
4. End date: left out, so the tool uses today, which is what "to now" means.
5. Currency: the default $, since both funds trade in US dollars.
https://tool.adjiebrotots.com/dcasimulator/#load&v=1&tickers=VOO,QQQ&why.tickers=The%20two%20funds%20the%20user%20named,%20each%20as%20its%20own%20scenario%20so%20they%20can%20be%20compared&amount=500&why.amount=The%20user%27s%20$500,%20invested%20once%20a%20month&startDate=2015-01-01&why.startDate=The%20user%20said%20from%202015,%20so%20the%20first%20day%20of%20that%20year&note=VOO%20and%20QQQ,%20monthly%20from%202015%20to%20now
```
https://tool.adjiebrotots.com/dcasimulator/#load&v=1&tickers=VOO,QQQ&why.tickers=The%20two%20funds%20the%20user%20named,%20each%20as%20its%20own%20scenario%20so%20they%20can%20be%20compared&amount=500&why.amount=The%20user%27s%20$500,%20invested%20once%20a%20month&startDate=2015-01-01&why.startDate=The%20user%20said%20from%202015,%20so%20the%20first%20day%20of%20that%20year&note=VOO%20and%20QQQ,%20monthly%20from%202015%20to%20now
```
Open the link to see the result.

QUICK STARTS (qs)
Three worked comparisons on real tickers: the same ticker bought monthly against weekly, an equity
ETF against a money market fund, and a single stock against an index ETF. Each sets only the
scenarios.
Start from the one closest to the user's question only when it fits (the same ticker on two
schedules, or two tickers on one schedule). Then send the user's own tickers, amount and dates.
tickers in the link replaces the Quick Start's scenarios; amount, yearlyIncrease, style, dayOrDate,
period and momentumPct replace that setting on every scenario, including the Quick Start's own. For
anything else leave qs out and send tickers.
qs takes one of: monthly-weekly, equity-mmf, stock-etf. Each lays down a worked comparison on real
tickers; tickers= and the plan keys in the link replace its scenarios, and a link sends only what
differs from it.
What each Quick Start sets is listed under QUICK START FIGURES at the end.

FIELDS (key: label on the page)
Most important: tickers, amount, startDate, endDate, style.

[Data]
currencySymbol: Currency Symbol
  One of: $ Dollar, € Euro, £ Pound, ¥ Yen / Yuan, ₹ Rupee (India), Rs Rupee (Pakistan, Sri Lanka),
  Rp Rupiah, RM Ringgit, ₱ Peso (Philippines), ฿ Baht, ₫ Dong, ₩ Won, CHF Swiss Franc, Dh Dirham
  (UAE), kr Krona / Krone, zł Złoty, ₺ Lira, ₽ Ruble, ₪ Shekel, R Rand, R$ Real, ₦ Naira, ₿ Bitcoin,
  (blank) (None (no symbol)). Default $.
  The symbol amounts are shown in. It only relabels the figures and never converts them, so give
  amount in the currency of the tickers (a US ticker in $, an ASX ticker in $ too, BBCA.JK in Rp).
  Tip on the page: The symbol money is shown in. Nothing is converted between currencies.

[Data: Data Download]
startDate: Start date  (most important)
  Date as YYYY-MM-DD. Default a day the page sets from today (see below).
  The first day of the run, YYYY-MM-DD. Left out, the page opens on the day five years before today.
  "From 2015" is 2015-01-01. The run covers only the dates every ticker has prices for, so a ticker
  listed later trims the window for all of them.
  Tip on the page: The run covers the dates every selected ticker shares, so a later starter trims
  the window for all of them and the comparison stays fair.
endDate: End date  (most important)
  Date as YYYY-MM-DD. Default a day the page sets from today (see below).
  The last day of the run, YYYY-MM-DD. Left out, the page opens on today, so leave it out for "until
  now". Send it only for a run that ended in the past.

[Assumptions: Simulation and metrics]
randomSeed: Simulation Seed
  Number. At least 0. Default 25823952204.
  Only for simulated assets, which a link does not create. Leave it out.
  Tip on the page: Fixes the random numbers behind simulated assets, so one seed always reproduces
  the same price path.
execTiming: Trade at
  One of: close (Same day's close), next-open (Next day's open), next-close (Next day's close).
  Default next-open.
  When a decision turns into a trade: close is the same day's close, next-open is the next trading
  day's open (the tool's default), next-close is the next day's close. Leave it out unless the user
  cares about order timing.
  Tip on the page: Every rule decides on a day's close. This sets when the order fills: that close,
  or the next trading day's open or close.
riskFreeRate: Risk-Free Rate
  Number (%/yr after it). 0 to 30, step 0.1. Default 4.
  The yearly return with no risk, % a year, used for the Sharpe and Sortino ratios only. Left out,
  4. Use the local cash or short-term bond rate if the user asks about risk-adjusted returns.
  Tip on the page: The yearly return you could earn without risk. Sharpe and Sortino measure the
  return earned above it.

COMPACT LISTS
- `tickers=<TICKER>[:<setting>=<value>...],<TICKER>[:<setting>=<value>...],...`
- `amount=<number>`
- `yearlyIncrease=<number>`
- `style=<name>`
- `dayOrDate=<number or weekday>`
- `period=monthly|weekly`
- `momentumPct=<number>`

tickers is the scenarios, one real ticker each, separated by `,`. A ticker is capital letters, digits and `. ^ = _ -`, up to 24 (SPY, BRK-B, ^GSPC, AAA.AX, EURUSD=X); anything else is refused and named in the banner. At most 6, and the first 6 are used. All scenarios share the plan keys amount, yearlyIncrease, style, dayOrDate, period and momentumPct when the link names them; a scenario takes its own value for any of them, and a `name`, by writing `:<setting>=<value>` after its ticker. A scenario left alone takes the tool's defaults: 500 a month on the 1st, no yearly increase, monthly-date. Two scenarios on the same ticker are named by their style unless you give a name; a name is up to 40 characters and may not contain `:` or `,`.

Settings in a ticker item: `amount`, `yearlyIncrease`, `style`, `dayOrDate`, `period`, `momentumPct`, `name`.

SPY bought monthly against weekly, with 520 a month and 120 a week:
`tickers=SPY:amount=520:style=monthly-date,SPY:amount=120:style=weekly-day`
VOO monthly against buying the dip, 500 each:
`tickers=VOO:style=monthly-date,VOO:style=momentum-dip:momentumPct=5&amount=500`
Two funds on the same plan, 750 a month, rising 5% a year:
`tickers=VOO,QQQ&amount=750&yearlyIncrease=5`

tickers: The real tickers to simulate, one scenario each, as Yahoo Finance spells them (SPY, VOO,
QQQ, BRK-B, BTC-USD, AAA.AX for the ASX, BBCA.JK for Jakarta). Use the ticker for the fund or stock
the user names, not its company name. Left out, the page keeps its two simulated example assets,
which compare nothing real, so almost every link should send tickers. Syntax under Compact lists.

amount: The money invested at each purchase, in the currency. It is per purchase, so for a weekly
style it is the weekly amount. Use the user's figure; if they give a yearly or monthly total for a
weekly style, divide it yourself and say so in why.

yearlyIncrease: Raises the amount once a year, compounding: 10 makes year 2 +10% and year 3 +21%.
Only when the user says their contributions grow. Left out, the amount stays flat.

style: How each purchase date is chosen, one of: monthly-date (the default, one fixed day a month),
weekly-day (one fixed weekday a week), momentum-peak (buy once the price has risen by momentumPct
from the period open), momentum-dip (buy once it has fallen by momentumPct), tech-ma-cross
(moving-average crossover), tech-rsi (RSI oversold), tech-bollinger (lower Bollinger Band),
tech-macd-cross (MACD crosses up), tech-macd-hist (MACD histogram turns positive), tech-adx (strong
trend only). The technical styles run on the tool's usual indicator settings. monthly-top,
monthly-bottom, weekly-top and weekly-bottom buy on the best or worst price day of the period; they
need hindsight and the tool marks them as demonstration only, so use them only when the user asks.
For a plain "invest every month" leave style out.

dayOrDate: For monthly-date, the day of the month, 1 to 31 (the tool buys on the trading day nearest
to it). For weekly-day, the weekday, 1 (Monday) to 7 (Sunday), or its name. Left out, 1.

period: For the momentum and technical styles only, how often at most they buy: monthly or weekly.
Left out, monthly.

momentumPct: For momentum-peak and momentum-dip only, the rise or dip in % from the period open that
triggers a purchase, 0.1 to 50. Left out, 5.

QUICK START FIGURES (what each qs sets, as a link would carry them)
A heading line holds what all the Quick Starts under it share; each Quick Start's own line holds the
rest.

monthly-weekly: Monthly vs Weekly. Scenarios: (tickers=SPY:amount=520:style=monthly-date:dayOrDate=1,SPY:amount=120:style=weekly-day:dayOrDate=1).
equity-mmf: Equity vs Money Market. Scenarios: (tickers=DHHF.AX:amount=500:style=monthly-date:dayOrDate=1,AAA.AX:amount=500:style=monthly-date:dayOrDate=1).
stock-etf: Stock vs ETF. Scenarios: (tickers=AAPL:amount=500:style=monthly-date:dayOrDate=1,SPY:amount=500:style=monthly-date:dayOrDate=1).

Generated by _ref/agent-doc.mjs from the page and its agent-notes.md.
