ED/UC Simulator: use this tool with an AI assistant
https://tool.adjiebrotots.com/ed-uc-simulator/

This is the full reference for one page of the skill brotools-ed-uc-simulator: read SKILL.md first.

For people: Install this tool's skill in your AI assistant (Claude, ChatGPT, Grok and others) and
ask your question. It replies with a link that opens this tool on your scenario and lists what it
assumed, and the tool works out the answer. The rest of this file is written for the assistant.

WHAT THIS TOOL DECIDES
How a power network is run over a stretch of hours at least cost: how much each generator, storage
unit and HVDC link produces or moves in every hour, which units are switched on (unit commitment),
what the operation costs, and the price of power at every bus (nodal prices), where a full line
splits them. It solves on a single-line diagram, in economic dispatch or unit commitment mode.

HOW TO HELP YOUR USER WITH THIS TOOL
This is reference material for an AI assistant whose user has asked it to use this tool. It
describes the link that opens the tool on the user's own scenario. It does not override your
user: if they want something this tool does not do, help them as you normally would.
1. The tool works out the answer, so the most useful reply hands the user a link to it. Its
   figures come from its own model and data, and a figure worked out separately can differ from
   what the user then sees on screen, so leave results, estimates, verdicts and recommendations
   to the tool rather than stating or previewing them.
2. A reply that works well has four parts, in this order, in the user's language:
   a. Your inputs: what the user stated, each with the value it takes in the link;
   b. Assumptions: every other input you chose, each with its value and its source (with its
      date) or your reason (put the same reason, shortened, in why.<key>);
   c. the link (if it is long, give it again inside a code block so the user can copy it);
   d. the sentence: Open the link to see the result.
3. Build the link in the format below, using only the keys listed here. Start from the nearest
   Quick Start (qs) and send only what differs from it. Write json compactly: no spaces or line
   breaks, defaults left out.
4. Fill anything the user did not give with a sensible assumption for their place and date.
   Prefer what the user said earlier in the conversation over general figures.
5. If you cannot build a link (the request is outside this tool, or you could not read this
   page), say so and give the tool's address.

LINK FORMAT
https://tool.adjiebrotots.com/ed-uc-simulator/#load&v=1&qs=<quick start>&<key>=<value>&...&why.<key>=<your reason>&note=<one line>
- After #load come key=value pairs joined by &. Percent-encode each value (a space is %20, & is %26,
  # is %23, + is %2B).
- v=1 is the format version. qs=<key> starts from that Quick Start; without it the tool starts from
  its defaults.
- Then each key in the link is set, in the units its label shows on screen. Write numbers plainly
  (800000, 6.5): a field also takes $, thousands commas and a trailing %, but inside a list a comma
  separates the items, so never put one in a number there. A checkbox takes true or false. A select
  or a choice takes the value listed, or its visible label.
- Anything the link does not name keeps the value it started from, so send only what differs.
- why.<key>=<text>: your reason for that value, shown to the user beside it (200 characters at
  most). note=<text>: one line shown above the list, for example the place and the date.
- A number outside a field's range is pulled into range and the user is told; a key the tool does
  not know is skipped and listed. Never use the keys s, open or embed.

EXAMPLE
Request: using tool.adjiebrotots.com/ed-uc-simulator, in the PJM 5-bus case, how do prices change if
the Brighton generator's cost rises to $40/MWh?
A reply in that form:
Your inputs:
- el.Brighton.marginal_cost: 40
Assumptions:
1. Network: the PJM 5-bus Quick Start (qs=pjm5), unchanged apart from the cost below.
2. Brighton: the generator at bus E. Its marginal cost is set to $40 per MWh
   (el.Brighton.marginal_cost); its rating and every other part stay as in the Quick Start.
3. Solve: the Quick Start's own: mode edm (edm is economic dispatch) over 1 d (d is days), with line
   limits and load shedding as the tool defaults them.
https://tool.adjiebrotots.com/ed-uc-simulator/#load&v=1&qs=pjm5&el.Brighton.marginal_cost=40&why.el.Brighton.marginal_cost=The%20user%27s%20new%20marginal%20cost%20for%20Brighton,%20in%20$%20per%20MWh&run=0&note=PJM%205-bus%20case,%20Brighton%27s%20marginal%20cost%20raised%20to%20$40/MWh
```
https://tool.adjiebrotots.com/ed-uc-simulator/#load&v=1&qs=pjm5&el.Brighton.marginal_cost=40&why.el.Brighton.marginal_cost=The%20user%27s%20new%20marginal%20cost%20for%20Brighton,%20in%20$%20per%20MWh&run=0&note=PJM%205-bus%20case,%20Brighton%27s%20marginal%20cost%20raised%20to%20$40/MWh
```
Open the link to see the result.

QUICK STARTS (qs)
There are four networks. pjm5 is the PJM 5-bus system from Li and Bo (2010): five buses, six lines,
five generators and three loads, solved as an economic dispatch over a day. uc3 is a coal unit, a
combined cycle and a peaker on one bus, solved as a unit commitment over a day. solar is a solar
farm, a battery and two gas units serving homes and shops, solved as a unit commitment over a day.
areas is a windy north and a gas-fired south joined by a 250 MW HVDC link, solved as a unit
commitment over three days.
Start from the one closest to the user's network, then change its parts by name with the
el.<name>.<param> keys. Their names, buses and ratings are under QUICK START FIGURES, so read the
part the user means from there: in pjm5 the generator at bus E is Brighton, at bus A are Alta and
Park City, at bus C Solitude and at bus D Sundance. A Quick Start also puts the options (edMode, the
horizon, edStart, the limits, edCur and the rest) back on their own values, so name each option the
user wants different. Without qs the tool starts from pjm5. A network that differs structurally,
with other buses, lines or devices, goes in json.
qs takes one of: pjm5, uc3, solar, areas.
What each Quick Start sets is listed under QUICK START FIGURES at the end.

FIELDS (key: label on the page)
Most important: edMode, edSpan, edSpanUnit, edStart, edLimits, edShed, edVoll, edCur.

[Dispatch]
edCur: Currency symbol  (most important)
  One of: $ Dollar, € Euro, £ Pound, ¥ Yen / Yuan, ₹ Rupee (India), Rs Rupee (Pakistan, Sri Lanka),
  Rp Rupiah, RM Ringgit, ₱ Peso (Philippines), ฿ Baht, ₫ Dong, ₩ Won, CHF Swiss Franc, Dh Dirham
  (UAE), kr Krona / Krone, zł Złoty, ₺ Lira, ₽ Ruble, ₪ Shekel, R Rand, R$ Real, ₦ Naira, ₿ Bitcoin.
  Default $.
  The currency symbol shown beside every cost and price. It only relabels the figures and never
  converts them, so give every cost in one currency and set its symbol here (Rp, the euro sign and
  so on). Every Quick Start puts it back on $.

[Dispatch: Problem]
edMode: Solve as  (most important)
  One of: uc (Unit commitment, mixed-integer), lin (Unit commitment, linear relaxation), edm
  (Economic dispatch), ed (Economic dispatch, no minimum output). Default edm.
  How the network is solved. uc: each committable unit is on or off in each hour, with its start-up
  costs, minimum output and up and down times (exact). lin: the same with on or off relaxed to a
  share from 0 to 1 (quick; its cost is a lower bound). edm: every unit is on in every hour, between
  its minimum stable loading and its rating, cheapest first, with no start-ups or up and down times.
  ed: economic dispatch with no minimum output, every unit anywhere from zero to its rating. Use edm
  for nodal prices and plain economic dispatch, and uc when the user asks about start-ups, unit
  commitment or minimum up and down times. pjm5 opens as edm and the other Quick Starts as uc.
  Tip on the page: Economic dispatch: every unit is on in every hour, between its minimum stable
  loading and its rating, cheapest first. No start-ups or up and down times.
edSpan: Horizon  (most important)
  Number. 1 to 30, step 1. Default 1.
  The length of the horizon, in the unit edSpanUnit sets: 1 to 30 days, or 1 to 720 hours. The hours
  are solved together, so storage and commitment carry over from one to the next. Days past 30 are
  pulled to 30 and reported.
  Tip on the page: Solved together in one-hour steps, up to 30 days. Storage and commitment carry
  over from one hour to the next.
edSpanUnit: Horizon (hours or days)  (most important)
  One of: h (hours), d (days). Default d.
  h for hours or d for days. The Quick Starts use days (a day, or three). Send edSpanUnit and edSpan
  together whenever the user's horizon is not in whole days, for example 36 hours is edSpan=36 with
  edSpanUnit=h.
edStart: First hour  (most important)
  Text. 1900-01-01T00:00 to 2200-12-31T23:00, step 3600. Default 2026-01-01T00:00.
  The first hour of the horizon, as YYYY-MM-DDTHH:00 (a whole hour), always with the time, for
  example 2026-06-01T00:00; a date with no time is not read and the first hour goes back to the
  default. The built-in demand shapes follow the weekday and are lower at the weekend, so it matters
  for a horizon that crosses one. The default is 2026-01-01T00:00, a Thursday. Leave it out unless
  the user gives a date.
  Tip on the page: When the horizon starts. Built-in demand profiles follow the weekday, lower at
  the weekend.

[Dispatch: Network]
edLimits: Line limits  (most important)
  Checkbox: true or false. Default true.
  On (the default): lines, transformers and links carry no more than their ratings, so a full one
  splits the price on either side. Off: no branch limit binds. Turn it off only when the user asks
  to ignore the limits.
  Tip on the page: Lines, transformers and links carry no more than their ratings. A full one splits
  the price on either side of it.

[Dispatch: Load shedding]
edShed: Allow load shedding  (most important)
  Checkbox: true or false. Default true.
  On (the default): load the units cannot reach is cut at the value of lost load instead of making
  the problem infeasible. Off: such a case is reported as a problem and not solved.
  Tip on the page: Load the units cannot reach is cut at the value of lost load instead of making
  the problem infeasible.
edVoll: Value of lost load (VoLL)  (most important)
  Number ($ before it, /MWh after it). 100 to 100,000, step 100. Default 10000.
  The value of lost load: what a MWh not served costs, per MWh in the currency of edCur. It caps the
  price, since shedding is the last resort. Used only while edShed is on. Typical 3,000 to 20,000
  (the default is 10,000). Leave it out unless the user gives one.
  Tip on the page: What a MWh not served costs. It caps the price, since shedding is always the last
  resort.

[Dispatch: Solver]
edGap: Optimality gap
  One of: 0.0001 (0.01%), 0.001 (0.1%), 0.01 (1%). Default 0.0001.
  Used only when edMode is uc. How close to the best possible cost the solver must prove its answer
  before it stops. 0.0001 is 0.01%, 0.001 is 0.1%, 0.01 is 1%. Leave it out.
  Tip on the page: HiGHS stops once its answer is proven within this share of the best possible
  cost.
edTime: Time limit
  One of: 10 s, 30 s, 60 s, 300 (5 min). Default 60.
  The solver's time limit, in seconds (10, 30, 60 or 300). Leave it out.

COMPACT LISTS
- `el.<name>.<param>=<value>`

Each key changes one parameter of one part of the network, found by the name the diagram shows for it (QUICK START FIGURES lists them). Names ignore case, spaces and underscores, so Park City, park city and ParkCity are one name; write it with %20 for the space or without it, as el.ParkCity.p_nom. Percent-encode any other awkward character in a name (# & + % /). The parameter is the text after the last dot. A name that no part has, or that two parts share, or a parameter the part does not take, is reported and skipped. A number outside the parameter's range is pulled into it and reported. A part with no name of its own is called by its automatic one (Generator 12, Load 7). Send one key per parameter, and a why.<key> beside each.

Parameters by kind of part, in the units the tool saves them in (the same as in json). A cost is per MWh, per start or per hour in the currency of edCur.

Bus parameters: v_nom (kV, 0.1 to 1500).

Line parameters: r (ohm, 0 to 100000), x (ohm, -100000 to 100000; a line needs a non-zero x) and s_nom (MW, 0 to 100000; 0 means no limit). A line with a standard type takes its impedance and rating from the type, so for it change length (km, 0 to 5000) and num_parallel (identical circuits, a whole number 1 to 20); the Quick Starts' lines have no type.

Transformer parameters: s_nom (MVA, 0 to 100000, above 0), x (per unit on s_nom, -10 to 10, not 0) and r (per unit on s_nom, 0 to 10).

Generator parameters: p_nom (MW, rating, 0 to 100000), marginal_cost (cost per MWh, -10000 to 100000), committable (1 or 0, or on or off: whether unit commitment may switch it off; read only in uc and lin), p_min_pu (minimum stable loading as a fraction of p_nom, 0 to 1, so 0.4 is 40%), start_up_cost and shut_down_cost (cost per start or stop, 0 to 100000000), stand_by_cost (cost per hour while on, 0 to 10000000), min_up_time and min_down_time (hours, whole numbers 0 to 168), ramp_limit_up and ramp_limit_down (the most it may move in an hour, as a fraction of p_nom, 0.01 to 1; 1 means no limit), init (1 if the unit was running before the first hour, else 0) and prof (its availability through the day: flat, or one of pv, pvs, pvw, pveq for solar, wnd for wind). The commitment values apply only to a committable unit.

Load parameters: p_set (MW, the peak demand, 0 to 100000) and prof (the shape through the day and the week: flat, or one of sys for a system day, res residential, com commercial, ind industrial, respv residential with rooftop solar, resev residential with electric cars).

Storage parameters: p_nom (MW, power rating, 0 to 100000), max_hours (hours of energy at full power, 0 to 1000), eff (round-trip efficiency as a fraction, 0.01 to 1, so 0.88 is 88%), soc0 (the starting charge as a fraction of its energy, 0 to 1; used when it is not cyclic) and cyclic (1 if it must end where it started, else 0).

Link parameters (an HVDC link): p_nom (MW, rating, 0 to 100000), efficiency (a fraction, 0.01 to 1, so 0.97 is 97%) and both (1 if it carries power either way, 0 for one way, from the first end).

A line type, a part's symbol, a cost curve, an uploaded hourly series, adding or removing parts and rewiring are not patches: send the network in json.

`run=0` opens the network without solving it: no result shows, Run dispatch stays lit and the reader presses it to see the answer. Always add it to a link for this tool, so the answer comes from the tool when the reader asks for it and never straight from the link. It holds for a Quick Start's pre-solved result too, so it works with or without el.<name>.<param> keys and json. Without it the network is solved as soon as the link opens.

JSON
`json=<network>` replaces the network with one of the user's own: the form the tool saves, which is how every Quick Start is written. Use it only for a network that differs structurally from the four Quick Starts (other buses, lines or devices); to change a value on one of them, patch it. A qs before it is replaced, but still sets the options, so pick the nearest one or send edMode and the horizon yourself. Write it compactly (no spaces or line breaks) and leave out every parameter that is at its default.

{"v":2,"name":"<title>","el":[<part>,<part>,...]}

Each part is {"c":<class>,"id":<whole number>, ...}. The class is Bus, Line, Transformer, Generator, Load, StorageUnit or Link. Every id is a different whole number, across all parts together. A name is only needed to override the automatic one (Bus 3, Load 7, Generator 4); the names el.<name>.<param> and the diagram use are these.
- A device (Generator, Load, StorageUnit) names its bus with "bus":<bus id>.
- A branch (Line, Transformer, Link) names both ends with "bus0":<bus id> and "bus1":<bus id>. One with a missing end is left out and reported.
- The other keys are the parameters listed under COMPACT LISTS, in the same units. A Bus needs "v_nom" in kV (its default is 1). Give every Line an "x" (and "s_nom" for a limit) and every Transformer an "s_nom" and "x". A Generator costs nothing and has no rating by default, so give "p_nom" and "marginal_cost"; "committable":1 with "p_min_pu", "start_up_cost" and the up and down times makes it a unit that edMode uc or lin commits. A Load needs "p_set" and usually "prof".
- Leave out "at" and the tool lays the buses out in rows from the first bus, with devices and branches placed automatically.
- Generator "style":"pv" or "wind" only draws the unit as solar or wind; its "prof" (pv, wnd) is what makes it follow the sun or the wind.
At least one bus is needed; the tool optimises up to 300 buses and 120 generators. An unknown class, a missing bus or a number out of range is reported or pulled into range, never a failure. A network that cannot be read at all leaves the tool on its Quick Start.
Two buses joined by a line, a gas unit and wind at the first and a town load at the second, solved as a unit commitment over a day (send edMode=uc with it):
{"v":2,"name":"Hub and town","el":[{"c":"Bus","id":1,"name":"Hub","v_nom":110},{"c":"Bus","id":2,"name":"Town","v_nom":110},{"c":"Line","id":3,"bus0":1,"bus1":2,"x":12,"s_nom":120},{"c":"Generator","id":4,"name":"Gas","bus":1,"p_nom":150,"marginal_cost":45,"committable":1,"p_min_pu":0.3,"start_up_cost":2000,"min_up_time":2},{"c":"Generator","id":5,"name":"Wind","bus":1,"p_nom":80,"prof":"wnd","style":"wind"},{"c":"Load","id":6,"name":"Town load","bus":2,"p_set":100,"prof":"res"}]}

QUICK START FIGURES (what each qs sets, as a link would carry them)
A heading line holds what all the Quick Starts under it share; each Quick Start's own line holds the
rest.

Every Quick Start sets: edSpanUnit=d

pjm5: PJM 5-bus. edMode=edm edSpan=1 Parts: Buses: A (230 kV), B (230 kV), C (230 kV), D (230 kV), E (230 kV).
    Lines: A-B (A to B, 400 MW), A-D (A to D, no limit), A-E (A to E, no limit), B-C (B to C, no limit), C-D (C to D, no limit), D-E (D to E, 240 MW).
    Generators: Alta (at A, 40 MW, 14 per MWh), Park City (at A, 170 MW, 15 per MWh), Solitude (at C, 520 MW, 30 per MWh), Sundance (at D, 200 MW, 40 per MWh), Brighton (at E, 600 MW, 10 per MWh).
    Loads: Load B (at B, peak 300 MW, system day), Load C (at C, peak 300 MW, system day), Load D (at D, peak 400 MW, system day).
uc3: Three units. edMode=uc edSpan=1 Parts: Buses: System (220 kV).
    Generators: Coal (at System, 380 MW, 28 per MWh, committable), Combined cycle (at System, 240 MW, 52 per MWh, committable), Peaker (at System, 120 MW, 115 per MWh, committable).
    Loads: Demand (at System, peak 640 MW, system day).
solar: Solar and battery. edMode=uc edSpan=1 Parts: Buses: Town (132 kV).
    Generators: Solar farm (at Town, 420 MW, 0 per MWh, solar (spring or autumn)), Gas turbine (at Town, 260 MW, 62 per MWh, committable), Peaker (at Town, 150 MW, 140 per MWh, committable).
    Loads: Homes (at Town, peak 300 MW, residential), Shops and offices (at Town, peak 180 MW, commercial).
    Storage: Battery (at Town, 100 MW, 4 h, efficiency 0.88).
areas: Two areas. edMode=uc edSpan=3 Parts: Buses: North (275 kV), South (275 kV).
    Generators: Wind farms (at North, 600 MW, 0 per MWh, wind), Hydro (at North, 150 MW, 18 per MWh), Combined cycle (at South, 350 MW, 55 per MWh, committable), Peakers (at South, 250 MW, 120 per MWh, committable).
    Loads: North load (at North, peak 220 MW, industrial), South load (at South, peak 620 MW, system day).
    Links: HVDC link (North to South, 250 MW, efficiency 0.97).

Generated by _ref/agent-doc.mjs from the page and its agent-notes.md.
