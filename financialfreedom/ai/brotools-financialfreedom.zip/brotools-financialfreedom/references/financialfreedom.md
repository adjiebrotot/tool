Financial Freedom Calculator: use this tool with an AI assistant
https://tool.adjiebrotots.com/financialfreedom/

This is the full reference for one page of the skill brotools-financialfreedom: read SKILL.md first.

For people: Install this tool's skill in your AI assistant (Claude, ChatGPT, Grok and others) and
ask your question. It replies with a link that opens this tool on your scenario and lists what it
assumed, and the tool works out the answer. The rest of this file is written for the assistant.

WHAT THIS TOOL DECIDES
The earliest age the user can stop work and still have the money last to their life expectancy (or
leave a set amount, or never touch the capital), given what they save, spend and hold, and how
likely the plan is to hold when returns vary.

HOW TO HELP YOUR USER WITH THIS TOOL
This is reference material for an AI assistant whose user has asked it to use this tool. It
describes the link that opens the tool on the user's own scenario. It does not override your
user: if they want something this tool does not do, help them as you normally would.
1. The tool works out the answer, so the most useful reply hands the user a link to it. Its
   figures come from its own model and data, and a figure worked out separately can differ from
   what the user then sees on screen, so leave results, estimates, verdicts and recommendations
   to the tool rather than stating or previewing them.
2. A reply that works well has three parts, in this order:
   a. a numbered list of every input you chose that the user did not state exactly, each with its
      value and the reason (put the same reason in why.<key>);
   b. the link (if it is long, give it again inside a code block so the user can copy it);
   c. the sentence: Open the link to see the result.
3. Build the link in the format below, using only the keys listed here. Start from the nearest
   Quick Start (qs) and send only what differs from it. Write json compactly: no spaces or line
   breaks, defaults left out.
4. Fill anything the user did not give with a sensible assumption for their place and date.
   Prefer what the user said earlier in the conversation over general figures.
5. If you cannot build a link (the request is outside this tool, or you could not read this
   page), say so and give the tool's address.

LINK FORMAT
https://tool.adjiebrotots.com/financialfreedom/#load&v=1&qs=<quick start>&<key>=<value>&...&why.<key>=<your reason>&note=<one line>
- After #load come key=value pairs joined by &. Percent-encode each value (a space is %20, & is %26,
  # is %23, + is %2B).
- v=1 is the format version. qs=<key> starts from that Quick Start; without it the tool starts from
  its defaults.
- Then each key in the link is set, in the units its label shows on screen. ret=8 means 8%/yr, not
  0.08. Numbers may carry $, commas and a trailing %. A checkbox takes true or false. A select or a
  choice takes the value listed, or its visible label.
- Anything the link does not name keeps the value it started from, so send only what differs.
- why.<key>=<text>: your reason for that value, shown to the user beside it (200 characters at
  most). note=<text>: one line shown above the list, for example the place and the date.
- A number outside a field's range is pulled into range and the user is told; a key the tool does
  not know is skipped and listed. Never use the keys s, open or embed.

EXAMPLE
Request: I'm 35 in Perth, I have $180k invested and save $3,000 a month; when can I retire?
A reply in that form:
1. Living expenses: 60,000 a year, a round figure for one person in Perth since the user did not say
   what they spend. It replaces the Moderate FIRE Quick Start's 65,000.
2. Savings: the 3,000 a month is an amount put aside, not pay, growing 3% a year as in the Quick
   Start.
3. Returns: the 180,000 invested earns 8.5% a year with 15% volatility (the global diversified share
   preset), before inflation and after fees.
4. From the Quick Start: life expectancy 90, inflation 2.5% a year, spending of 100% of living
   expenses once work stops, and the goal Just Die, with no stages and no pension. The retirement
   age is left for the tool to find.
https://tool.adjiebrotots.com/financialfreedom/#load&v=1&qs=moderate&ageNow=35&assets=180000&savings=3000&savingsPeriod=monthly&expense=60000&why.expense=The%20user%20did%20not%20say%20what%20they%20spend,%20so%20a%20round%20figure%20for%20one%20person%20living%20in%20Perth&note=Perth,%20October%202026,%20saving%203,000%20a%20month
```
https://tool.adjiebrotots.com/financialfreedom/#load&v=1&qs=moderate&ageNow=35&assets=180000&savings=3000&savingsPeriod=monthly&expense=60000&why.expense=The%20user%20did%20not%20say%20what%20they%20spend,%20so%20a%20round%20figure%20for%20one%20person%20living%20in%20Perth&note=Perth,%20October%202026,%20saving%203,000%20a%20month
```
Open the link to see the result.

QUICK STARTS (qs)
Six worked plans, each filling every tab: a 32-year-old saving from take-home pay, a lean saver at
28 on net income with stages for a hustle and a relax age and an age pension, earning in Australia
and retiring in Bali, a high earner under the Die Rich goal, a couple with two kids as life stages
who want to leave a legacy, and a 52-year-old with a pension.
Start from the one closest to the user, then send the user's own figures (usually ageNow, assets,
savings with savingsPeriod, expense) and any assumption you change. A Quick Start also sets the
switches and stages shown under Quick Start figures; send savingsMode, expenseMode or incomeMode to
change them. Frugal, fatfire and legacy count savings as take-home pay (savingsMode=income), so a
user who gives an amount saved needs savingsMode=savings. For a user none of them fits, leave qs out
and send every field that matters.
qs takes one of: moderate, frugal, geoarbitrage, fatfire, legacy, latestart. Each fills every tab
with a worked plan; a link sends only what differs from it.
What each Quick Start sets is listed under QUICK START FIGURES at the end.

FIELDS (key: label on the page)
Most important: ageNow, assets, savings, savingsPeriod, savingsMode, expense, expensePeriod,
currency, assetPreset, ret, std, inflation, ageDie, retireExpense, retireExpensePeriod, ffmode.

[You]
currency: Currency Symbol  (most important)
  One of: $ Dollar, € Euro, £ Pound, ¥ Yen / Yuan, ₹ Rupee (India), Rs Rupee (Pakistan, Sri Lanka),
  Rp Rupiah, RM Ringgit, ₱ Peso (Philippines), ฿ Baht, ₫ Dong, ₩ Won, CHF Swiss Franc, Dh Dirham
  (UAE), kr Krona / Krone, zł Złoty, ₺ Lira, ₽ Ruble, ₪ Shekel, R Rand, R$ Real, ₦ Naira, ₿ Bitcoin.
  Default $.
  The currency every amount on the page is in. It only relabels the figures and never converts them,
  so give every amount in this one currency, the local one for the place. Send the symbol, which is
  the option's value ($, €, £, Rp, RM, ¥, ₹ and so on from the list), not the name beside it. A code
  such as AUD is read as the symbol it stands for, but send the symbol. One symbol can stand for
  several currencies: $ is the Australian, US and Singapore dollar.
  Tip on the page: The symbol money is shown in. Nothing is converted between currencies.

[You: Ages]
ageNow: Age now  (most important)
  Number (yrs after it). 0 to 100, step 1. Default 30.
  The user's age today, in whole years.
ageDie: Life expectancy  (most important)
  Number (yrs after it). 2 to 120, step 1. Default 90.
  How long the money has to last, the life expectancy the plan is run to. Use the user's figure;
  otherwise 90, which most Quick Starts use (88 to 92). The Die Rich goal ignores it.
  Tip on the page: How long the money has to last. Die Rich ignores it.

[You: Money in]
savings: savings  (most important)
  Number ($ before it). 0 to 100,000,000,000. Default 30,000.
  Per the period in savingsPeriod, and what it is depends on savingsMode: the amount put aside each
  period, or the user's take-home pay. There is no tax model, so give pay after tax and returns
  after fees. Use the user's own figure.
  Tip on the page: The baseline. Before you stop work, any age no stage covers comes back to this,
  grown at its rate from today.
savingsPeriod: savingsPeriod (a week, a month or a year)  (most important)
  One of: weekly (a week), monthly (a month), yearly (a year). Default yearly.
  The period savings is per. Send it with savings whenever the user's figure is weekly or monthly.
growth: Growth of that amount
  Number (%/yr after it). -10 to 30, step 0.1. Default 3.
  How fast savings (or net income) grows each year, before inflation: pay rises. The Quick Starts
  use 2 to 3. At the inflation rate it holds its value in today's money; below it, it shrinks.
  Tip on the page: How fast the amount above grows each year, before inflation. Pay rises live here.
pensionOn: Government or age pension
  Checkbox: true or false. Default false.
  A government or age pension, counted as income from its start age. Turn it on only when the user
  has one or asks for one. It counts only while Money in is Simple (incomeMode); with Detailed, give
  the pension as an inStages item. The Late start Quick Start has one.
  Tip on the page: Income from its start age, so it reduces the pot you need from then on.
pensionStartAge: Pension starts at age
  Number (yrs after it). 40 to 90, step 1. Default 67.
  The age the pension starts, 40 to 90. The Late start Quick Start uses 67.
pensionAmount: Pension amount
  Number ($ before it). 0 to 100,000,000,000. Default 29,000.
  What the pension pays today, per the period in pensionPeriod. The Late start Quick Start uses
  about 29,000 a year, the Australian single full rate.
  Tip on the page: What it pays today. Counted as income from its start age.
pensionPeriod: Pension amount (a week, a month or a year)
  One of: weekly (a week), monthly (a month), yearly (a year). Default yearly.
  The period pensionAmount is per. Send it with pensionAmount whenever the user's figure is weekly
  or monthly.
pensionIndexed: Rises with inflation
  Checkbox: true or false. Default true.
  Whether the pension rises with inflation, so it holds its value. On for most government pensions.

[You: Money out]
expense: Living expenses  (most important)
  Number ($ before it). 0 to 100,000,000,000. Default 60,000.
  What the user spends to live now, in today's money, per the period in expensePeriod. Retirement
  spending is a share of it unless retireExpense is an amount. Use the user's figure; otherwise a
  typical spend for their place and household, and say so.
  Tip on the page: What you spend to live now, in today's money. Every % of living is a share of it.
expensePeriod: Living expenses (a week, a month or a year)  (most important)
  One of: weekly (a week), monthly (a month), yearly (a year). Default yearly.
  The period expense is per. Send it with expense whenever the user's figure is weekly or monthly.
retireExpense: Retirement expenses  (most important)
  Number ($ before it, % after it). 0 to 1,000. Default 100.
  What the user spends once work stops: a % of living expenses (retireExpensePeriod pct, the
  default; 100 is no change) or an amount per period in today's money. Leave it at the Quick Start's
  figure unless the user expects their spending to change. The Geoarbitrage Quick Start uses 40 for
  a cheaper country.
  Tip on the page: % of living: follows your living expenses, from the age you stop work. 80% if the
  mortgage is gone by then.
retireExpensePeriod: Retirement expenses (% of living, a week, a month or a year)  (most important)
  One of: pct (% of living), weekly (a week), monthly (a month), yearly (a year). Default pct.
  pct: retireExpense is a % of living expenses. weekly, monthly, yearly: it is an amount in today's
  money, not following the living expenses. Send it with retireExpense whenever the user gives an
  amount.

[Investment: What you hold]
assets: Invested assets today  (most important)
  Number ($ before it). 0 to 1,000,000,000,000. Default 100,000.
  What the user already holds that earns the return below: shares, funds, super or a 401(k),
  savings. Not the home they live in. Use the user's figure; 0 if they hold nothing.
  Tip on the page: What you already hold that earns the return below. Not the home you live in.

[Investment: Return assumptions]
assetPreset: Asset  (most important)
  One of: custom (Custom (enter your own)), cash (Cash / high-yield savings), bonds (Fixed income
  (government bonds)), us (Equity - United States), asx (Equity - Australia (ASX)), world (Equity -
  global diversified), gold (Gold). Default custom.
  Picks a long-run return and volatility from history. Sending a preset other than custom fills ret
  and std with its figures, unless the link also sends them. custom: send the user's own ret and
  std. cash, bonds, us, asx, world and gold are starting points; world, a global diversified share
  portfolio, is what most Quick Starts use.
ret: Expected return (CAGR)  (most important)
  Number (%/yr after it). -5 to 40, step 0.1. Default 8.
  The compound return the user expects, % a year, before inflation and after fees. Send it only with
  assetPreset=custom or to override a preset's figure.
  Tip on the page: The compound return you expect, before inflation and after fees.
std: Volatility  (most important)
  Number (%/yr after it). 0 to 80, step 0.1. Default 15.
  How much the return bounces from year to year, % a year. 0 draws one smooth projection. Send it
  only with assetPreset=custom or to override a preset's figure.
  Tip on the page: How much the return bounces year to year. Use 0 for a single smooth projection.

[Goal: Retirement goal]
ffmode: What should the money do?  (most important)
  One of: die (Just Die), legacy (Leave a Legacy), rich (Die Rich). Default die.
  The goal for the money. die: it runs out at life expectancy (Just Die). legacy: the amount in
  legacy is left at life expectancy (Leave a Legacy). rich: only real growth is ever spent, so the
  capital lasts for ever (Die Rich), the dearest goal. Use die unless the user wants to leave money
  behind or never touch the capital.
legacy: Amount to leave behind
  Number ($ before it). 0 to 1,000,000,000,000. Default 500,000.
  The amount to leave at life expectancy, in today's money. Used only with ffmode=legacy.
  Tip on the page: In today's money.

[Assumptions: Prices]
inflation: Inflation  (most important)
  Number (%/yr after it). 0 to 30, step 0.1. Default 2.5.
  Price rises, % a year. Use the local inflation target, 2 to 3 in most rich countries (the Quick
  Starts use 2.5, and 3 where costs rise faster).
  Tip on the page: Same life, bigger figure. While Show in today’s money, beside the results, is on,
  the page reads it in today’s money instead.

[Assumptions: Risk]
chance: Investment outcome chance
  Number (% after it). 50 to 99, step 1. Default 50.
  How cautious the Investment outcome line is: a balance reached or beaten in at least this share of
  futures. 50, the default, is the expected return. Leave it out unless the user asks for a more
  cautious projection.
  Tip on the page: The Investment outcome line is reached or beaten in at least this share of
  futures. 50% is the expected return; 90% is cautious.
confidence: Confidence level
  Number (% after it). 50 to 99, step 1. Default 90.
  The share of futures the confidence pot has to survive. Leave it out unless the user asks.
  Tip on the page: The share of futures the confidence pot has to survive.

[Beside the results]
showReal: Show in today's money
  Checkbox: true or false. Default true.
  Display only: true shows figures in today's money, false in the money of each year. Leave it out.
  Tip on the page: The plan is the same either way. On: every figure in today's money. Off: in the
  money of each year, as the account will read.
ageRetire: ageRetire
  Slider. 30 to 90. Default 47.
  The age the user stops work. Leave it out unless the user names an age to test. Left out, the tool
  opens on the earliest age the plan works, which is its answer, and that is not the Default printed
  here (the page's own start). Any whole age from ageNow to ageDie.

COMPACT LISTS
- `savingsMode=<savings|income>`
- `incomeMode=<simple|detailed>`
- `expenseMode=<simple|detailed>`
- `stages=<name>:<field>=<value>:<field>=<value>,<name>:...`
- `inStages=<name>:<field>=<value>:<field>=<value>,<name>:...`

savingsMode, incomeMode and expenseMode are not form fields: they are the page's switches. A value may also be the words the page shows (Net income, Detailed).

savingsMode: what savings is. savings (the default): the amount put aside each period. income: the user's take-home pay each period; the tool takes the living expenses off it to find the saving, so spending less also raises what is saved.

incomeMode: Simple is one savings or income figure with the pension fields. Detailed turns Money in into a list of stages by age (inStages), and the pension fields are then not used: give a pension as an inStages item with keeps=true. expenseMode: Simple is living expenses and retireExpense. Detailed turns Money out into a list of stages by age (stages). Sending a stages or inStages list switches its section to Detailed, and an empty list switches it back to Simple; send the switch yourself to override that. Simple keeps any rows it has but does not use them.

The two lists replace the Quick Start's rows whole. Items are separated by `,`, the name and each field by `:`, both typed as they are; a name may not contain `:`, `,` or `=` (leave them out). Each field is `<field>=<value>`, in any order. Numbers are plain (80, 29000), with no thousands separators. At most 12 items. List the stages in age order: they never overlap, and a start earlier than the stage above's end is moved up to it. A stage replaces the baseline for its ages, so it holds the whole figure for those years, not the difference.

Fields of both lists:
`from` and `to`: ages in years, 0 to 120. A blank or missing `from` begins where the stage above ended (at 0 for the first). A blank or missing `to` runs to life expectancy; 120 means for life.
`amount` (required): the figure for the stage, 0 or more, in today's money.

stages (Money out, with expenseMode detailed): spending during a stretch of life, such as kids at home. The baseline is the living expenses before work stops and the retirement expenses after, and a stage replaces it for its ages. Other field: `period`: pct (the default; `amount` is a % of living expenses, up to 1000), weekly, monthly or yearly (`amount` is that amount per period).
`stages=1st kid:from=34:to=36:amount=125,2nd kid:from=36:to=54:amount=150,1st kid leaves:from=54:to=56:amount=125`
`stages=Relax age:from=40:to=55:amount=4500:period=monthly`

inStages (Money in, with incomeMode detailed): a stretch of life that pays differently. The baseline is savings, grown at growth, and a stage replaces it for its ages; `amount` is in the same terms as savings (take-home pay when savingsMode=income). Other fields: `period`: weekly, monthly or yearly (the default). `growth`: how fast it grows, % a year before inflation, from today, -10 to 30 (default the growth field). `keeps`: true if it is still paid once the user stops work (a pension, rent, part-time work), false (the default) if it ends when work does.
`inStages=Part-time:from=45:to=55:amount=20000:keeps=true,Age pension:from=67:to=120:amount=29000:growth=2.5:keeps=true`

Switching a section to Detailed with no list (incomeMode=detailed alone) leaves its list as the Quick Start had it, empty for most.

QUICK START FIGURES (what each qs sets, as a link would carry them)
A heading line holds what all the Quick Starts under it share; each Quick Start's own line holds the
rest.

moderate: Moderate FIRE. ageNow=32 savings=45000 expense=65000 assets=120000 assetPreset=world ret=8.5
frugal: Frugal Living. ageNow=28 ageDie=92 savings=92000 growth=2.5 expense=30000 assets=40000 assetPreset=world ret=8.5 savingsMode=income incomeMode=detailed expenseMode=detailed Life stages: Money out (stages=Hustle age:from=28:to=33:amount=80:period=pct,Relax age:from=40:to=55:amount=120:period=pct); Money in (inStages=Hustle age:from=28:to=33:amount=105000:period=yearly:growth=4,Relax age:from=40:to=55:amount=20000:period=yearly:growth=2.5:keeps=true,Age pension:from=67:to=120:amount=29000:period=yearly:growth=2.5:keeps=true).
geoarbitrage: Geoarbitrage, Bali. ageNow=34 ageDie=88 savings=40000 expense=70000 retireExpense=40 assets=90000 assetPreset=world ret=8.5 inflation=3
fatfire: Fat FIRE, forever. ageNow=38 savings=320000 expense=120000 assets=400000 assetPreset=us ret=10 std=15.5 ffmode=rich savingsMode=income
legacy: Family legacy. ageNow=33 savings=150000 expense=70000 retireExpense=95 assets=150000 assetPreset=world ret=8.5 ffmode=legacy legacy=750000 savingsMode=income expenseMode=detailed Life stages: Money out (stages=1st kid:from=34:to=36:amount=125:period=pct,2nd kid:from=36:to=54:amount=150:period=pct,1st kid leaves:from=54:to=56:amount=125:period=pct).
latestart: Late start, on a pension. ageNow=52 ageDie=92 savings=25000 growth=2 pensionOn=true expense=55000 retireExpense=85 assets=180000 ret=6.5 std=10

Generated by _ref/agent-doc.mjs from the page and its agent-notes.md.
