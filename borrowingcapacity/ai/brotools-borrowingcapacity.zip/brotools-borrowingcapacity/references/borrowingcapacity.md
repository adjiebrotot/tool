Borrowing Capacity: use this tool with an AI assistant
https://tool.adjiebrotots.com/borrowingcapacity/

This is the full reference for one page of the skill brotools-borrowingcapacity: read SKILL.md first.

For people: Install this tool's skill in your AI assistant (Claude, ChatGPT, Grok and others) and
ask your question. It replies with a link that opens this tool on your scenario and lists what it
assumed, and the tool works out the answer. The rest of this file is written for the assistant.

WHAT THIS TOOL DECIDES
How much an Australian lender would lend for a home, from the applicants' income, household, debts
and the loan's rate and term, as the smallest of four limits (serviceability, debt to income, loan
to value and the deposit), which limit holds it down, and whether that covers the price entered.

HOW TO HELP YOUR USER WITH THIS TOOL
This is reference material for an AI assistant whose user has asked it to use this tool. It
describes the link that opens the tool on the user's own scenario. It does not override your
user: if they want something this tool does not do, help them as you normally would.
1. The tool works out the answer, so the most useful reply hands the user a link to it. Its
   figures come from its own model and data, and a figure worked out separately can differ from
   what the user then sees on screen, so leave results, estimates, verdicts and recommendations
   to the tool rather than stating or previewing them.
2. A reply that works well has three parts, in this order:
   a. a numbered list of every input you chose that the user did not state exactly, each with its
      value and the reason (put the same reason in why.<key>);
   b. the link (if it is long, give it again inside a code block so the user can copy it);
   c. the sentence: Open the link to see the result.
3. Build the link in the format below, using only the keys listed here. Start from the nearest
   Quick Start (qs) and send only what differs from it. Write json compactly: no spaces or line
   breaks, defaults left out.
4. Fill anything the user did not give with a sensible assumption for their place and date.
   Prefer what the user said earlier in the conversation over general figures.
5. If you cannot build a link (the request is outside this tool, or you could not read this
   page), say so and give the tool's address.

LINK FORMAT
https://tool.adjiebrotots.com/borrowingcapacity/#load&v=1&qs=<quick start>&<key>=<value>&...&why.<key>=<your reason>&note=<one line>
- After #load come key=value pairs joined by &. Percent-encode each value (a space is %20, & is %26,
  # is %23, + is %2B).
- v=1 is the format version. qs=<key> starts from that Quick Start; without it the tool starts from
  its defaults.
- Then each key in the link is set, in the units its label shows on screen. incSplit=50 means 50%,
  not 0.5. Numbers may carry $, commas and a trailing %. A checkbox takes true or false. A select or
  a choice takes the value listed, or its visible label.
- Anything the link does not name keeps the value it started from, so send only what differs.
- why.<key>=<text>: your reason for that value, shown to the user beside it (200 characters at
  most). note=<text>: one line shown above the list, for example the place and the date.
- A number outside a field's range is pulled into range and the user is told; a key the tool does
  not know is skipped and listed. Never use the keys s, open or embed.

EXAMPLE
Request: using tool.adjiebrotots.com/borrowingcapacity, how much can a couple earning $120,000 and
$85,000 in Sydney borrow?
A reply in that form:
1. Household: two applicants and no dependants. The link starts from the Couple Quick Start
   (qs=couple), which keeps private hospital cover on, no study loan, a card limit of 15,000, a loan
   at 5.9% a year over 30 years and the 2026-27 tax year.
2. Income: $205,000 a year gross between the two, with the second applicant's share set to 40%, the
   nearest step to $85,000 of $205,000.
3. Living costs: $4,000 a month declared; the lender uses the higher of this and its own benchmark.
4. Home and deposit: a $1,100,000 home with $250,000 saved, stamp duty at 4% of the price and $4,000
   of other purchase costs, none of which the user gave.
https://tool.adjiebrotots.com/borrowingcapacity/#load&v=1&qs=couple&city=Sydney&incSimple=205000&why.incSimple=$120,000%20plus%20$85,000%20gross%20a%20year,%20before%20tax&incSplit=40&why.incSplit=The%20second%20applicant%20earns%20$85,000,%20about%2041%25%20of%20$205,000,%20and%20the%20slider%20moves%20in%20steps%20of%205&deps=0&why.deps=No%20children%20were%20mentioned,%20and%20the%20Couple%20Quick%20Start%20has%20two&declaredExp=4000&why.declaredExp=A%20typical%20monthly%20figure%20for%20two%20adults%20with%20no%20children,%20excluding%20rent%20and%20debts&price=1100000&why.price=A%20typical%20Sydney%20price%20for%20a%20home%20a%20couple%20on%20this%20income%20might%20shop%20for&savings=250000&why.savings=Savings%20for%20the%20purchase%20were%20not%20given,%20so%20a%20typical%20amount%20for%20a%20couple%20at%20this%20income&dutyPct=4&why.dutyPct=New%20South%20Wales%20stamp%20duty%20on%20about%20$1.1M%20is%20about%204%25%20of%20the%20price&note=Sydney%20couple,%20October%202026
```
https://tool.adjiebrotots.com/borrowingcapacity/#load&v=1&qs=couple&city=Sydney&incSimple=205000&why.incSimple=$120,000%20plus%20$85,000%20gross%20a%20year,%20before%20tax&incSplit=40&why.incSplit=The%20second%20applicant%20earns%20$85,000,%20about%2041%25%20of%20$205,000,%20and%20the%20slider%20moves%20in%20steps%20of%205&deps=0&why.deps=No%20children%20were%20mentioned,%20and%20the%20Couple%20Quick%20Start%20has%20two&declaredExp=4000&why.declaredExp=A%20typical%20monthly%20figure%20for%20two%20adults%20with%20no%20children,%20excluding%20rent%20and%20debts&price=1100000&why.price=A%20typical%20Sydney%20price%20for%20a%20home%20a%20couple%20on%20this%20income%20might%20shop%20for&savings=250000&why.savings=Savings%20for%20the%20purchase%20were%20not%20given,%20so%20a%20typical%20amount%20for%20a%20couple%20at%20this%20income&dutyPct=4&why.dutyPct=New%20South%20Wales%20stamp%20duty%20on%20about%20$1.1M%20is%20about%204%25%20of%20the%20price&note=Sydney%20couple,%20October%202026
```
Open the link to see the result.

QUICK STARTS (qs)
There are 5 Quick Starts, each a named Australian borrower with their city, income, household,
debts, deposit and a home they would shop for. Each is opened as a full scenario, and the list below
shows only what it sets differently from the page's own start, so any key not listed keeps the
page's default.
Start from the one nearest the household: couple with children, a single average earner, a first
home buyer with a thin deposit, a self-employed borrower, or a high earner paid in several streams.
Then send the user's own figures: usually city, incSimple, incSplit, adults, deps, price, savings
and the debts they mention, plus any assumption you change. The Quick Starts' prices and savings are
examples, not the user's.
qs takes one of: finance-bro, couple, geoff, first-home, tradie.
What each Quick Start sets is listed under QUICK START FIGURES at the end.

FIELDS (key: label on the page)
Most important: incSimple, incSplit, adults, deps, city, declaredExp, price, savings, dutyPct,
cardLimit, persRepay, helpMode, prodRate, termYears.

[Income: What you earn]
incSimple: Total employment income  (most important)
  Number ($ before it, /yr after it). 0 to 100,000,000. Default 140,000.
  Gross income a year before tax, for all applicants together, excluding employer super. Add the
  applicants up ($120,000 and $85,000 is 205000). For a self-employed applicant it is the two-year
  average profit after tax plus add-backs. It counts while incMode is simple; the streams below
  count in Detailed.
  Tip on the page: Gross pay for the year, before tax and excluding employer super. Counted in full,
  as a lender treats base salary.

[Income: Employment]
incPayg: Base salary (PAYG)
  Number ($ before it, /yr after it). 0 to 100,000,000. Default 140,000.
  Employee base salary a year. Counts only in Detailed income.
  Tip on the page: Gross base salary before tax and excluding employer super. Counted in full by
  every lender.
shdPayg: Base salary (PAYG)
  Number (% after it). 0 to 100. Default 100.
  The share of the base salary the lender counts, %. 100 for salary.
incOvertime: Overtime
  Number ($ before it, /yr after it). 0 to 100,000,000. Default 0.
  Overtime a year (Employee, Detailed). Needs 6 to 12 months of history.
  Tip on the page: Needs 6 to 12 months of history. Shaded 80%, or 100% for essential services such
  as nursing, police, fire and ambulance.
shdOvertime: Overtime
  Number (% after it). 0 to 100. Default 80.
  The share of overtime the lender counts, %. Typically 80.
incBonus: Bonus or commission
  Number ($ before it, /yr after it). 0 to 100,000,000. Default 0.
  Bonus or commission a year (Employee, Detailed). Lenders shade it to 50 to 80%.
  Tip on the page: Lenders take the lower of the two year average and the latest year, then shade it
  to between 50% and 80%.
shdBonus: Bonus or commission
  Number (% after it). 0 to 100. Default 80.
  The share of a bonus the lender counts, %. 50 to 80.
incAllow: Allowances
  Number ($ before it, /yr after it). 0 to 100,000,000. Default 0.
  Non-reimbursable allowances a year (Employee, Detailed).
  Tip on the page: Car, shift, travel and site allowances. They must be non-reimbursable to count.
  Shaded 80% to 100%.
shdAllow: Allowances
  Number (% after it). 0 to 100. Default 80.
  The share of allowances the lender counts, %. 80 to 100.
incCasual: Casual or second job
  Number ($ before it, /yr after it). 0 to 100,000,000. Default 0.
  Casual or second job income a year (Employee, Detailed).
  Tip on the page: Needs 6 to 12 months in the same role. Shaded 80% to 100% depending on how
  settled the role looks.
shdCasual: Casual or second job
  Number (% after it). 0 to 100. Default 80.
  The share of casual income the lender counts, %. 80 to 100.

[Income: Self-employed]
incSeNpat: Two year average profit after tax (NPAT)
  Number ($ before it, /yr after it). 0 to 100,000,000. Default 0.
  Two-year average profit after tax (Self-employed, Detailed).
shdSe: Two year average profit after tax (NPAT)
  Number (% after it). 0 to 100. Default 100.
  The share of self-employed profit the lender counts, %. 100 for an established business.
incSeAdd: Add-backs
  Number ($ before it, /yr after it). 0 to 100,000,000. Default 0.
  Add-backs a year: depreciation, one-offs, director wages paid to you (Self-employed, Detailed).
  Tip on the page: Depreciation, one-off items, super above the compulsory rate, and director wages
  paid to you. Not a real cash drain, so they count. Shaded like NPAT, and not taxed.

[Income]
hasInvest: Rent, dividends or an investment property
  Checkbox: true or false. Default false.
  Tick if the household has rental income, dividends or an investment property. Its figures are
  ignored while it is off.
hasGov: Family Tax Benefit, pension or child support
  Checkbox: true or false. Default false.
  Tick for Family Tax Benefit, a pension or child support received. Its figures are ignored while it
  is off.

[Income: Investments]
incRent: Gross rental income
  Number ($ before it, /yr after it). 0 to 100,000,000. Default 0.
  Gross rental income a year. Send hasInvest with it. The shading in shdRent covers vacancy and
  costs, so do not deduct those.
  Tip on the page: Annual rent before costs. The 70% to 80% shading covers vacancy, fees, rates and
  strata, so do not deduct those yourself.
shdRent: Gross rental income
  Number (% after it). 0 to 100. Default 80.
  The share of rent the lender counts, %. 70 to 80.
ipCash: Investment property deductible costs
  Number ($ before it, /yr after it). 0 to 100,000,000. Default 0.
  Investment property deductible costs a year, for the tax only.
  Tip on the page: Interest, fees, rates, strata, insurance and repairs for the year. Used for the
  tax position only, never deducted from the rent twice.
ipDep: Depreciation (non-cash)
  Number ($ before it, /yr after it). 0 to 100,000,000. Default 0.
  Investment property depreciation a year (non-cash), for the tax only.
  Tip on the page: Claimed on the investment property. Lowers taxable income without costing cash,
  so it lifts the negative gearing benefit.
negGear: Allow negative gearing add-back
  Checkbox: true or false. Default true.
  Whether the lender adds the tax saved on a rental loss back. Leave it on.
  Tip on the page: Only some lenders add the tax saved on a rental loss back to servicing income.
  Turn it off for the conservative view.
incDiv: Dividends and distributions
  Number ($ before it, /yr after it). 0 to 100,000,000. Default 0.
  Cash dividends a year. Send hasInvest with it.
  Tip on the page: Cash received, two year average. Grossed up for franking credits, then shaded to
  80%.
shdDiv: Dividends and distributions
  Number (% after it). 0 to 100. Default 80.
  The share of dividends the lender counts, %. Typically 80.
frankPct: Franked portion
  Number (% after it). 0 to 100. Default 100.
  The franked share of the dividends, %. 100 for fully franked.
  Tip on the page: Share carrying franking credits at the 30% company rate. Fully franked grosses
  the cash up by 10 over 7.

[Income: Government and support]
incFtb: Family Tax Benefit A and B
  Number ($ before it, /yr after it). 0 to 100,000,000. Default 0.
  Family Tax Benefit A and B a year. Send hasGov with it.
  Tip on the page: Counted in full, but only while the youngest child stays under the lender's age
  limit of roughly 11 to 13 years.
shdFtb: Family Tax Benefit A and B
  Number (% after it). 0 to 100. Default 100.
  The share of Family Tax Benefit counted, %. 100.
incPension: Centrelink pension or DSP
  Number ($ before it, /yr after it). 0 to 100,000,000. Default 0.
  Centrelink pension or disability support a year. Send hasGov with it.
  Tip on the page: Age pension, disability support pension and carer payment. Counted in full.
shdPension: Centrelink pension or DSP
  Number (% after it). 0 to 100. Default 100.
  The share of the pension counted, %. 100.
pensionTaxable: Pension is taxable
  Checkbox: true or false. Default false.
  Whether the pension is taxable (age pension yes, disability support below pension age no).
  Tip on the page: Age pension is taxable, DSP below age pension age is not. Changes the tax line
  only, not the shading.
incCsIn: Child support received
  Number ($ before it, /yr after it). 0 to 100,000,000. Default 0.
  Child support received a year. Send hasGov with it.
  Tip on the page: Needs a court order or binding agreement plus 6 months of evidence. Tax free, so
  it is counted in full.
shdCsIn: Child support received
  Number (% after it). 0 to 100. Default 100.
  The share of child support received counted, %. 100.

[Household: Household and living costs]
city: City  (most important)
  One of: Sydney, Melbourne, Brisbane, Perth, Adelaide, Canberra, Hobart, Gold Coast, Regional or
  other. Default Perth.
  Sets the lender's living-cost benchmark (HEM) by local cost of living. Use the city nearest the
  home; Regional for other Australian places.
  Tip on the page: Scales the HEM benchmark by local cost of living excluding housing, taken from
  the Cost of Living Comparator. Perth is the base at 100.
adults: Adults in the household  (most important)
  One of: 1 applicant, 2 applicants. Default 2.
  How many people are on the loan, 1 or 2.
  Tip on the page: One or two people on the loan. Two applicants are taxed as two people, and HEM
  assumes a couple's living costs.
incSplit: Second applicant’s share of income  (most important)
  Slider (%). 0 to 50. Default 50.
  The second applicant's share of the household income, in %, 0 to 50 in steps of 5 (the slider
  lands on the nearest step). Used only with 2 adults; it changes the tax, since two applicants are
  two taxpayers. Send the lower earner's share: $85,000 of $205,000 is about 41, so 40. Send 0 when
  one applicant earns nearly all of it.
  Tip on the page: Two applicants are two taxpayers, so the tax scale runs on each share, not on the
  pooled income. Set 0% when one earns everything. The study loan is charged on the higher earner’s
  share.
deps: Dependants  (most important)
  One of: 0 (No dependants), 1 dependant, 2 dependants, 3 dependants, 4 dependants, 5 dependants, 6
  dependants. Default 0.
  Children or others who rely on the income, 0 to 6. Each one raises the living costs a lender
  assumes. Use what the user said; with no mention, 0.
  Tip on the page: Children or others who rely on your income. Each one raises the HEM living cost a
  lender assumes, and lowers the Medicare levy threshold.
declaredExp: Declared living expenses  (most important)
  Number ($ before it, /mo after it). 0 to 1,000,000. Default 3,500.
  The user's own living costs a month, excluding rent and every debt repayment. The lender uses the
  higher of this and its HEM benchmark, so a low figure does not raise the result. Typical 2,500 to
  5,500 by household; use a figure for the household if the user gives none.
  Tip on the page: Your own monthly figure, excluding rent, every debt repayment and investment
  outgoings. Those are counted under Debts.
privHealth: Private hospital cover
  Checkbox: true or false. Default true.
  Private hospital cover. false adds the Medicare Levy Surcharge once income passes the threshold.
  Leave it on unless the user says they have none.
  Tip on the page: Without it, the Medicare Levy Surcharge of 1% to 1.5% applies once income passes
  the singles or family threshold.

[Household: Tax and study loan]
taxYear: Resident tax year
  One of: 2025-26, 2026-27, 2027-28. Default 2026-27.
  The resident tax year whose lowest bracket applies. Use the year the user is applying in.
  Tip on the page: Sets the lowest bracket: 16% in 2025-26, 15% in 2026-27, 14% from 2027-28.
  Medicare thresholds use the latest published values.
helpMode: Study loan (HELP or HECS)  (most important)
  One of: tax (Deduct as tax), commitment (Treat as a commitment), none (No study loan). Default
  none.
  A study loan (HELP or HECS): none, tax (repayments come off as tax) or commitment (counted as a
  debt). Leave it at none unless the user has one.
  Tip on the page: The same dollars either way. As tax it lowers net income, as a commitment it
  lowers the NSR instead.
helpThreshold: Repayment threshold
  Number ($ before it, /yr after it). 0 to 1,000,000. Default 67,000.
  The income above which the study loan repays, a year. Used only when helpMode is not none; indexed
  yearly.
  Tip on the page: Only income above this line repays, at 15% to $125,000 and 17% above. Indexed
  yearly, so update it if yours differs.

[Debts]
hasHomeLoan: Another home or investment loan
  Checkbox: true or false. Default false.
  Tick for another home or investment loan. Its figures are ignored while it is off.
hasCard: Credit card or line of credit
  Checkbox: true or false. Default true.
  Tick for a credit card or line of credit. On by default. Its limit is ignored while it is off, so
  send false with no card.
hasPersonal: Personal or car loan
  Checkbox: true or false. Default false.
  Tick for a personal or car loan. Its figures are ignored while it is off.
hasBnpl: Buy now pay later
  Checkbox: true or false. Default false.
  Tick for buy now pay later. Its figures are ignored while it is off.
hasSupport: Child support or maintenance paid
  Checkbox: true or false. Default false.
  Tick for child support or maintenance paid. Its figure is ignored while it is off.
hasRefi: A facility closing or refinancing at settlement
  Checkbox: true or false. Default false.
  Tick for a facility closing or refinanced at settlement. Its figures are ignored while it is off.

[Debts: Other home and investment loans]
olBal: Total balance
  Number ($ before it). 0 to 1,000,000,000. Default 0.
  Total balance of the other home and investment loans. Send olRate with it.
olRate: Actual rate
  Number (%/yr after it). 0 to 30. Default 6.20.
  The rate paid today on those loans, % a year. The lender reassesses it at the higher of this plus
  the buffer and its floor.
  Tip on the page: The rate you pay today. The lender reassesses it at the higher of this plus 3.00%
  and its own floor.
olTerm: Remaining term
  Number (yrs after it). 1 to 40. Default 25.
  Years left on those loans. Shown in the Detailed debts view.
olType: Repayment type
  One of: pi (Principal and interest), io (Interest only). Default pi.
  pi (principal and interest) or io (interest only), for those loans. Shown in the Detailed debts
  view.
  Tip on the page: Interest only is reassessed as principal and interest over the term left after it
  ends, so the assessed repayment is larger.
olIo: Interest only period left
  Number (yrs after it). 0 to 15. Default 3.
  Years of interest only left. Used only when olType is io.

[Debts: Revolving credit]
cardLimit: Credit card and line of credit limits  (most important)
  Number ($ before it). 0 to 10,000,000. Default 10,000.
  The total limit of all credit cards and lines of credit, not the balance. A card never used still
  counts. Typical 5,000 to 25,000 for a household.
  Tip on the page: Assessed on the limit, not the balance. A card you never use still costs
  capacity, so closing it is the cheapest lift there is.
cardPct: Assessed monthly rate
  Slider (%). 3 to 3.8. Default 3.8.
  The monthly repayment charged on a card limit, % of the limit. Lenders use 3 to 3.8.

[Debts: Personal and car loans]
persRepay: Monthly repayments  (most important)
  Number ($ before it, /mo after it). 0 to 1,000,000. Default 0.
  Monthly repayments on personal and car loans. Send persBal with it.
persBal: Balances outstanding
  Number ($ before it). 0 to 1,000,000,000. Default 0.
  Total balance of personal and car loans. It feeds the debt-to-income limit only.

[Debts: Buy now pay later]
bnplRepay: Monthly instalments
  Number ($ before it, /mo after it). 0 to 1,000,000. Default 0.
  Monthly buy now pay later instalments. Send bnplLimit with it.
  Tip on the page: Or, where the lender assesses a limit rather than a balance, the limit divided by
  its assessment period.
bnplLimit: Total limits
  Number ($ before it). 0 to 1,000,000,000. Default 0.
  Total buy now pay later limits. It feeds the debt-to-income limit only.

[Debts: After settlement]
occupancy: Occupancy
  One of: owner (Owner occupier), investor (Investor, still renting or boarding). Default owner.
  owner (moves in) or investor (still pays rent or board after settlement, which counts as a
  commitment).
  Tip on the page: Investor if you keep renting or boarding after settlement. Owner occupiers move
  in, so the rent line falls away.
rentBoard: Rent or board paid after settlement
  Number ($ before it, /mo after it). 0 to 1,000,000. Default 0.
  Rent or board paid a month after settlement. Used only when occupancy is investor.
newPropCosts: Strata, rates and insurance on the new property
  Number ($ before it, /mo after it). 0 to 1,000,000. Default 350.
  Strata, rates and insurance a month on the new home. Typical 250 to 500 for a house, more for an
  apartment.
csOut: Child support or maintenance paid
  Number ($ before it, /mo after it). 0 to 1,000,000. Default 0.
  Child support or maintenance paid a month. Send hasSupport with it.
ipOut: Investment property outgoings not netted off rent
  Number ($ before it, /mo after it). 0 to 1,000,000. Default 0.
  Investment property outgoings a month that the rental shading does not already cover. Leave at 0
  if rent is shaded at 70 to 80.
  Tip on the page: Only what the rental shading misses. Leave it at zero if you shaded rent at 70%
  to 80%, or you pay the same cost twice.

[Debts: Closing at settlement]
refiRepay: Repayments being refinanced or closed
  Number ($ before it, /mo after it). 0 to 1,000,000. Default 0.
  Monthly repayments on a facility closed at settlement; they come off the commitments. Send refiBal
  with it.
  Tip on the page: Facilities paid out or closed at settlement. They come off commitments, and their
  balances off the DTI cap.
refiBal: Balances being refinanced or closed
  Number ($ before it). 0 to 1,000,000,000. Default 0.
  Balances of the facilities closed at settlement.

[Loan: The loan]
prodRate: Product rate offered  (most important)
  Number (%/yr after it). 0 to 30. Default 5.90.
  The interest rate the user would be offered on the new loan, % a year. The lender tests at the
  higher of this plus buffer and its floor rate, so the tested rate is higher than this one. Use the
  user's offered rate; otherwise a going variable owner-occupier rate for the date.
termYears: Loan term  (most important)
  Number (yrs after it). 1 to 40. Default 30.
  Years the new loan runs. Typical 30.
hasIo: Interest only to start
  Checkbox: true or false. Default false.
  Interest only to start. On shortens the term the lender tests over by newIo years.
  Tip on the page: Shortens the window you are tested over to the term minus the interest only
  period, so capacity drops materially.
newIo: Interest only period
  Number (yrs after it). 0 to 15. Default 5.
  Years of interest only on the new loan. Used only with hasIo on.

[Loan: Lender policy]
buffer: APRA buffer
  Slider (%). 0 to 5. Default 3.
  The serviceability buffer the lender adds to the rate, in percentage points. 3 is the APRA rule;
  leave it unless the user names a lender's policy.
  Tip on the page: Added on top of the product rate by APRA rule. It has been 3.00 points since
  October 2021.
floorRate: Lender floor
  Slider (%). 0 to 9. Default 5.5.
  The lender's minimum test rate, % a year. Typical 5 to 5.75; leave it unless the user names a
  lender's policy.
  Tip on the page: A minimum assessment rate the lender never goes below, typically 5.00% to 5.75%.
  The higher of floor and buffered rate is used.
umiReq: Minimum left each month (UMI)
  Number ($ before it, /mo after it). 0 to 100,000. Default 250.
  The monthly surplus the lender insists on after everything. Typical 0 to 500.
  Tip on the page: The buffer the lender insists you keep after every outgoing, including the new
  repayment. Usually $0 to $500 a month.
nsrMin: Minimum income cover (NSR)
  Slider (×). 1 to 1.2. Default 1.
  The minimum income cover (net service ratio), 1 to 1.2. Typical 1 to 1.1.
  Tip on the page: It must clear 1.00, and some lenders want 1.05 to 1.10. This is the secondary
  sanity check, UMI is the primary test.

[Purchase: The purchase]
price: Purchase price  (most important)
  Number ($ before it). 0 to 1,000,000,000. Default 900,000.
  The price of the home. Use the user's price; otherwise a typical price for the kind of home and
  the city, which the borrower would shop for.
valuation: Bank valuation
  Number ($ before it). 0 to 1,000,000,000. Default 900,000.
  What the bank values the home at. The lower of price and valuation sets the loan to value limit.
  Used only in the Detailed purchase view; the Simple view uses the price.
  Tip on the page: The LVR cap applies to the lower of price and valuation, so a shortfall costs you
  directly.
depositMode: Deposit funds (Enter an amount or Percentage of price)
  One of: amount (Enter an amount), pct (Percentage of price). Default amount.
  amount: savings is all the cash the user has for the purchase, and stamp duty and other costs come
  out of it first. pct: depositPct is the deposit as a % of the price, with the costs paid on top.
  Send it with savings or depositPct.
  Tip on the page: Savings, a family gift and any grant. Stamp duty and the purchase costs come out
  of it first.
savings: Deposit funds  (most important)
  Number ($ before it). 0 to 1,000,000,000. Default 200,000.
  Used when depositMode is amount. Savings, a family gift and any grant.
depositPct: Deposit funds
  Number (% of price after it). 0 to 100. Default 20.
  Used when depositMode is pct.
dutyMode: Stamp duty (Percentage of price or Enter an amount)
  One of: pct (Percentage of price), amount (Enter an amount). Default pct.
  pct: dutyPct is a % of the price. amount: dutyAmt is the dollar duty. Send it with dutyPct or
  dutyAmt.
  Tip on the page: Rates and concessions differ by state. Check your revenue office, or use
  percentage mode for a quick estimate.
dutyPct: Stamp duty  (most important)
  Number (% of price after it). 0 to 20. Default 4.00.
  Stamp duty as a % of the price, for the state and price. About 4 to 5.5 in NSW and Victoria for a
  $0.9M to $1.4M home, 3.5 to 4 in WA and Queensland, 4.5 to 4.8 in South Australia. Each Quick
  Start holds its state's figure. First home buyer concessions can make it 0.
dutyAmt: Stamp duty
  Number ($ before it). 0 to 1,000,000,000. Default 36,000.
  Used when dutyMode is amount.
otherCosts: Other purchase costs
  Number ($ before it). 0 to 1,000,000,000. Default 4,000.
  Conveyancing, transfer and registration, building and pest. About 4,000 on a standard purchase.
  Tip on the page: Conveyancing, transfer and registration, building and pest. Around $4,000 on a
  standard purchase.

[Purchase: Loan to value]
lmiCap: Lenders Mortgage Insurance
  Checkbox: true or false. Default false.
  Lenders Mortgage Insurance. On lets the loan go past 80% of the price, up to 95%, with the premium
  added to the loan. Needed when the deposit is under 20% of the price.
  Tip on the page: Lets a lender go past 80% LVR, up to 95%. The premium is capitalised, so you
  service the larger balance and serviceability tightens.
lmiRate: LMI premium
  Number (% of loan after it). 0 to 10. Default 2.50.
  The premium as a % of the loan. Used only with lmiCap on.
lvrMax: Maximum LVR
  Slider (%). 50 to 95. Default 80.
  The most the lender lends as a % of the home's value. 80 avoids LMI; up to 95 with it. Used only
  in the Detailed purchase view; the Simple view uses 80, or 95 with lmiCap on.
  Tip on the page: 80% avoids LMI. 85% is waived for some professions such as doctors and lawyers.
  90% to 95% is possible with LMI.

[Purchase: Debt to income]
dtiCap: DTI cap
  Slider (×). 3 to 9. Default 6.
  The most the lender allows in total debt as a multiple of gross income. 6 is the reporting line;
  strict lenders use 4.5 to 5.5. Shown in the Detailed purchase view.
  Tip on the page: Many lenders cut this well below the 6.0 reporting line, to 4.5 or 5.5, once the
  LVR is high.
dtiBasis: Income basis
  One of: gross (Gross income, unshaded), assessable (Assessable income, shaded). Default gross.
  gross (raw income) or assessable (the shaded income, which is stricter).
  Tip on the page: Some lenders measure DTI on raw gross income, others on the shaded assessable
  figure, which is stricter.

COMPACT LISTS
- `incMode=<simple|detailed>`
- `incWho=<employee|self>`
- `debtsMode=<simple|detailed>`
- `loanMode=<simple|detailed>`
- `capsMode=<simple|detailed>`

These five are not form fields: they are the page's Simple / Detailed switches and its Employee / Self-employed switch. A value may also be the words the page shows (Detailed, Self-employed). You rarely need to send them, because a link that names a figure which only counts in one view switches that view on by itself. The key you send always wins.

incMode: simple counts incSimple, in full. detailed counts the streams instead, each shaded by its own shd key: incPayg, incOvertime, incBonus, incAllow, incCasual (employee) or incSeNpat, incSeAdd (self-employed), and incSimple is not used. Naming any stream, shading or investment figure that is shown in Detailed (incPayg, incBonus, shdBonus, shdRent, ipCash and the like) switches Income to Detailed; naming incSimple alone switches it to Simple. When the link switches Income to Detailed and does not name the base salary (incPayg, or incSeNpat for self-employed), the base salary becomes what is left of incSimple after the other streams you named, as the Detailed button does. So in Detailed, send incPayg or incSeNpat as well.
`incMode=detailed&incPayg=100000&incBonus=20000`

incWho: employee or self. Only one side counts at a time. Naming a self-employed stream (incSeNpat, incSeAdd, shdSe) selects self; naming an employee stream selects employee. In Simple it changes only the wording on the page, not the result.

debtsMode and loanMode: change only which controls the page shows, never the result; a value in a hidden control still counts. Naming olTerm, olType, olIo, cardPct or ipOut shows the Detailed debts view; naming buffer, floorRate, umiReq or nsrMin shows the Detailed loan view.

capsMode: simple sets the loan to value limit to 80 (95 with lmiCap on) and values the home at the price. detailed uses lvrMax and valuation, and shows dtiCap and dtiBasis. Naming any of lvrMax, valuation, dtiCap or dtiBasis switches Purchase to Detailed; whichever of lvrMax and valuation you leave out then takes what Simple was using (95 or 80, and the price).

The boxes under "Tick what you have" (hasInvest, hasGov, hasHomeLoan, hasCard, hasPersonal, hasBnpl, hasSupport, hasRefi) and the two switches hasIo and lmiCap hide and zero what is under them while they are off. Send the box with its figures. As a safety net, a link that names a non-zero figure under an off box and does not name the box turns it on.
`hasPersonal=true&persRepay=950&persBal=42000`

QUICK START FIGURES (what each qs sets, as a link would carry them)
A heading line holds what all the Quick Starts under it share; each Quick Start's own line holds the
rest.

finance-bro: Finance Bro, Sydney. incPayg=230000 incBonus=90000 city=Sydney adults=1 declaredExp=5200 hasPersonal=true cardLimit=25000 persRepay=950 persBal=42000 newPropCosts=900 price=1350000 savings=550000 dutyPct=4.24 incMode=detailed debtsMode=detailed
couple: Couple, Melbourne. incSimple=185000 city=Melbourne deps=2 declaredExp=4800 cardLimit=15000 newPropCosts=450 price=920000 savings=300000 dutyPct=5.46
geoff: Average Man, Perth. incSimple=110000 adults=1 declaredExp=2800 cardLimit=8000 price=560000 savings=180000 dutyPct=3.68
first-home: First home buyer, Brisbane. incSimple=120000 city=Brisbane adults=1 declaredExp=2600 helpMode=tax cardLimit=5000 newPropCosts=400 price=480000 savings=70000 dutyPct=0 lmiCap=true
tradie: Self-employed tradie, Adelaide. incSimple=165000 city=Adelaide adults=1 deps=1 declaredExp=3200 hasPersonal=true cardLimit=20000 persRepay=950 persBal=48000 newPropCosts=380 price=780000 savings=300000 dutyPct=4.71 incWho=self

Generated by _ref/agent-doc.mjs from the page and its agent-notes.md.
