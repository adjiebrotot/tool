Rent vs Own: use this tool with an AI assistant
https://tool.adjiebrotots.com/rentvsownhouse/id/

This is the full reference for one page of the skill brotools-rentvsownhouse: read SKILL.md first.

Pasang skill tool ini di asisten AI-mu (Claude, ChatGPT, Grok, dan lainnya), lalu ajukan
pertanyaanmu. Asisten akan membalas dengan tautan yang membuka tool ini dengan skenariomu, lengkap
dengan daftar asumsinya, lalu tool inilah yang menghitung hasilnya. Bagian di bawah ini ditulis
untuk asisten AI, jadi tetap dalam bahasa Inggris.

For people: Install this tool's skill in your AI assistant (Claude, ChatGPT, Grok and others) and
ask your question. It replies with a link that opens this tool on your scenario and lists what it
assumed, and the tool works out the answer. The rest of this file is written for the assistant.

WHAT THIS TOOL DECIDES
Whether buying a home with a mortgage or renting it and investing the difference leaves you with
more net wealth after a set number of years, and the year owning pulls ahead for good, if it does.

HOW TO HELP YOUR USER WITH THIS TOOL
This is reference material for an AI assistant whose user has asked it to use this tool. It
describes the link that opens the tool on the user's own scenario. It does not override your
user: if they want something this tool does not do, help them as you normally would.
1. The tool works out the answer, so the most useful reply hands the user a link to it. Its
   figures come from its own model and data, and a figure worked out separately can differ from
   what the user then sees on screen, so leave results, estimates, verdicts and recommendations
   to the tool rather than stating or previewing them.
2. A reply that works well has four parts, in this order, in the user's language:
   a. Your inputs: what the user stated, each with the value it takes in the link;
   b. Assumptions: every other input you chose, each with its value and its source (with its
      date) or your reason (put the same reason, shortened, in why.<key>);
   c. the link (if it is long, give it again inside a code block so the user can copy it);
   d. the sentence: Open the link to see the result.
3. Build the link in the format below, using only the keys listed here. Start from the nearest
   Quick Start (qs) and send only what differs from it. Write json compactly: no spaces or line
   breaks, defaults left out.
4. Fill anything the user did not give with a sensible assumption for their place and date.
   Prefer what the user said earlier in the conversation over general figures.
5. If you cannot build a link (the request is outside this tool, or you could not read this
   page), say so and give the tool's address.

LINK FORMAT
https://tool.adjiebrotots.com/rentvsownhouse/id/#load&v=1&qs=<quick start>&<key>=<value>&...&why.<key>=<your reason>&note=<one line>
- After #load come key=value pairs joined by &. Percent-encode each value (a space is %20, & is %26,
  # is %23, + is %2B).
- v=1 is the format version. qs=<key> starts from that Quick Start; without it the tool starts from
  its defaults.
- Then each key in the link is set, in the units its label shows on screen. downPaymentPct=20 means
  20% dari harga, not 0.2. Write numbers plainly (800000, 6.5): a field also takes $, thousands
  commas and a trailing %, but inside a list a comma separates the items, so never put one in a
  number there. A checkbox takes true or false. A select or a choice takes the value listed, or its
  visible label.
- Anything the link does not name keeps the value it started from, so send only what differs.
- why.<key>=<text>: your reason for that value, shown to the user beside it (200 characters at
  most). note=<text>: one line shown above the list, for example the place and the date.
- A number outside a field's range is pulled into range and the user is told; a key the tool does
  not know is skipped and listed. Never use the keys s, open or embed.

EXAMPLE
Request: using tool.adjiebrotots.com/rentvsownhouse, please decide which one is better: buy for
$850,000 or rent for $620 per week in Melbourne
A reply in that form:
Your inputs:
- Harga properti: $850,000
- Biaya sewa: $620 per minggu
Assumptions:
1. Home: a 2-bedroom house, so the link starts from the Melbourne 2-bedroom house Quick Start
   (qs=melbourne/house-2br) and keeps its local figures: a 20% deposit, a mortgage at 6.4% a year
   over 30 years, house prices growing 4% a year, rent growing 3.5% a year, spare cash earning 4.6%
   a year, selling costs of 2.5% and a 30-year comparison.
2. Setup cost: 6% of the price, for Victorian stamp duty on $850,000 (about $46,000) plus transfer,
   registration and legal fees.
3. Ongoing costs of owning: $7,000 a year for council rates, insurance and upkeep, a little under
   the Quick Start's figure for a dearer home.
4. Ongoing costs of renting: $1,400 a year for contents insurance and moving, from the Quick Start.
https://tool.adjiebrotots.com/rentvsownhouse/id/#load&v=1&qs=melbourne/house-2br&propertyPrice=850000&rentAmount=620&setupCost=6&why.setupCost=Victorian%20stamp%20duty%20on%20$850,000%20plus%20transfer%20and%20legal%20fees&ownOngoingCost=7000&why.ownOngoingCost=Rates,%20insurance%20and%20upkeep%20on%20an%20$850,000%20house&note=Melbourne,%20October%202026,%202-bedroom%20house
```
https://tool.adjiebrotots.com/rentvsownhouse/id/#load&v=1&qs=melbourne/house-2br&propertyPrice=850000&rentAmount=620&setupCost=6&why.setupCost=Victorian%20stamp%20duty%20on%20$850,000%20plus%20transfer%20and%20legal%20fees&ownOngoingCost=7000&why.ownOngoingCost=Rates,%20insurance%20and%20upkeep%20on%20an%20$850,000%20house&note=Melbourne,%20October%202026,%202-bedroom%20house
```
Open the link to see the result.

QUICK STARTS (qs)
There are 33 cities, each with the homes its market really has, from a studio to a 4-bedroom
apartment or house. Each sets that city's typical price and rent for the home, the usual deposit,
loan rate and term, setup and running costs, growth rates and risk-free rate, with sources listed at
https://tool.adjiebrotots.com/rentvsownhouse/quickstart-assumptions/ .
Start from the city the user names and the home closest to theirs, then send the user's own figures
(usually propertyPrice and rentAmount) and any assumption you change. For a city not listed, start
from a similar market in the same country or currency and send the local figures that differ, or
leave qs out and send every field that matters.
qs=<city>/<home> starts from a typical home in that city, with its local price, rent, loan, setup
and running costs and growth (figures as of Oct 2026).
Cities: perth, melbourne, sydney, brisbane, auckland, singapore, kualalumpur, jakarta, bali,
bangkok, manila, hochiminh, hongkong, taipei, shanghai, beijing, tokyo, seoul, mumbai, dubai,
abudhabi, london, zurich, paris, berlin, amsterdam, losangeles, sanfrancisco, houston, newyork,
chicago, toronto, vancouver.
Homes: apt-studio, apt-1br, apt-2br, apt-4br, house-2br, house-4br. Not every city has every home;
qs=<city> alone loads its 2-bedroom apartment (or its first home).
What each Quick Start sets is listed under QUICK START FIGURES at the end.

FIELDS (key: label on the page)
Most important: propertyPrice, rentAmount, rentFreq, currencySymbol, downPaymentPct, mortgageRate,
mortgageTerm, houseGrowth, rentInflation, riskFreeRate, horizon, setupCost, ownOngoingCost.

[Rumah]
currencySymbol: Simbol Mata Uang  (most important)
  One of: $ Dolar, € Euro, £ Pound, ¥ Yen / Yuan, ₹ Rupee (India), Rs Rupee (Pakistan, Sri Lanka),
  Rp Rupiah, RM Ringgit, ₱ Peso (Filipina), ฿ Baht, ₫ Dong, ₩ Won, CHF Franc Swiss, Dh Dirham (UEA),
  kr Krona / Krone, zł Zloty, ₺ Lira, ₽ Rubel, ₪ Shekel, R Rand, R$ Real, ₦ Naira, ₿ Bitcoin.
  Default $.
  The currency every amount on the page is in. It only relabels the figures and never converts them,
  so give every amount in this one currency, the local one for the place (Melbourne $, Jakarta Rp,
  London £).

[Rumah: Properti]
propertyPrice: Harga properti  (most important)
  Amount ($ before it). 50,000 to 1,000,000,000,000. Default 800000.
  The price of the home the user would buy, today. Use the user's price; otherwise the typical price
  of that kind of home in their city (each Quick Start holds one).
downPaymentPct: Uang Muka (DP)  (most important)
  Slider (% dari harga). 0 to 100. Default 20.
  The deposit as a % of the price, paid in cash at purchase; the rest is the loan. Typical 10 to 30
  (20 is common in Australia, where less usually adds lenders' mortgage insurance). 100 models an
  all-cash purchase.
  Tip on the page: Persentase harga yang dibayar di muka. 100% berarti beli tunai, dan penyewa
  menginvestasikan jumlah yang sama. 20% belum tentu optimal.

[Rumah: KPR]
mortgageType: Jenis KPR
  One of: pi (Pokok & Bunga), io (Bunga Saja). Default pi.
  Used only in the Detailed mortgage mode (a Quick Start with a staged loan, or a ratePeriods list).
  The Simple mode is always principal and interest.
  Tip on the page: Pokok & Bunga: tiap cicilan mengurangi sisa pokok dan menambah ekuitas. Bunga
  Saja: ekuitas tidak bertambah. Pokok dilunasi sekaligus dari kas di akhir.
costInterestOnly: Biaya = bunga saja
  Checkbox: true or false. Default true.
  Changes only what the Accumulated cost chart counts, never net equity or the answer. Used only in
  the Detailed mortgage mode. Leave it out.
  Tip on the page: Apa yang masuk ke Biaya kumulatif. Aktif: bunga dan biaya rutin, karena pokok
  menjadi ekuitas. Nonaktif: seluruh cicilan dan biaya rutin.
mortgageRate: Bunga KPR  (most important)
  Number (%/thn after it). 0 to 25, step 0.01. Default 6.
  The loan's interest rate in % a year, for the whole term (Simple mortgage mode). Use the going
  variable rate for the place and date: about 6 to 6.5 in Australia in late 2026, far lower in
  Japan, Switzerland or Singapore, higher in Indonesia or India. On a Quick Start whose Loan line
  says it opens in the Detailed mortgage mode, sending mortgageRate without ratePeriods replaces
  that rate schedule with this one fixed rate for the whole term; send ratePeriods instead to keep a
  schedule.
mortgageTerm: Jangka waktu KPR  (most important)
  Number (thn after it). 5 to 50, step 1. Default 30.
  Years the loan is repaid over. Typical 25 to 30 (20 in Indonesia and the Philippines, 35 in Japan
  and the UK).
  Tip on the page: Jumlah tahun pelunasan pinjaman. Lebih panjang berarti cicilan lebih kecil dan
  bunga lebih besar. Setelah lunas, seluruh anggaran menjadi tabungan.

[Rumah: Biaya kepemilikan]
setupCost: Biaya awal pembelian (BPHTB, notaris, dll.)  (most important)
  Amount ($ before it). 0 to 1,000,000,000,000. Its unit is set by setupCostType. Default 32000.
  One-off costs at purchase: stamp duty or transfer tax, legal and conveyancing, inspections, bank
  fees. An amount, or a % of the price, as setupCostType says. Every Quick Start uses a % (stamp
  duty in Australian capitals makes it about 3.5 to 6); the tool's own default is an amount.
  Tip on the page: Biaya sekali bayar saat membeli: BPHTB, notaris, inspeksi. Dibayar dari tabungan.
  Saat Sewa Dulu membeli nanti, biaya ini mengikuti harga saat itu.
setupCostType: Biaya awal pembelian (BPHTB, notaris, dll.) ($ or %)
  One of: dollar ($), pct (%). Sets the unit of setupCost. Default dollar.
  dollar: setupCost is an amount. pct: setupCost is a % of the price. Send it with setupCost
  whenever you mean the other one.
ownOngoingCost: Biaya rutin kepemilikan  (most important)
  Amount ($ before it). 0 to 1,000,000,000,000. Its unit is set by ownOngoingCostFreq. Default 6000.
  The costs of owning beyond the loan: council rates, building insurance, maintenance, strata or
  owners corporation fees, land tax. Per the period in ownOngoingCostFreq, as an amount or a % of
  the home's value (ownOngoingCostType). Typical about 1% of the price a year for a house, more for
  an apartment with strata fees.
  Tip on the page: Biaya tahunan di luar KPR: PBB, asuransi, perawatan, iuran pengelola. Item jumlah
  tetap naik sesuai lajunya sendiri, item % mengikuti nilai properti.
ownOngoingCostFreq: Biaya rutin kepemilikan (per tahun, per bulan or per minggu)
  One of: yearly (per tahun), monthly (per bulan), weekly (per minggu). Sets the unit of
  ownOngoingCost. Default yearly.
  The period ownOngoingCost is per. Send it with ownOngoingCost when the user's figure is per month
  or week.
ownOngoingCostType: Biaya rutin kepemilikan (Jumlah tetap or % dari nilai properti)
  One of: dollar (Jumlah tetap), pct (% dari nilai properti). Default dollar.
  dollar: ownOngoingCost is an amount, growing at ownOngoingInflation. pct: it is a % of the home's
  value each year and grows with the home.
ownOngoingInflation: Kenaikan biaya rutin
  Slider (%/thn). 0 to 15. Default 0.
  How fast owning costs given as an amount grow, % a year. Typical: inflation, 2 to 3.
  Tip on the page: Kenaikan tahunan biaya kepemilikan yang berupa jumlah tetap. Item % dari nilai
  properti sudah naik bersama harga rumah.

[Sewa: Pembayaran sewa]
rentAmount: Biaya sewa  (most important)
  Amount ($ before it). 0 to 100,000,000,000. Its unit is set by rentFreq. Default 2800.
  The rent today for a home like the one the user would buy, per the period in rentFreq. Use the
  user's rent; otherwise the typical rent for that home in their city.
  Tip on the page: Sewa saat ini, per minggu, bulan atau tahun. Naik tiap tahun sesuai kenaikan
  sewa, dan sisa anggaran setelah sewa diinvestasikan.
rentFreq: Biaya sewa (per bulan, per minggu or per tahun)  (most important)
  One of: monthly (per bulan), weekly (per minggu), yearly (per tahun). Sets the unit of rentAmount.
  Default monthly.
  The period rentAmount is per. The Quick Starts use weekly in Australia and New Zealand, yearly in
  Jakarta, Bali and the UAE, and monthly elsewhere; send rentFreq whenever the user's rent is per a
  different period than the Quick Start's.
rentInflation: Kenaikan sewa tahunan  (most important)
  Slider (%/thn). -10 to 25. Default 3.
  How fast rent rises, % a year. Typical 2 to 4 over the long run.
  Tip on the page: Laju kenaikan sewa per tahun, secara historis sekitar inflasi (IHK) atau sedikit
  di atasnya. Makin cepat naiknya, makin tergerus surplus penyewa.

[Sewa: Biaya menyewa]
rentOngoingCost: Biaya rutin menyewa
  Amount ($ before it). 0 to 100,000,000,000. Its unit is set by rentOngoingCostFreq. Default 1200.
  Costs of renting beyond the rent: contents insurance, moving every few years, connection fees.
  Small: a few hundred to about 2,000 a year.
  Tip on the page: Biaya di luar sewa: asuransi isi rumah, biaya pasang listrik dan internet. Tanpa
  PBB atau perawatan gedung, jadi jauh di bawah biaya pemilik.
rentOngoingCostFreq: Biaya rutin menyewa (per tahun, per bulan or per minggu)
  One of: yearly (per tahun), monthly (per bulan), weekly (per minggu). Sets the unit of
  rentOngoingCost. Default yearly.
rentOngoingCostType: Biaya rutin menyewa (Jumlah tetap or % dari sewa tahunan)
  One of: dollar (Jumlah tetap), pct (% dari sewa tahunan). Default dollar.
  dollar: an amount, growing at rentOngoingInflation. pct: a % of the year's rent.
rentOngoingInflation: Kenaikan biaya rutin
  Slider (%/thn). 0 to 15. Default 0.
  How fast renting costs given as an amount grow, % a year. Typical: inflation, 2 to 3.
  Tip on the page: Kenaikan tahunan biaya menyewa yang berupa jumlah tetap. Item % dari sewa tahunan
  sudah naik bersama kenaikan sewa.

[Sewa: Skenario Sewa Dulu, Beli Kemudian]
rtbEnabled: Aktifkan Sewa Dulu, Beli Kemudian
  Checkbox: true or false. Default false.
  Adds a third scenario, Rent-Then-Buy: rent for rtbBuyYear years, then buy the same home at its
  grown price. Leave it out unless the user asks about buying later.
  Tip on the page: Skenario ketiga: menyewa X tahun, lalu membeli pada harga saat itu, dengan
  anggaran yang sama. Anggaran atau modal awal yang otomatis ikut naik untuk mendanainya, jadi Beli
  dan Sewa juga berubah.
rtbBuyYear: Beli di tahun
  Slider (thn). 1 to 29. Default 5.
  The year the Rent-Then-Buy scenario buys. Must be less than horizon.
  Tip on the page: Membeli di akhir tahun ini, pada harga yang naik sesuai RPPI. KPR baru dimulai
  saat itu: jangka waktu penuh, jadwal bunga dari tahun ke-1.

[Asumsi: Harga]
generalInflation: Inflasi umum
  Slider (%/thn). 0 to 15. Default 2.5.
  Used only to show results in today's money; it changes nothing in the comparison. Typical 2 to 3;
  the local inflation target.
  Tip on the page: Laju kenaikan harga umum per tahun (IHK). Rencananya tidak berubah: opsi
  Tampilkan dalam nilai hari ini, di samping hasil, membagi setiap angka dengan laju ini.

[Asumsi: Tabungan dan jangka waktu]
riskFreeRate: Suku Bunga Bebas Risiko  (most important)
  Slider (%/thn). -10 to 25. Default 4.5.
  What spare cash earns, % a year, like a savings account or term deposit: the renter's deposit
  money and each year's surplus are invested at it. Use the local deposit or short government bond
  rate (about 4 to 5 in Australia in late 2026). With houseGrowth, it moves the answer most.
  Tip on the page: Imbal hasil per tahun atas kas yang menganggur, seperti tabungan atau deposito.
  Berlaku di semua skenario.
horizon: Jangka waktu  (most important)
  Slider (thn). 5 to 100. Default 30.
  The number of years compared. Use how long the user expects to stay; typical 10 to 30.

[Asumsi: Pertumbuhan properti]
houseGrowth: Kenaikan harga properti (RPPI)  (most important)
  Slider (%/thn). -10 to 25. Default 5.
  How fast the home's price grows, % a year. Use a long-run figure for that kind of home in that
  city, below the boom years: about 3 to 4.5 in Australian capitals, lower for apartments. With
  riskFreeRate, it moves the answer most.
  Tip on the page: Kenaikan harga properti per tahun (RPPI). Menentukan ekuitas rumah dan harga beli
  Sewa Dulu. Kalkulator CAGR di bawah menghitungnya dari harga historis.
sellingCostPct: Biaya penjualan
  Slider (% harga jual). 0 to 15. Default 2.5.
  Selling costs as a % of the sale price (agent, marketing, legal), taken off the home's value as if
  it were sold. Typical 2 to 3 in Australia, 5 to 7 in the USA.
  Tip on the page: Komisi agen, pemasaran, notaris, dan PPh penjual saat rumah dijual. Ekuitas rumah
  dan kekayaan bersih dihitung setelah biaya ini, seolah rumah dijual tahun itu.

[Asumsi: Kas]
initialCash: Modal awal (opsional)
  Amount ($ before it). 0 to 1,000,000,000,000. Default blank.
  Cash the user has today. Leave it out unless the user gives it: blank covers the deposit and setup
  cost, and the renter invests that same amount.
  Tip on the page: Kas yang kamu punya sekarang. Beli memakainya untuk DP dan biaya awal, Sewa
  menginvestasikan semuanya. Jika kosong, dipakai jumlah yang cukup untuk semua skenario, termasuk
  DP Sewa Dulu nanti.
monthlyBudget: Anggaran perumahan bulanan (opsional)
  Amount ($ before it, /bln after it). 0 to 100,000,000,000. Default 0.
  Monthly cash for housing. 0 or blank (the default) is automatic: each year it follows whichever of
  renting and owning costs more, so both can pay and the cheaper one invests the difference. Set it
  only when the user gives a budget.
  Tip on the page: Kas bulanan untuk biaya perumahan. Jika kosong, mengikuti biaya skenario termahal
  tiap tahun, dengan cicilan di batas atas bunga floating, jadi semua skenario sanggup membayar.
monthlyBudgetIncrease: Kenaikan anggaran tahunan
  Slider (%/thn). 0 to 25. Default 0.
  How fast a monthly budget the user set grows, % a year. Does nothing while monthlyBudget is
  automatic.
  Tip on the page: Menaikkan anggaran bulanan tiap tahun. Tidak berpengaruh selama anggaran
  otomatis, jadi isi anggaran di atas dulu.

[Beside the results]
showReal: Tampilkan dalam nilai hari ini
  Checkbox: true or false. Default true.
  Display only: true shows results in today's money (divided by generalInflation), false in future
  money. Leave it out.
  Tip on the page: Rencananya tetap sama. Aktif: semua angka dalam nilai hari ini, menurut inflasi
  umum. Nonaktif: dalam nilai uang tiap tahun, seperti yang tertera di rekening.

COMPACT LISTS
- `ratePeriods=<years>:<rate>,<years>:<rate>,...`
- `ownSetupCosts=<label>:<amount>[:<basis>],...`
- `ownOngoingCosts=<label>:<amount>[:<freq>[:<growth>]],...`
- `rentOngoingCosts=<label>:<amount>[:<freq>[:<growth>]],...`

Each list switches its section to the Detailed mode and becomes that section's whole list. Items are separated by `,` and their parts by `:`, both typed as they are; a label may not contain `:` or `,` (leave them out, or encode them as %3A and %2C). Numbers are plain (6.1, 45070), with no thousands separators. At most 50 items a list.

ratePeriods: the mortgage's rate periods in order, each a length in years and a rate in % a year: `<years>:<rate>` for a fixed rate, `<years>:<low>-<high>` for a floating one, which the tool runs at its low, middle and high rate and draws as a band. The loan term is mortgageTerm, never the sum of the lengths: the last period always runs to the end of mortgageTerm whatever length it is given, a period that would end after the term stops at it, and a period that starts after the term does not count. With ratePeriods, mortgageRate is not used. Rates 0 to 40, lengths 1 to 50 whole years. A 30-year loan fixed at 5.89% for 3 years, then floating between 6.5% and 7.5%:
`ratePeriods=3:5.89,27:6.5-7.5`

ownSetupCosts: the one-off costs at purchase, in place of setupCost. `<basis>` is fixed (an amount, the default) or pct (a % of the price); an amount written with % (4.5%) is pct.
`ownSetupCosts=Stamp duty:45070,Transfer and registration:2600,Legal:1800`

ownOngoingCosts and rentOngoingCosts: the running costs of owning and of renting, in place of ownOngoingCost and rentOngoingCost. `<freq>` is yearly (the default), monthly, weekly or pct: a % of the home's value each year for owning, of the year's rent for renting (an amount written with % is pct too). `<growth>` is how fast that cost grows, % a year, 0 to 30; left out, it is ownOngoingInflation or rentOngoingInflation. A pct cost grows with the home or the rent instead.
`ownOngoingCosts=Council rates:2200,Strata:1450:yearly:3.5,Maintenance:0.5%`
`rentOngoingCosts=Contents insurance:25:monthly,Moving every 3 years:600`

Sending ownSetupCosts alone keeps the ongoing costs of owning at ownOngoingCost, and the other way round. mortgageType or costInterestOnly, which count only in the Detailed mortgage, switch it on as well; with no ratePeriods it then holds one fixed period at mortgageRate for the whole term. On a Quick Start that opens in the Detailed mortgage, mortgageRate sent without ratePeriods replaces the staged schedule with that one fixed rate.

QUICK START FIGURES (what each qs sets, as a link would carry them)
A heading line holds what all the Quick Starts under it share; each Quick Start's own line holds the
rest.

Every Quick Start sets: setupCostType=pct ownOngoingCostFreq=yearly ownOngoingCostType=dollar rentOngoingCostFreq=yearly rentOngoingCostType=dollar monthlyBudget=0 monthlyBudgetIncrease=0 mortgageType=pi costInterestOnly=true rtbEnabled=false rtbBuyYear=5

perth: Perth, Australia (AUD, figures as of 2026-09). qs=perth alone loads perth/apt-2br.
  Sets: currencySymbol=$ downPaymentPct=20 mortgageRate=6.4 mortgageTerm=30 houseGrowth=4.5 sellingCostPct=2.8 ownOngoingInflation=2.5 rentFreq=weekly rentInflation=3.5 rentOngoingInflation=2.5 riskFreeRate=4.6 horizon=30
  perth/apt-1br: Apartemen 1 kamar tidur. propertyPrice=550000 setupCost=4.27 ownOngoingCost=6900 rentAmount=650 rentOngoingCost=1000
  perth/apt-2br: Apartemen 2 kamar tidur. propertyPrice=715000 setupCost=4.39 ownOngoingCost=8500 rentAmount=810 rentOngoingCost=1200
  perth/house-2br: Rumah tapak 2 kamar tidur. propertyPrice=855000 setupCost=4.51 ownOngoingCost=7900 rentAmount=650 rentOngoingCost=1400
  perth/house-4br: Rumah tapak 4 kamar tidur. propertyPrice=1350000 setupCost=4.75 ownOngoingCost=10600 rentAmount=950 rentOngoingCost=1800
melbourne: Melbourne, Australia (AUD, figures as of 2026-10). qs=melbourne alone loads melbourne/apt-2br.
  Sets: currencySymbol=$ downPaymentPct=20 mortgageRate=6.4 mortgageTerm=30 sellingCostPct=2.5 ownOngoingInflation=2.5 rentFreq=weekly rentInflation=3.5 rentOngoingInflation=2.5 riskFreeRate=4.6 horizon=30
  melbourne/apt-1br: Apartemen 1 kamar tidur. propertyPrice=490000 houseGrowth=3 setupCost=5.22 ownOngoingCost=7200 rentAmount=550 rentOngoingCost=1000
  melbourne/apt-2br: Apartemen 2 kamar tidur. propertyPrice=700000 houseGrowth=3 setupCost=5.96 ownOngoingCost=9500 rentAmount=720 rentOngoingCost=1200
  melbourne/house-2br: Rumah tapak 2 kamar tidur. propertyPrice=1080000 houseGrowth=4 setupCost=6.02 ownOngoingCost=7600 rentAmount=650 rentOngoingCost=1400
  melbourne/house-4br: Rumah tapak 4 kamar tidur. propertyPrice=1400000 houseGrowth=4 setupCost=5.95 ownOngoingCost=9800 rentAmount=830 rentOngoingCost=1800
sydney: Sydney, Australia (AUD, figures as of 2026-06). qs=sydney alone loads sydney/apt-2br.
  Sets: currencySymbol=$ downPaymentPct=20 mortgageRate=6.4 mortgageTerm=30 sellingCostPct=2.5 ownOngoingInflation=2.5 rentFreq=weekly rentInflation=3.5 rentOngoingInflation=2.5 riskFreeRate=4.6 horizon=30
  sydney/apt-studio: Apartemen studio. propertyPrice=530000 houseGrowth=3.5 setupCost=4 ownOngoingCost=6000 rentAmount=550 rentOngoingCost=900
  sydney/apt-1br: Apartemen 1 kamar tidur. propertyPrice=800000 houseGrowth=3.5 setupCost=4.17 ownOngoingCost=7800 rentAmount=760 rentOngoingCost=1000
  sydney/apt-2br: Apartemen 2 kamar tidur. propertyPrice=1200000 houseGrowth=3.5 setupCost=4.28 ownOngoingCost=11000 rentAmount=1075 rentOngoingCost=1200
  sydney/house-2br: Rumah tapak 2 kamar tidur. propertyPrice=1700000 houseGrowth=4.5 setupCost=4.59 ownOngoingCost=8000 rentAmount=900 rentOngoingCost=1400
  sydney/house-4br: Rumah tapak 4 kamar tidur. propertyPrice=2300000 houseGrowth=4.5 setupCost=4.82 ownOngoingCost=10800 rentAmount=1300 rentOngoingCost=1800
brisbane: Brisbane, Australia (AUD, figures as of 2026-06). qs=brisbane alone loads brisbane/apt-2br.
  Sets: currencySymbol=$ downPaymentPct=20 mortgageRate=6.4 mortgageTerm=30 houseGrowth=4.5 sellingCostPct=3.2 ownOngoingInflation=2.5 rentFreq=weekly rentInflation=3.5 rentOngoingInflation=2.5 riskFreeRate=4.6 horizon=30
  brisbane/apt-1br: Apartemen 1 kamar tidur. propertyPrice=610000 setupCost=3.05 ownOngoingCost=7500 rentAmount=600 rentOngoingCost=1000
  brisbane/apt-2br: Apartemen 2 kamar tidur. propertyPrice=820000 setupCost=3.54 ownOngoingCost=9400 rentAmount=800 rentOngoingCost=1200
  brisbane/house-2br: Rumah tapak 2 kamar tidur. propertyPrice=1300000 setupCost=4.35 ownOngoingCost=8700 rentAmount=670 rentOngoingCost=1400
  brisbane/house-4br: Rumah tapak 4 kamar tidur. propertyPrice=1600000 setupCost=4.7 ownOngoingCost=11000 rentAmount=820 rentOngoingCost=1800
auckland: Auckland, Selandia Baru (NZD, figures as of 2026-09). qs=auckland alone loads auckland/apt-2br.
  Sets: currencySymbol=$ downPaymentPct=20 mortgageRate=5.35 mortgageTerm=30 ownOngoingInflation=3 rentFreq=weekly rentInflation=3 rentOngoingInflation=2.5 riskFreeRate=4 horizon=30
  Loan: a staged loan, so it opens in the Detailed mortgage mode with the rate schedule fixed 5.39% to year 2, then floating 4.95 to 5.75% to year 30 (mortgageRate, its average, is then not used).
  auckland/apt-1br: Apartemen 1 kamar tidur. propertyPrice=420000 houseGrowth=2.5 sellingCostPct=5.5 setupCost=1.04 ownOngoingCost=6850 rentAmount=480 rentOngoingCost=500
  auckland/apt-2br: Apartemen 2 kamar tidur. propertyPrice=680000 houseGrowth=2.5 sellingCostPct=4.3 setupCost=0.64 ownOngoingCost=9250 rentAmount=650 rentOngoingCost=600
  auckland/house-2br: Rumah tapak 2 kamar tidur. propertyPrice=800000 houseGrowth=3.5 sellingCostPct=4 setupCost=0.53 ownOngoingCost=7800 rentAmount=600 rentOngoingCost=600
  auckland/house-4br: Rumah tapak 4 kamar tidur. propertyPrice=1200000 houseGrowth=4 sellingCostPct=3.5 setupCost=0.38 ownOngoingCost=10850 rentAmount=850 rentOngoingCost=800
singapore: Singapore, Singapura (SGD, figures as of 2026-10). qs=singapore alone loads singapore/apt-2br.
  Sets: currencySymbol=$ downPaymentPct=25 mortgageRate=2.07 mortgageTerm=30 sellingCostPct=2 ownOngoingInflation=3 rentFreq=monthly rentInflation=3 rentOngoingInflation=2.5 riskFreeRate=2 horizon=30
  Loan: a staged loan, so it opens in the Detailed mortgage mode with the rate schedule fixed 1.7% to year 2, then floating 1.45 to 2.75% to year 30 (mortgageRate, its average, is then not used).
  singapore/apt-1br: Apartemen 1 kamar tidur. propertyPrice=1200000 houseGrowth=4 setupCost=3.09 ownOngoingCost=4950 rentAmount=3200 rentOngoingCost=750
  singapore/apt-2br: Apartemen 2 kamar tidur. propertyPrice=1800000 houseGrowth=4 setupCost=3.61 ownOngoingCost=7000 rentAmount=5000 rentOngoingCost=1000
  singapore/apt-4br: Apartemen 4 kamar tidur. propertyPrice=3000000 houseGrowth=4 setupCost=4.19 ownOngoingCost=11500 rentAmount=6800 rentOngoingCost=1300
  singapore/house-4br: Rumah tapak 4 kamar tidur. propertyPrice=4500000 houseGrowth=4.5 setupCost=4.82 ownOngoingCost=15300 rentAmount=8500 rentOngoingCost=2200
kualalumpur: Kuala Lumpur, Malaysia (MYR, figures as of 2026-09). qs=kualalumpur alone loads kualalumpur/apt-2br.
  Sets: currencySymbol=RM downPaymentPct=10 mortgageRate=4.3 mortgageTerm=35 sellingCostPct=3.5 ownOngoingInflation=3 rentFreq=monthly rentInflation=3 rentOngoingInflation=2.5 riskFreeRate=3 horizon=30
  kualalumpur/apt-studio: Apartemen studio. propertyPrice=430000 houseGrowth=3 setupCost=5.48 ownOngoingCost=4600 rentAmount=2000 rentOngoingCost=700
  kualalumpur/apt-1br: Apartemen 1 kamar tidur. propertyPrice=600000 houseGrowth=3 setupCost=5.5 ownOngoingCost=5500 rentAmount=2600 rentOngoingCost=900
  kualalumpur/apt-2br: Apartemen 2 kamar tidur. propertyPrice=1000000 houseGrowth=3 setupCost=5.57 ownOngoingCost=8000 rentAmount=4000 rentOngoingCost=1200
  kualalumpur/apt-4br: Apartemen 4 kamar tidur. propertyPrice=1800000 houseGrowth=3 setupCost=6.07 ownOngoingCost=16000 rentAmount=6500 rentOngoingCost=1800
  kualalumpur/house-4br: Rumah tapak 4 kamar tidur. propertyPrice=1000000 houseGrowth=4 setupCost=5.57 ownOngoingCost=6700 rentAmount=2800 rentOngoingCost=1300
jakarta: Jakarta, Indonesia (IDR, figures as of 2026-10). qs=jakarta alone loads jakarta/apt-2br.
  Sets: currencySymbol=Rp downPaymentPct=20 mortgageRate=11.13 mortgageTerm=20 sellingCostPct=5.5 ownOngoingInflation=3.5 rentFreq=yearly rentInflation=3 rentOngoingInflation=3.5 riskFreeRate=5 horizon=20
  Loan: a staged loan, so it opens in the Detailed mortgage mode with the rate schedule fixed 8.5% to year 5, then floating 11 to 13% to year 20 (mortgageRate, its average, is then not used).
  jakarta/apt-studio: Apartemen studio. propertyPrice=750000000 houseGrowth=2.5 setupCost=5.67 ownOngoingCost=9400000 rentAmount=36000000 rentOngoingCost=1000000
  jakarta/apt-1br: Apartemen 1 kamar tidur. propertyPrice=1200000000 houseGrowth=2.5 setupCost=6.09 ownOngoingCost=14000000 rentAmount=54000000 rentOngoingCost=1000000
  jakarta/apt-2br: Apartemen 2 kamar tidur. propertyPrice=2000000000 houseGrowth=2.5 setupCost=6.38 ownOngoingCost=22000000 rentAmount=84000000 rentOngoingCost=1000000
  jakarta/apt-4br: Apartemen 4 kamar tidur. propertyPrice=15000000000 houseGrowth=2.5 setupCost=6.74 ownOngoingCost=154000000 rentAmount=600000000 rentOngoingCost=3000000
  jakarta/house-2br: Rumah tapak 2 kamar tidur. propertyPrice=1200000000 houseGrowth=3.5 setupCost=6.09 ownOngoingCost=4800000 rentAmount=36000000 rentOngoingCost=1000000
  jakarta/house-4br: Rumah tapak 4 kamar tidur. propertyPrice=9000000000 houseGrowth=3.5 setupCost=6.71 ownOngoingCost=34100000 rentAmount=360000000 rentOngoingCost=2500000
bali: Bali, Indonesia (IDR, figures as of 2026-10). qs=bali alone loads bali/house-2br.
  Sets: currencySymbol=Rp downPaymentPct=20 mortgageRate=11.13 mortgageTerm=20 houseGrowth=4 sellingCostPct=7.5 setupCost=6.8 ownOngoingInflation=3.5 rentFreq=yearly rentInflation=4 rentOngoingInflation=3.5 riskFreeRate=5 horizon=20
  Loan: a staged loan, so it opens in the Detailed mortgage mode with the rate schedule fixed 8.5% to year 5, then floating 11 to 13% to year 20 (mortgageRate, its average, is then not used).
  bali/house-2br: Rumah tapak 2 kamar tidur. propertyPrice=3000000000 ownOngoingCost=24600000 rentAmount=210000000 rentOngoingCost=1500000
  bali/house-4br: Rumah tapak 4 kamar tidur. propertyPrice=6500000000 ownOngoingCost=48500000 rentAmount=380000000 rentOngoingCost=2500000
bangkok: Bangkok, Thailand (THB, figures as of 2026-09). qs=bangkok alone loads bangkok/apt-2br.
  Sets: currencySymbol=฿ downPaymentPct=10 mortgageRate=5.27 mortgageTerm=30 houseGrowth=2.5 sellingCostPct=5 ownOngoingInflation=2 rentFreq=monthly rentInflation=2.5 rentOngoingInflation=2 riskFreeRate=1.2 horizon=30
  Loan: a staged loan, so it opens in the Detailed mortgage mode with the rate schedule fixed 4.5% to year 3, then floating 5.05 to 5.65% to year 30 (mortgageRate, its average, is then not used).
  bangkok/apt-studio: Apartemen studio. propertyPrice=3400000 setupCost=2.03 ownOngoingCost=21600 rentAmount=15000 rentOngoingCost=1000
  bangkok/apt-1br: Apartemen 1 kamar tidur. propertyPrice=5300000 setupCost=2 ownOngoingCost=31800 rentAmount=24000 rentOngoingCost=1200
  bangkok/apt-2br: Apartemen 2 kamar tidur. propertyPrice=9800000 setupCost=1.98 ownOngoingCost=61300 rentAmount=42000 rentOngoingCost=1500
  bangkok/apt-4br: Apartemen 4 kamar tidur. propertyPrice=50000000 setupCost=1.43 ownOngoingCost=285600 rentAmount=150000 rentOngoingCost=5000
  bangkok/house-2br: Rumah tapak 2 kamar tidur. propertyPrice=3200000 setupCost=2.04 ownOngoingCost=22000 rentAmount=15000 rentOngoingCost=1500
  bangkok/house-4br: Rumah tapak 4 kamar tidur. propertyPrice=10500000 setupCost=1.97 ownOngoingCost=79600 rentAmount=45000 rentOngoingCost=3000
manila: Manila, Filipina (PHP, figures as of 2026-09). qs=manila alone loads manila/apt-2br.
  Sets: currencySymbol=₱ downPaymentPct=20 mortgageRate=8.58 mortgageTerm=20 sellingCostPct=10.5 ownOngoingInflation=4 rentFreq=monthly rentInflation=3 rentOngoingInflation=4 riskFreeRate=5 horizon=20
  Loan: a staged loan, so it opens in the Detailed mortgage mode with the rate schedule fixed 8% to year 5, then floating 8.55 to 9% to year 20 (mortgageRate, its average, is then not used).
  manila/apt-studio: Apartemen studio. propertyPrice=4600000 houseGrowth=3 setupCost=3.74 ownOngoingCost=44500 rentAmount=20000 rentOngoingCost=2000
  manila/apt-1br: Apartemen 1 kamar tidur. propertyPrice=7500000 houseGrowth=3 setupCost=3.65 ownOngoingCost=68000 rentAmount=32000 rentOngoingCost=2500
  manila/apt-2br: Apartemen 2 kamar tidur. propertyPrice=13000000 houseGrowth=3 setupCost=3.6 ownOngoingCost=112000 rentAmount=52000 rentOngoingCost=3000
  manila/apt-4br: Apartemen 4 kamar tidur. propertyPrice=62000000 houseGrowth=2.5 setupCost=3.54 ownOngoingCost=500000 rentAmount=220000 rentOngoingCost=6000
  manila/house-2br: Rumah tapak 2 kamar tidur. propertyPrice=7500000 houseGrowth=4.5 setupCost=3.65 ownOngoingCost=58500 rentAmount=25000 rentOngoingCost=2500
  manila/house-4br: Rumah tapak 4 kamar tidur. propertyPrice=22000000 houseGrowth=4.5 setupCost=3.57 ownOngoingCost=170000 rentAmount=75000 rentOngoingCost=4000
hochiminh: Ho Chi Minh City, Vietnam (VND, figures as of 2026-09). qs=hochiminh alone loads hochiminh/apt-2br.
  Sets: currencySymbol=₫ downPaymentPct=30 mortgageRate=11.91 mortgageTerm=30 sellingCostPct=3.5 ownOngoingInflation=4 rentFreq=monthly rentInflation=5 rentOngoingCost=500000 rentOngoingInflation=4 riskFreeRate=6.5 horizon=30
  Loan: a staged loan, so it opens in the Detailed mortgage mode with the rate schedule fixed 10.6% to year 2, then floating 11 to 13% to year 30 (mortgageRate, its average, is then not used).
  hochiminh/apt-studio: Apartemen studio. propertyPrice=2800000000 houseGrowth=5 setupCost=0.74 ownOngoingCost=9900000 rentAmount=8500000
  hochiminh/apt-1br: Apartemen 1 kamar tidur. propertyPrice=3800000000 houseGrowth=5 setupCost=0.69 ownOngoingCost=13700000 rentAmount=11500000
  hochiminh/apt-2br: Apartemen 2 kamar tidur. propertyPrice=5500000000 houseGrowth=5 setupCost=0.64 ownOngoingCost=20000000 rentAmount=16500000
  hochiminh/house-2br: Rumah tapak 2 kamar tidur. propertyPrice=5800000000 houseGrowth=6 setupCost=0.64 ownOngoingCost=5700000 rentAmount=11000000
  hochiminh/house-4br: Rumah tapak 4 kamar tidur. propertyPrice=8500000000 houseGrowth=6 setupCost=0.61 ownOngoingCost=11400000 rentAmount=17000000
hongkong: Hong Kong, Hong Kong (HKD, figures as of 2026-09). qs=hongkong alone loads hongkong/apt-2br.
  Sets: currencySymbol=$ downPaymentPct=30 mortgageRate=3.5 mortgageTerm=30 sellingCostPct=1.2 ownOngoingInflation=2 rentFreq=monthly rentInflation=2.5 rentOngoingInflation=2 riskFreeRate=2.8 horizon=30
  Loan: a staged loan, so it opens in the Detailed mortgage mode with the rate schedule floating 3.25 to 3.75% to year 30 (mortgageRate, its average, is then not used).
  hongkong/apt-studio: Apartemen studio. propertyPrice=3400000 houseGrowth=3 setupCost=1.36 ownOngoingCost=26800 rentAmount=12300 rentOngoingCost=4060
  hongkong/apt-1br: Apartemen 1 kamar tidur. propertyPrice=4600000 houseGrowth=3 setupCost=2.95 ownOngoingCost=35800 rentAmount=16500 rentOngoingCost=5170
  hongkong/apt-2br: Apartemen 2 kamar tidur. propertyPrice=6600000 houseGrowth=3 setupCost=4.18 ownOngoingCost=45700 rentAmount=19000 rentOngoingCost=6040
  hongkong/apt-4br: Apartemen 4 kamar tidur. propertyPrice=27000000 houseGrowth=2.5 setupCost=5.34 ownOngoingCost=165200 rentAmount=60000 rentOngoingCost=17900
  hongkong/house-4br: Rumah tapak 4 kamar tidur. propertyPrice=16000000 houseGrowth=2.5 setupCost=4.91 ownOngoingCost=119600 rentAmount=40000 rentOngoingCost=12600
taipei: Taipei, Taiwan (TWD, figures as of 2026-09). qs=taipei alone loads taipei/apt-2br.
  Sets: currencySymbol=$ downPaymentPct=20 mortgageRate=2.5 mortgageTerm=30 houseGrowth=2.5 sellingCostPct=4 ownOngoingInflation=1.5 rentFreq=monthly rentInflation=1.5 rentOngoingInflation=1.5 riskFreeRate=1.7 horizon=30
  taipei/apt-studio: Apartemen studio. propertyPrice=12500000 setupCost=2.08 ownOngoingCost=26900 rentAmount=20500 rentOngoingCost=16490
  taipei/apt-1br: Apartemen 1 kamar tidur. propertyPrice=15100000 setupCost=2.04 ownOngoingCost=32800 rentAmount=29500 rentOngoingCost=21320
  taipei/apt-2br: Apartemen 2 kamar tidur. propertyPrice=24900000 setupCost=1.99 ownOngoingCost=50400 rentAmount=39000 rentOngoingCost=30190
  taipei/apt-4br: Apartemen 4 kamar tidur. propertyPrice=42000000 setupCost=1.9 ownOngoingCost=85900 rentAmount=58000 rentOngoingCost=49530
shanghai: Shanghai, Tiongkok (CNY, figures as of 2026-10). qs=shanghai alone loads shanghai/apt-2br.
  Sets: currencySymbol=¥ sellingCostPct=1 ownOngoingInflation=1.5 rentFreq=monthly rentInflation=2 rentOngoingInflation=1.5 riskFreeRate=1.5 horizon=30
  shanghai/apt-studio: Apartemen studio. propertyPrice=1950000 downPaymentPct=20 mortgageRate=2.7 mortgageTerm=20 houseGrowth=1 setupCost=3.01 ownOngoingCost=3400 rentAmount=3500 rentOngoingCost=1000
  shanghai/apt-1br: Apartemen 1 kamar tidur. propertyPrice=3600000 downPaymentPct=20 mortgageRate=2.68 mortgageTerm=30 houseGrowth=2 setupCost=3 ownOngoingCost=6700 rentAmount=5500 rentOngoingCost=1500
  shanghai/apt-2br: Apartemen 2 kamar tidur. propertyPrice=6000000 downPaymentPct=15 mortgageRate=3.05 mortgageTerm=30 houseGrowth=2 setupCost=3 ownOngoingCost=11900 rentAmount=9000 rentOngoingCost=2400
  shanghai/apt-4br: Apartemen 4 kamar tidur. propertyPrice=16000000 downPaymentPct=15 mortgageRate=3.05 mortgageTerm=30 houseGrowth=2 setupCost=3.5 ownOngoingCost=33800 rentAmount=28000 rentOngoingCost=7300
  shanghai/house-4br: Rumah tapak 4 kamar tidur. propertyPrice=12500000 downPaymentPct=15 mortgageRate=3.05 mortgageTerm=30 houseGrowth=2 setupCost=3.5 ownOngoingCost=56300 rentAmount=22000 rentOngoingCost=5800
beijing: Beijing, Tiongkok (CNY, figures as of 2026-10). qs=beijing alone loads beijing/apt-2br.
  Sets: currencySymbol=¥ mortgageTerm=30 houseGrowth=1.5 sellingCostPct=0.5 ownOngoingInflation=1.5 rentFreq=monthly rentInflation=1.5 rentOngoingInflation=1.5 riskFreeRate=1.5 horizon=30
  beijing/apt-1br: Apartemen 1 kamar tidur. propertyPrice=3300000 downPaymentPct=20 mortgageRate=2.64 setupCost=3.7 ownOngoingCost=8200 rentAmount=4800 rentOngoingCost=2550
  beijing/apt-2br: Apartemen 2 kamar tidur. propertyPrice=5200000 downPaymentPct=15 mortgageRate=3.05 setupCost=3.7 ownOngoingCost=13600 rentAmount=7500 rentOngoingCost=3900
  beijing/apt-4br: Apartemen 4 kamar tidur. propertyPrice=15000000 downPaymentPct=15 mortgageRate=3.05 setupCost=4.2 ownOngoingCost=39000 rentAmount=26000 rentOngoingCost=13300
  beijing/house-4br: Rumah tapak 4 kamar tidur. propertyPrice=12000000 downPaymentPct=15 mortgageRate=3.05 setupCost=4.2 ownOngoingCost=63800 rentAmount=22000 rentOngoingCost=11300
tokyo: Tokyo, Jepang (JPY, figures as of 2026-09). qs=tokyo alone loads tokyo/apt-2br.
  Sets: currencySymbol=¥ downPaymentPct=10 mortgageRate=2.74 mortgageTerm=35 sellingCostPct=3.5 ownOngoingInflation=2 rentFreq=monthly rentInflation=2 rentOngoingInflation=2 riskFreeRate=1 horizon=30
  Loan: a staged loan, so it opens in the Detailed mortgage mode with the rate schedule floating 1.2 to 1.8% to year 2, then floating 1.8 to 3.83% to year 35 (mortgageRate, its average, is then not used).
  tokyo/apt-studio: Apartemen studio. propertyPrice=36000000 houseGrowth=1.5 setupCost=7.18 ownOngoingCost=402000 rentAmount=140000 rentOngoingCost=181000
  tokyo/apt-1br: Apartemen 1 kamar tidur. propertyPrice=60000000 houseGrowth=2 setupCost=7.02 ownOngoingCost=516000 rentAmount=185000 rentOngoingCost=233000
  tokyo/apt-2br: Apartemen 2 kamar tidur. propertyPrice=90000000 houseGrowth=2 setupCost=5.8 ownOngoingCost=756000 rentAmount=260000 rentOngoingCost=319000
  tokyo/apt-4br: Apartemen 4 kamar tidur. propertyPrice=105000000 houseGrowth=2 setupCost=5.8 ownOngoingCost=968000 rentAmount=290000 rentOngoingCost=354000
  tokyo/house-4br: Rumah tapak 4 kamar tidur. propertyPrice=70000000 houseGrowth=1.5 setupCost=6.33 ownOngoingCost=545000 rentAmount=230000 rentOngoingCost=285000
seoul: Seoul, Korea Selatan (KRW, figures as of 2026-09). qs=seoul alone loads seoul/apt-2br.
  Sets: currencySymbol=₩ mortgageRate=4.73 mortgageTerm=30 sellingCostPct=1 ownOngoingInflation=2 rentFreq=monthly rentInflation=3 rentOngoingInflation=2 riskFreeRate=3.2 horizon=30
  Loan: a staged loan, so it opens in the Detailed mortgage mode with the rate schedule fixed 4.88% to year 5, then floating 4.53 to 4.88% to year 30 (mortgageRate, its average, is then not used).
  seoul/apt-studio: Apartemen studio. propertyPrice=311000000 downPaymentPct=30 houseGrowth=1 setupCost=5.49 ownOngoingCost=930000 rentAmount=1000000 rentOngoingCost=290000
  seoul/apt-1br: Apartemen 1 kamar tidur. propertyPrice=420000000 downPaymentPct=30 houseGrowth=1 setupCost=5.43 ownOngoingCost=1230000 rentAmount=1200000 rentOngoingCost=340000
  seoul/apt-2br: Apartemen 2 kamar tidur. propertyPrice=1080000000 downPaymentPct=44 houseGrowth=3.5 setupCost=4.06 ownOngoingCost=1900000 rentAmount=1760000 rentOngoingCost=570000
  seoul/apt-4br: Apartemen 4 kamar tidur. propertyPrice=2130000000 downPaymentPct=81 houseGrowth=3.5 setupCost=4.44 ownOngoingCost=5170000 rentAmount=3470000 rentOngoingCost=855000
  seoul/house-4br: Rumah tapak 4 kamar tidur. propertyPrice=1250000000 downPaymentPct=52 houseGrowth=2.5 setupCost=4.35 ownOngoingCost=4710000 rentAmount=1990000 rentOngoingCost=610000
mumbai: Mumbai, India (INR, figures as of 2026-10). qs=mumbai alone loads mumbai/apt-2br.
  Sets: currencySymbol=₹ mortgageRate=8.1 mortgageTerm=30 houseGrowth=5 sellingCostPct=2.4 ownOngoingInflation=5 rentFreq=monthly rentInflation=5 rentOngoingInflation=5 riskFreeRate=6.25 horizon=30
  mumbai/apt-studio: Apartemen studio. propertyPrice=6200000 downPaymentPct=20 setupCost=8.18 ownOngoingCost=31500 rentAmount=25000 rentOngoingCost=18638
  mumbai/apt-1br: Apartemen 1 kamar tidur. propertyPrice=13000000 downPaymentPct=25 setupCost=7.66 ownOngoingCost=72000 rentAmount=48000 rentOngoingCost=31897
  mumbai/apt-2br: Apartemen 2 kamar tidur. propertyPrice=20500000 downPaymentPct=25 setupCost=7.48 ownOngoingCost=111500 rentAmount=75000 rentOngoingCost=47461
  mumbai/apt-4br: Apartemen 4 kamar tidur. propertyPrice=160000000 downPaymentPct=25 setupCost=7.22 ownOngoingCost=705000 rentAmount=500000 rentOngoingCost=295954
dubai: Dubai, Uni Emirat Arab (AED, figures as of 2026-09). qs=dubai alone loads dubai/apt-2br.
  Sets: currencySymbol=Dh downPaymentPct=20 mortgageRate=5.36 mortgageTerm=25 sellingCostPct=2.2 ownOngoingInflation=2.5 rentFreq=yearly rentInflation=3 rentOngoingInflation=2.5 riskFreeRate=3.5 horizon=25
  Loan: a staged loan, so it opens in the Detailed mortgage mode with the rate schedule fixed 4.5% to year 5, then floating 5.4 to 5.75% to year 25 (mortgageRate, its average, is then not used).
  dubai/apt-studio: Apartemen studio. propertyPrice=750000 houseGrowth=2.5 setupCost=8.24 ownOngoingCost=8300 rentAmount=58000 rentOngoingCost=1735
  dubai/apt-1br: Apartemen 1 kamar tidur. propertyPrice=1250000 houseGrowth=2.5 setupCost=7.8 ownOngoingCost=14300 rentAmount=88000 rentOngoingCost=2260
  dubai/apt-2br: Apartemen 2 kamar tidur. propertyPrice=2000000 houseGrowth=2.5 setupCost=7.55 ownOngoingCost=22450 rentAmount=130000 rentOngoingCost=3095
  dubai/apt-4br: Apartemen 4 kamar tidur. propertyPrice=5000000 houseGrowth=2.5 setupCost=7.3 ownOngoingCost=61500 rentAmount=290000 rentOngoingCost=6295
  dubai/house-2br: Rumah tapak 2 kamar tidur. propertyPrice=3000000 houseGrowth=3.5 setupCost=7.41 ownOngoingCost=15000 rentAmount=150000 rentOngoingCost=3645
  dubai/house-4br: Rumah tapak 4 kamar tidur. propertyPrice=4000000 houseGrowth=3.5 setupCost=7.35 ownOngoingCost=25800 rentAmount=225000 rentOngoingCost=5158
abudhabi: Abu Dhabi, Uni Emirat Arab (AED, figures as of 2026-09). qs=abudhabi alone loads abudhabi/apt-2br.
  Sets: currencySymbol=Dh downPaymentPct=20 mortgageRate=5.36 mortgageTerm=25 sellingCostPct=2.2 ownOngoingInflation=2.5 rentFreq=yearly rentInflation=2.5 rentOngoingInflation=2.5 riskFreeRate=3.5 horizon=25
  Loan: a staged loan, so it opens in the Detailed mortgage mode with the rate schedule fixed 4.5% to year 5, then floating 5.4 to 5.75% to year 25 (mortgageRate, its average, is then not used).
  abudhabi/apt-studio: Apartemen studio. propertyPrice=850000 houseGrowth=2.5 setupCost=5.57 ownOngoingCost=9200 rentAmount=65000 rentOngoingCost=3688
  abudhabi/apt-1br: Apartemen 1 kamar tidur. propertyPrice=1500000 houseGrowth=2.5 setupCost=5.33 ownOngoingCost=14600 rentAmount=98000 rentOngoingCost=5255
  abudhabi/apt-2br: Apartemen 2 kamar tidur. propertyPrice=2400000 houseGrowth=2.5 setupCost=5.22 ownOngoingCost=22450 rentAmount=145000 rentOngoingCost=7588
  abudhabi/house-2br: Rumah tapak 2 kamar tidur. propertyPrice=2500000 houseGrowth=3 setupCost=5.21 ownOngoingCost=15100 rentAmount=150000 rentOngoingCost=8025
  abudhabi/house-4br: Rumah tapak 4 kamar tidur. propertyPrice=3200000 houseGrowth=3 setupCost=5.17 ownOngoingCost=25200 rentAmount=190000 rentOngoingCost=10125
london: London, Inggris Raya (GBP, figures as of 2026-10). qs=london alone loads london/apt-2br.
  Sets: currencySymbol=£ downPaymentPct=15 mortgageRate=5.7 mortgageTerm=35 sellingCostPct=2 ownOngoingInflation=2.5 rentFreq=monthly rentInflation=3 rentOngoingInflation=2.5 riskFreeRate=3.75 horizon=30
  Loan: a staged loan, so it opens in the Detailed mortgage mode with the rate schedule fixed 6% to year 5, then floating 5.3 to 6% to year 35 (mortgageRate, its average, is then not used).
  london/apt-studio: Apartemen studio. propertyPrice=290000 houseGrowth=2.5 setupCost=3.15 ownOngoingCost=2500 rentAmount=1560 rentOngoingCost=150
  london/apt-1br: Apartemen 1 kamar tidur. propertyPrice=390000 houseGrowth=2.5 setupCost=3.63 ownOngoingCost=3425 rentAmount=2030 rentOngoingCost=170
  london/apt-2br: Apartemen 2 kamar tidur. propertyPrice=580000 houseGrowth=2.5 setupCost=4.1 ownOngoingCost=4300 rentAmount=2520 rentOngoingCost=200
  london/house-2br: Rumah tapak 2 kamar tidur. propertyPrice=485000 houseGrowth=3.5 setupCost=3.79 ownOngoingCost=1950 rentAmount=2000 rentOngoingCost=200
  london/house-4br: Rumah tapak 4 kamar tidur. propertyPrice=820000 houseGrowth=3.5 setupCost=4.33 ownOngoingCost=3150 rentAmount=3200 rentOngoingCost=250
zurich: Zurich, Swiss (CHF, figures as of 2026-08). qs=zurich alone loads zurich/apt-2br.
  Sets: currencySymbol=CHF downPaymentPct=20 mortgageRate=1.71 mortgageTerm=30 houseGrowth=3 sellingCostPct=2.6 ownOngoingInflation=1 rentFreq=monthly rentInflation=2 rentOngoingInflation=1 riskFreeRate=0.5 horizon=30
  Loan: a staged loan, so it opens in the Detailed mortgage mode with the rate schedule fixed 2.03% to year 10, then floating 1.08 to 2.03% to year 30 (mortgageRate, its average, is then not used).
  zurich/apt-studio: Apartemen studio. propertyPrice=690000 setupCost=0.31 ownOngoingCost=2160 rentAmount=1450 rentOngoingCost=200
  zurich/apt-1br: Apartemen 1 kamar tidur. propertyPrice=1200000 setupCost=0.3 ownOngoingCost=3570 rentAmount=2200 rentOngoingCost=250
  zurich/apt-2br: Apartemen 2 kamar tidur. propertyPrice=1550000 setupCost=0.29 ownOngoingCost=4550 rentAmount=2530 rentOngoingCost=300
  zurich/apt-4br: Apartemen 4 kamar tidur. propertyPrice=2100000 setupCost=0.28 ownOngoingCost=6700 rentAmount=3450 rentOngoingCost=400
  zurich/house-4br: Rumah tapak 4 kamar tidur. propertyPrice=1750000 setupCost=0.29 ownOngoingCost=7900 rentAmount=3450 rentOngoingCost=450
paris: Paris, Prancis (EUR, figures as of 2026-09). qs=paris alone loads paris/apt-2br.
  Sets: currencySymbol=€ downPaymentPct=20 mortgageRate=3.5 mortgageTerm=25 sellingCostPct=4 ownOngoingInflation=2 rentFreq=monthly rentInflation=2 rentOngoingInflation=2 riskFreeRate=2.4 horizon=25
  paris/apt-studio: Apartemen studio. propertyPrice=240000 houseGrowth=2 setupCost=8.38 ownOngoingCost=2080 rentAmount=850 rentOngoingCost=250
  paris/apt-1br: Apartemen 1 kamar tidur. propertyPrice=390000 houseGrowth=2 setupCost=7.95 ownOngoingCost=3380 rentAmount=1250 rentOngoingCost=300
  paris/apt-2br: Apartemen 2 kamar tidur. propertyPrice=585000 houseGrowth=2 setupCost=7.72 ownOngoingCost=5070 rentAmount=1750 rentOngoingCost=400
  paris/apt-4br: Apartemen 4 kamar tidur. propertyPrice=1150000 houseGrowth=2 setupCost=7.5 ownOngoingCost=9300 rentAmount=3100 rentOngoingCost=650
  paris/house-2br: Rumah tapak 2 kamar tidur. propertyPrice=370000 houseGrowth=1.5 setupCost=7.99 ownOngoingCost=3540 rentAmount=1450 rentOngoingCost=450
  paris/house-4br: Rumah tapak 4 kamar tidur. propertyPrice=700000 houseGrowth=1.5 setupCost=7.65 ownOngoingCost=6300 rentAmount=2600 rentOngoingCost=600
berlin: Berlin, Jerman (EUR, figures as of 2026-10). qs=berlin alone loads berlin/apt-2br.
  Sets: currencySymbol=€ downPaymentPct=20 mortgageRate=4.3 mortgageTerm=30 sellingCostPct=3.6 setupCost=11.57 ownOngoingInflation=2 rentFreq=monthly rentInflation=2.5 rentOngoingInflation=2 riskFreeRate=2.5 horizon=30
  Loan: a staged loan, so it opens in the Detailed mortgage mode with the rate schedule fixed 4.35% to year 10, then floating 4.04 to 4.52% to year 30 (mortgageRate, its average, is then not used).
  berlin/apt-studio: Apartemen studio. propertyPrice=220000 houseGrowth=2.5 ownOngoingCost=1300 rentAmount=720 rentOngoingCost=70
  berlin/apt-1br: Apartemen 1 kamar tidur. propertyPrice=340000 houseGrowth=2.5 ownOngoingCost=1800 rentAmount=1000 rentOngoingCost=90
  berlin/apt-2br: Apartemen 2 kamar tidur. propertyPrice=490000 houseGrowth=2.5 ownOngoingCost=2300 rentAmount=1400 rentOngoingCost=110
  berlin/apt-4br: Apartemen 4 kamar tidur. propertyPrice=990000 houseGrowth=2.5 ownOngoingCost=3900 rentAmount=2600 rentOngoingCost=160
  berlin/house-4br: Rumah tapak 4 kamar tidur. propertyPrice=620000 houseGrowth=2 ownOngoingCost=3050 rentAmount=1950 rentOngoingCost=160
amsterdam: Amsterdam, Belanda (EUR, figures as of 2026-10). qs=amsterdam alone loads amsterdam/apt-2br.
  Sets: currencySymbol=€ downPaymentPct=10 mortgageRate=4.7 mortgageTerm=30 houseGrowth=3 sellingCostPct=1.6 ownOngoingInflation=2.5 rentFreq=monthly rentInflation=3 rentOngoingInflation=2.5 riskFreeRate=2.5 horizon=30
  amsterdam/apt-studio: Apartemen studio. propertyPrice=330000 setupCost=3.73 ownOngoingCost=2050 rentAmount=950 rentOngoingCost=120
  amsterdam/apt-1br: Apartemen 1 kamar tidur. propertyPrice=495000 setupCost=3.15 ownOngoingCost=2950 rentAmount=1500 rentOngoingCost=150
  amsterdam/apt-2br: Apartemen 2 kamar tidur. propertyPrice=650000 setupCost=2.9 ownOngoingCost=3900 rentAmount=1950 rentOngoingCost=180
  amsterdam/apt-4br: Apartemen 4 kamar tidur. propertyPrice=1170000 setupCost=2.57 ownOngoingCost=6250 rentAmount=3100 rentOngoingCost=250
  amsterdam/house-4br: Rumah tapak 4 kamar tidur. propertyPrice=750000 setupCost=2.85 ownOngoingCost=4550 rentAmount=2500 rentOngoingCost=250
losangeles: Los Angeles, Amerika Serikat (USD, figures as of 2026-10). qs=losangeles alone loads losangeles/apt-2br.
  Sets: currencySymbol=$ downPaymentPct=20 mortgageRate=7.4 mortgageTerm=30 sellingCostPct=6.3 ownOngoingInflation=2.5 rentFreq=monthly rentInflation=3 rentOngoingCost=270 rentOngoingInflation=2.5 riskFreeRate=4 horizon=30
  losangeles/apt-studio: Apartemen studio. propertyPrice=380000 houseGrowth=3 setupCost=1.36 ownOngoingCost=10763 rentAmount=1800
  losangeles/apt-1br: Apartemen 1 kamar tidur. propertyPrice=500000 houseGrowth=3 setupCost=1.08 ownOngoingCost=13615 rentAmount=2250
  losangeles/apt-2br: Apartemen 2 kamar tidur. propertyPrice=730000 houseGrowth=3 setupCost=0.79 ownOngoingCost=18598 rentAmount=3000
  losangeles/house-2br: Rumah tapak 2 kamar tidur. propertyPrice=800000 houseGrowth=4 setupCost=0.7 ownOngoingCost=16145 rentAmount=3300
  losangeles/house-4br: Rumah tapak 4 kamar tidur. propertyPrice=1050000 houseGrowth=4 setupCost=0.58 ownOngoingCost=21970 rentAmount=4800
sanfrancisco: San Francisco, Amerika Serikat (USD, figures as of 2026-10). qs=sanfrancisco alone loads sanfrancisco/apt-2br.
  Sets: currencySymbol=$ downPaymentPct=20 mortgageRate=7.4 mortgageTerm=30 sellingCostPct=6.1 ownOngoingInflation=2.5 rentFreq=monthly rentInflation=3.5 rentOngoingCost=250 rentOngoingInflation=2.5 riskFreeRate=4 horizon=30
  sanfrancisco/apt-studio: Apartemen studio. propertyPrice=570000 houseGrowth=2.5 setupCost=1.33 ownOngoingCost=15259 rentAmount=2900
  sanfrancisco/apt-1br: Apartemen 1 kamar tidur. propertyPrice=830000 houseGrowth=2.5 setupCost=1.02 ownOngoingCost=20384 rentAmount=4300
  sanfrancisco/apt-2br: Apartemen 2 kamar tidur. propertyPrice=1250000 houseGrowth=2.5 setupCost=0.8 ownOngoingCost=28851 rentAmount=6200
  sanfrancisco/house-2br: Rumah tapak 2 kamar tidur. propertyPrice=1350000 houseGrowth=3.5 setupCost=0.75 ownOngoingCost=23283 rentAmount=5000
  sanfrancisco/house-4br: Rumah tapak 4 kamar tidur. propertyPrice=2100000 houseGrowth=3.5 setupCost=0.61 ownOngoingCost=34954 rentAmount=8500
houston: Houston, Amerika Serikat (USD, figures as of 2026-10). qs=houston alone loads houston/apt-2br.
  Sets: currencySymbol=$ downPaymentPct=20 mortgageRate=7.4 mortgageTerm=30 sellingCostPct=6.4 ownOngoingInflation=3 rentFreq=monthly rentInflation=2.8 rentOngoingCost=340 rentOngoingInflation=2.5 riskFreeRate=4 horizon=30
  houston/apt-1br: Apartemen 1 kamar tidur. propertyPrice=195000 houseGrowth=2 setupCost=2.36 ownOngoingCost=10534 rentAmount=1300
  houston/apt-2br: Apartemen 2 kamar tidur. propertyPrice=300000 houseGrowth=2 setupCost=1.53 ownOngoingCost=16533 rentAmount=1900
  houston/house-2br: Rumah tapak 2 kamar tidur. propertyPrice=230000 houseGrowth=3.5 setupCost=2.11 ownOngoingCost=9201 rentAmount=1350
  houston/house-4br: Rumah tapak 4 kamar tidur. propertyPrice=340000 houseGrowth=3.5 setupCost=1.51 ownOngoingCost=14194 rentAmount=2400
newyork: New York, Amerika Serikat (USD, figures as of 2026-09). qs=newyork alone loads newyork/apt-2br.
  Sets: currencySymbol=$ mortgageRate=7.4 mortgageTerm=30 ownOngoingInflation=3 rentFreq=monthly rentInflation=3 rentOngoingInflation=2.5 riskFreeRate=4 horizon=30
  newyork/apt-studio: Apartemen studio. propertyPrice=460000 downPaymentPct=20 houseGrowth=2 sellingCostPct=7.5 setupCost=1.84 ownOngoingCost=13900 rentAmount=3450 rentOngoingCost=250
  newyork/apt-1br: Apartemen 1 kamar tidur. propertyPrice=695000 downPaymentPct=20 houseGrowth=2 sellingCostPct=7.5 setupCost=1.36 ownOngoingCost=22100 rentAmount=4400 rentOngoingCost=250
  newyork/apt-2br: Apartemen 2 kamar tidur. propertyPrice=1380000 downPaymentPct=20 houseGrowth=2 sellingCostPct=7.5 setupCost=1.76 ownOngoingCost=34000 rentAmount=6000 rentOngoingCost=300
  newyork/apt-4br: Apartemen 4 kamar tidur. propertyPrice=4000000 downPaymentPct=30 houseGrowth=2 sellingCostPct=7.5 setupCost=1.87 ownOngoingCost=89000 rentAmount=15000 rentOngoingCost=500
  newyork/house-2br: Rumah tapak 2 kamar tidur. propertyPrice=570000 downPaymentPct=20 houseGrowth=3.5 sellingCostPct=7 setupCost=3.19 ownOngoingCost=9900 rentAmount=2900 rentOngoingCost=250
  newyork/house-4br: Rumah tapak 4 kamar tidur. propertyPrice=950000 downPaymentPct=20 houseGrowth=3.5 sellingCostPct=7 setupCost=2.85 ownOngoingCost=15600 rentAmount=4000 rentOngoingCost=300
chicago: Chicago, Amerika Serikat (USD, figures as of 2026-09). qs=chicago alone loads chicago/apt-2br.
  Sets: currencySymbol=$ downPaymentPct=20 mortgageRate=7.4 mortgageTerm=30 sellingCostPct=6 ownOngoingInflation=3 rentFreq=monthly rentInflation=3 rentOngoingCost=360 rentOngoingInflation=2.5 riskFreeRate=4 horizon=30
  chicago/apt-studio: Apartemen studio. propertyPrice=195000 houseGrowth=1.5 setupCost=3.16 ownOngoingCost=7500 rentAmount=1600
  chicago/apt-1br: Apartemen 1 kamar tidur. propertyPrice=290000 houseGrowth=1.5 setupCost=2.58 ownOngoingCost=11400 rentAmount=2250
  chicago/apt-2br: Apartemen 2 kamar tidur. propertyPrice=480000 houseGrowth=1.5 setupCost=2.02 ownOngoingCost=18400 rentAmount=3200
  chicago/house-2br: Rumah tapak 2 kamar tidur. propertyPrice=320000 houseGrowth=3 setupCost=2.64 ownOngoingCost=9000 rentAmount=2050
  chicago/house-4br: Rumah tapak 4 kamar tidur. propertyPrice=490000 houseGrowth=3 setupCost=2.11 ownOngoingCost=13800 rentAmount=3300
toronto: Toronto, Kanada (CAD, figures as of 2026-09). qs=toronto alone loads toronto/apt-2br.
  Sets: currencySymbol=$ downPaymentPct=20 mortgageRate=5.13 mortgageTerm=30 sellingCostPct=5 ownOngoingInflation=2.5 rentFreq=monthly rentInflation=3 rentOngoingInflation=2 riskFreeRate=3 horizon=30
  Loan: a staged loan, so it opens in the Detailed mortgage mode with the rate schedule fixed 5.25% to year 5, then floating 4.9 to 5.3% to year 30 (mortgageRate, its average, is then not used).
  toronto/apt-studio: Apartemen studio. propertyPrice=345000 houseGrowth=3 setupCost=2.93 ownOngoingCost=7000 rentAmount=1890 rentOngoingCost=300
  toronto/apt-1br: Apartemen 1 kamar tidur. propertyPrice=510000 houseGrowth=3 setupCost=3.17 ownOngoingCost=10300 rentAmount=2380 rentOngoingCost=300
  toronto/apt-2br: Apartemen 2 kamar tidur. propertyPrice=760000 houseGrowth=3 setupCost=3.44 ownOngoingCost=14600 rentAmount=3320 rentOngoingCost=300
  toronto/house-2br: Rumah tapak 2 kamar tidur. propertyPrice=1000000 houseGrowth=3.5 setupCost=3.65 ownOngoingCost=11300 rentAmount=3200 rentOngoingCost=350
  toronto/house-4br: Rumah tapak 4 kamar tidur. propertyPrice=1300000 houseGrowth=3.5 setupCost=3.73 ownOngoingCost=15000 rentAmount=4500 rentOngoingCost=350
vancouver: Vancouver, Kanada (CAD, figures as of 2026-09). qs=vancouver alone loads vancouver/apt-2br.
  Sets: currencySymbol=$ downPaymentPct=20 mortgageRate=5.13 mortgageTerm=30 sellingCostPct=3.5 ownOngoingInflation=2.5 rentFreq=monthly rentInflation=3 rentOngoingInflation=2 riskFreeRate=3 horizon=30
  Loan: a staged loan, so it opens in the Detailed mortgage mode with the rate schedule fixed 5.25% to year 5, then floating 4.9 to 5.3% to year 30 (mortgageRate, its average, is then not used).
  vancouver/apt-studio: Apartemen studio. propertyPrice=450000 houseGrowth=3 setupCost=2.16 ownOngoingCost=4700 rentAmount=2035 rentOngoingCost=300
  vancouver/apt-1br: Apartemen 1 kamar tidur. propertyPrice=650000 houseGrowth=3 setupCost=2.11 ownOngoingCost=6800 rentAmount=2400 rentOngoingCost=300
  vancouver/apt-2br: Apartemen 2 kamar tidur. propertyPrice=950000 houseGrowth=3 setupCost=2.07 ownOngoingCost=9900 rentAmount=3300 rentOngoingCost=300
  vancouver/house-4br: Rumah tapak 4 kamar tidur. propertyPrice=1650000 houseGrowth=3.5 setupCost=2.08 ownOngoingCost=11500 rentAmount=5000 rentOngoingCost=350

Generated by _ref/agent-doc.mjs from the page and its agent-notes.md.
