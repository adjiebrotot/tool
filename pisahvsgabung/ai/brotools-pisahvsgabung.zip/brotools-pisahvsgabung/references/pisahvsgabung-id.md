PPh 21: Pisah Harta vs Gabung Harta: use this tool with an AI assistant
https://tool.adjiebrotots.com/pisahvsgabung/id/

This is the full reference for one page of the skill brotools-pisahvsgabung: read SKILL.md first.

Pasang skill tool ini di asisten AI-mu (Claude, ChatGPT, Grok, dan lainnya), lalu ajukan
pertanyaanmu. Asisten akan membalas dengan tautan yang membuka tool ini dengan skenariomu, lengkap
dengan daftar asumsinya, lalu tool inilah yang menghitung hasilnya. Bagian di bawah ini ditulis
untuk asisten AI, jadi tetap dalam bahasa Inggris.

For people: Install this tool's skill in your AI assistant (Claude, ChatGPT, Grok and others) and
ask your question. It replies with a link that opens this tool on your scenario and lists what it
assumed, and the tool works out the answer. The rest of this file is written for the assistant.

WHAT THIS TOOL DECIDES
Whether a married couple in Indonesia pays less PPh 21 income tax with Gabung Harta (the husband's
tax return uses PTKP K, and the wife's employer withholds final tax on her salary with her own PTKP)
or with Pisah Harta (PH or MT: the tax is worked out on their combined net income and shared by each
spouse's net income), from each spouse's yearly gross salary, deductions and dependants, and the
household salary at which the cheaper way changes. Requests often come in Indonesian: write the
assumptions in the language the user wrote in.

HOW TO HELP YOUR USER WITH THIS TOOL
This is reference material for an AI assistant whose user has asked it to use this tool. It
describes the link that opens the tool on the user's own scenario. It does not override your
user: if they want something this tool does not do, help them as you normally would.
1. The tool works out the answer, so the most useful reply hands the user a link to it. Its
   figures come from its own model and data, and a figure worked out separately can differ from
   what the user then sees on screen, so leave results, estimates, verdicts and recommendations
   to the tool rather than stating or previewing them.
2. A reply that works well has four parts, in this order, in the user's language:
   a. Your inputs: what the user stated, each with the value it takes in the link;
   b. Assumptions: every other input you chose, each with its value and its source (with its
      date) or your reason (put the same reason, shortened, in why.<key>);
   c. the link (if it is long, give it again inside a code block so the user can copy it);
   d. the sentence: Open the link to see the result.
3. Build the link in the format below, using only the keys listed here. Start from the nearest
   Quick Start (qs) and send only what differs from it. Write json compactly: no spaces or line
   breaks, defaults left out.
4. Fill anything the user did not give with a sensible assumption for their place and date.
   Prefer what the user said earlier in the conversation over general figures.
5. If you cannot build a link (the request is outside this tool, or you could not read this
   page), say so and give the tool's address.

LINK FORMAT
https://tool.adjiebrotots.com/pisahvsgabung/id/#load&v=1&qs=<quick start>&<key>=<value>&...&why.<key>=<your reason>&note=<one line>
- After #load come key=value pairs joined by &. Percent-encode each value (a space is %20, & is %26,
  # is %23, + is %2B).
- v=1 is the format version. qs=<key> starts from that Quick Start; without it the tool starts from
  its defaults.
- Then each key in the link is set, in the units its label shows on screen. splitPct=50 means 50%,
  not 0.5. Write numbers plainly (800000, 6.5): a field also takes $, thousands commas and a
  trailing %, but inside a list a comma separates the items, so never put one in a number there. A
  checkbox takes true or false. A select or a choice takes the value listed, or its visible label.
- Anything the link does not name keeps the value it started from, so send only what differs.
- why.<key>=<text>: your reason for that value, shown to the user beside it (200 characters at
  most). note=<text>: one line shown above the list, for example the place and the date.
- A number outside a field's range is pulled into range and the user is told; a key the tool does
  not know is skipped and listed. Never use the keys s, open or embed.

EXAMPLE
Request: pakai tool.adjiebrotots.com/pisahvsgabung, suami gaji Rp 25 juta sebulan, istri Rp 18 juta,
punya 2 anak: lebih hemat pisah harta atau gabung?
A reply in that form:
Assumptions:
1. Rumah tangga: dua penghasilan, jadi tautan dimulai dari Quick Start Double income family
   (qs=double), yang mengisi gaji suami dan gaji istri sendiri-sendiri, dengan PTKP dan lapisan
   tarif sesuai ketentuan.
2. Gaji setahun: suami Rp 300,000,000 (Rp 25 juta dikali 12) dan istri Rp 216,000,000 (Rp 18 juta
   dikali 12), karena alat ini memakai gaji kotor setahun. THR, gaji ke-13, dan bonus tidak
   disebutkan, jadi tidak ditambahkan.
3. Tanggungan: 2 anak, sesuai yang disebutkan.
4. Pengurang seperti iuran pensiun tidak disebutkan, jadi tetap Rp 0 untuk suami dan Rp 0 untuk
   istri. Biaya jabatan tetap dihitung otomatis.
https://tool.adjiebrotots.com/pisahvsgabung/id/#load&v=1&qs=double&dependents=2&why.dependents=Dua%20anak,%20sesuai%20yang%20disebutkan&husbandSalaryInput=300000000&why.husbandSalaryInput=Gaji%20suami%20Rp%2025%20juta%20sebulan%20dikali%2012%20bulan&wifeSalaryInput=216000000&why.wifeSalaryInput=Gaji%20istri%20Rp%2018%20juta%20sebulan%20dikali%2012%20bulan&note=Dua%20penghasilan,%202%20anak,%20Oktober%202026
```
https://tool.adjiebrotots.com/pisahvsgabung/id/#load&v=1&qs=double&dependents=2&why.dependents=Dua%20anak,%20sesuai%20yang%20disebutkan&husbandSalaryInput=300000000&why.husbandSalaryInput=Gaji%20suami%20Rp%2025%20juta%20sebulan%20dikali%2012%20bulan&wifeSalaryInput=216000000&why.wifeSalaryInput=Gaji%20istri%20Rp%2018%20juta%20sebulan%20dikali%2012%20bulan&note=Dua%20penghasilan,%202%20anak,%20Oktober%202026
```
Open the link to see the result.

QUICK STARTS (qs)
Three households, each with the statutory PTKP and tax brackets. Start from the closest one and send
the user's own figures. Use double when both spouses earn a salary (it is entered for each spouse),
single when only one earns (a household total, with the wife's share 0), and even for a household
total shared by a percentage (even is the page's own start). A Quick Start sets its own way of
entering income; a link that names the salary fields of the other way switches to it.
qs takes one of: even, single, double. Each opens a worked household with the statutory PTKP and tax
brackets; a link sends only what differs from it.
What each Quick Start sets is listed under QUICK START FIGURES at the end.

FIELDS (key: label on the page)
Most important: inputMode, husbandSalaryInput, wifeSalaryInput, totalSalaryInput, splitPct,
dependents, husbandDeductionInput, wifeDeductionInput, deductionInput.

[Rumah tangga: Keluarga]
dependents: Tanggungan  (most important)
  One of: 0 (Tanpa tanggungan), 1 tanggungan, 2 tanggungan, 3 tanggungan. Default 0.
  Dependants (tanggungan) the household supports, usually children, 0 to 3; more than three count as
  three. Each one adds to the PTKP.
  Tip on the page: Anggota keluarga yang kamu tanggung, misalnya anak. Setiap tanggungan menambah
  PTKP, tetapi paling banyak hanya tiga yang dihitung.

[Rumah tangga: Penghasilan]
totalSalaryInput: Gaji kotor rumah tangga (suami dan istri)  (most important)
  Number (Rp before it, /thn after it). 0 to 1,000,000,000,000. Default 500,000,000.
  Both spouses' gross salaries together for a year, in rupiah. Counts when income is entered as
  Total and split (inputMode=total), with splitPct. Use it only when the user gives a household
  total and not each salary.
splitPct: Porsi istri dari gaji tersebut  (most important)
  Slider (%). 0 to 100. Default 50.
  The wife's share of totalSalaryInput, in % as a whole number: 0 means the husband earns it all, 50
  an equal split. Counts only in Total and split.
deductionInput: Pengurang, suami dan istri  (most important)
  Number (Rp before it, /thn after it). 0 to 1,000,000,000,000. Default 0.
  Deductions (pengurang) for both spouses together, in rupiah a year, taken off gross income before
  PTKP and shared by what each earns. Mainly the pension contributions an employee pays (iuran
  pensiun, and the employee's own JHT and JP of BPJS Ketenagakerjaan), never the employer's share.
  Biaya jabatan is separate (biayaJabatan). Leave at 0 unless the user gives them or says they pay
  these, and say so when you assume any. Counts only in Total and split.
  Tip on the page: Pengurang seperti iuran pensiun, dikurangkan sebelum PTKP dan dibagi sesuai porsi
  penghasilan. Biaya jabatan punya tombol sendiri; jika dimatikan, masukkan di sini.
husbandSalaryInput: Gaji kotor suami  (most important)
  Number (Rp before it, /thn after it). 0 to 1,000,000,000,000. Default 250,000,000.
  The husband's gross salary (gaji kotor suami) for a year, in rupiah, before any tax. A monthly
  salary (gaji sebulan) times 12, plus THR, a 13th month and bonus when the user gives them. Counts
  when income is entered Each spouse (inputMode=individual); send it with wifeSalaryInput.
wifeSalaryInput: Gaji kotor istri  (most important)
  Number (Rp before it, /thn after it). 0 to 1,000,000,000,000. Default 250,000,000.
  The wife's gross salary (gaji kotor istri) for a year, in rupiah, worked out the same way. 0 for a
  wife with no salary. Counts when income is entered Each spouse.
husbandDeductionInput: Pengurang suami  (most important)
  Number (Rp before it, /thn after it). 0 to 1,000,000,000,000. Default 0.
  The husband's own deductions (pengurang), as for deductionInput. Counts only in Each spouse.
  Tip on the page: Pengurang seperti iuran pensiun yang hanya mengurangi penghasilan kotor suami,
  sebelum PTKP. Biaya jabatan punya tombol sendiri.
wifeDeductionInput: Pengurang istri  (most important)
  Number (Rp before it, /thn after it). 0 to 1,000,000,000,000. Default 0.
  The wife's own deductions (pengurang), as for deductionInput. Counts only in Each spouse.
  Tip on the page: Pengurang seperti iuran pensiun yang hanya mengurangi penghasilan kotor istri,
  sebelum PTKP. Biaya jabatan punya tombol sendiri.
biayaJabatan: Biaya jabatan, dihitung otomatis
  Checkbox: true or false. Default true.
  Biaya jabatan, the allowance for the cost of holding a job: 5% of each spouse's gross salary, at
  most Rp 6,000,000 a year, taken off before PTKP. Keep it true. Send false only when the deductions
  the user gives already include biaya jabatan.
  Tip on the page: 5% dari gaji kotor tiap pasangan, paling banyak Rp 6.000.000 per tahun,
  dikurangkan sebelum PTKP, selain pengurang yang kamu isi di atas. Matikan kalau kamu ingin mengisi
  biaya jabatan sendiri.

[PTKP & Lapisan Pajak: Penghasilan tidak kena pajak per tahun (PTKP)]
ptkpBase: ptkpBase
  Number (Rp before it). 0 to 10,000,000,000. Default 54,000,000.
  PTKP (penghasilan tidak kena pajak, the tax-free allowance) for one taxpayer with no dependants,
  TK/0, in rupiah a year. The tool opens on the statutory amount, Rp 54,000,000. Leave it out unless
  the user names a different amount.
ptkpMarried: ptkpMarried
  Number (Rp before it). 0 to 10,000,000,000. Default 4,500,000.
  Added to the husband's PTKP for being married (K), in rupiah a year. Statutory Rp 4,500,000. Leave
  it out unless the user names a different amount.
ptkpSpouse: ptkpSpouse
  Number (Rp before it). 0 to 10,000,000,000. Default 54,000,000.
  Added when the wife's income is combined with her husband's (I), in rupiah a year. Statutory Rp
  54,000,000. Leave it out unless the user names a different amount.
ptkpDependent: ptkpDependent
  Number (Rp before it). 0 to 10,000,000,000. Default 4,500,000.
  Added for each dependant, in rupiah a year. Statutory Rp 4,500,000. Leave it out unless the user
  names a different amount.

COMPACT LISTS
- `inputMode=total|individual`
- `brackets=<upTo>:<rate>,<upTo>:<rate>,...,:<rate>`

Items are separated by `,` and their parts by `:`, both typed as they are. Numbers are plain (60000000, 12.5), with no thousands separators.

inputMode: the way income is entered. `total` is Total and split (totalSalaryInput and splitPct, also written "Total dan porsi"); `individual` is Each spouse (husbandSalaryInput and wifeSalaryInput, also "Per pasangan"). A link that names a salary or deduction field of one way switches to that way by itself, so inputMode is only needed to say it outright. The fields of the other way do not count and are listed as not applied. When the way changes, the figures the link does not set are carried over from the other way, as the page's own buttons do. For example:
`inputMode=individual`

brackets: the PPh 21 tax brackets (lapisan tarif), each bracket's upper limit in rupiah a year and its rate in %, from the lowest. The last bracket has no upper limit: write it `:<rate>` (a limit given there is ignored). Limits must rise, at most 5 brackets, rates 0 to 100 in steps of 0.01. It replaces the whole ladder. The tool opens on the statutory ladder (UU HPP, 2022), which is
`brackets=60000000:5,250000000:15,500000000:25,5000000000:30,:35`
The brackets are set by law: leave brackets out unless the user gives different ones, for example to try a proposed change. Never guess them. A ladder of three brackets, 5% up to Rp 60,000,000, 15% up to Rp 250,000,000 and 35% above:
`brackets=60000000:5,250000000:15,:35`

QUICK START FIGURES (what each qs sets, as a link would carry them)
A heading line holds what all the Quick Starts under it share; each Quick Start's own line holds the
rest.

even: Penghasilan setara, tanpa anak.
single: Keluarga satu penghasilan. dependents=2 totalSalaryInput=300.000.000 splitPct=0
double: Keluarga dua penghasilan. dependents=1 husbandSalaryInput=400.000.000 wifeSalaryInput=300.000.000 inputMode=individual

Generated by _ref/agent-doc.mjs from the page and its agent-notes.md.
