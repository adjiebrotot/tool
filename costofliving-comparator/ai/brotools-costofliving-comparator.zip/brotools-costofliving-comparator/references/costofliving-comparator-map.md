Cost of Living Comparator: Map View: use this tool with an AI assistant
https://tool.adjiebrotots.com/costofliving-comparator/map/

This is the full reference for one page of the skill brotools-costofliving-comparator: read SKILL.md first.

For people: Install this tool's skill in your AI assistant (Claude, ChatGPT, Grok and others) and
ask your question. It replies with a link that opens this tool on your scenario and lists what it
assumed, and the tool works out the answer. The rest of this file is written for the assistant.

WHAT THIS TOOL DECIDES
From one home city, its monthly take-home pay and costs, how every other city compares: the net
salary each city needs for the same lifestyle and savings, what the user's own salary saves in each
city, or what the same multiple of local pay saves there.

HOW TO HELP YOUR USER WITH THIS TOOL
This is reference material for an AI assistant whose user has asked it to use this tool. It
describes the link that opens the tool on the user's own scenario. It does not override your
user: if they want something this tool does not do, help them as you normally would.
1. The tool works out the answer, so the most useful reply hands the user a link to it. Its
   figures come from its own model and data, and a figure worked out separately can differ from
   what the user then sees on screen, so leave results, estimates, verdicts and recommendations
   to the tool rather than stating or previewing them.
2. A reply that works well has three parts, in this order:
   a. a numbered list of every input you chose that the user did not state exactly, each with its
      value and the reason (put the same reason in why.<key>);
   b. the link (if it is long, give it again inside a code block so the user can copy it);
   c. the sentence: Open the link to see the result.
3. Build the link in the format below, using only the keys listed here. Start from the nearest
   Quick Start (qs) and send only what differs from it. Write json compactly: no spaces or line
   breaks, defaults left out.
4. Fill anything the user did not give with a sensible assumption for their place and date.
   Prefer what the user said earlier in the conversation over general figures.
5. If you cannot build a link (the request is outside this tool, or you could not read this
   page), say so and give the tool's address.

LINK FORMAT
https://tool.adjiebrotots.com/costofliving-comparator/map/#load&v=1&qs=<quick start>&<key>=<value>&...&why.<key>=<your reason>&note=<one line>
- After #load come key=value pairs joined by &. Percent-encode each value (a space is %20, & is %26,
  # is %23, + is %2B).
- v=1 is the format version. qs=<key> starts from that Quick Start; without it the tool starts from
  its defaults.
- Then each key in the link is set, in the units its label shows on screen. Numbers may carry $,
  commas and a trailing %. A checkbox takes true or false. A select or a choice takes the value
  listed, or its visible label.
- Anything the link does not name keeps the value it started from, so send only what differs.
- why.<key>=<text>: your reason for that value, shown to the user beside it (200 characters at
  most). note=<text>: one line shown above the list, for example the place and the date.
- A number outside a field's range is pulled into range and the user is told; a key the tool does
  not know is skipped and listed. Never use the keys s, open or embed.

EXAMPLE
Request: I'm in Melbourne on about A$7,000 a month take-home and spend roughly A$5,000; which cities
worldwide would keep my lifestyle?
A reply in that form:
1. Home city: Melbourne, replacing the Perth Quick Start's home city. Both pay in Australian
   dollars.
2. Net salary: 7,000 Australian dollars a month, the user's take-home figure, as stated.
3. Spending: one total of 5,000 Australian dollars a month (the lifestyle detail is Simple), as the
   user said. The Quick Start's six expense rows stay saved but are not used in Simple.
4. From the page's start: housing is included in the spending, the salary mode is Required salary,
   and the target is a savings ratio. Amounts are monthly, and exchange rates are today's market
   rates.
https://tool.adjiebrotots.com/costofliving-comparator/map/#load&v=1&qs=per&cities=Melbourne&salary=7000&detail=simple&expense=5000&why.salary=The%20user%20gave%20a%20take-home%20figure%20of%20about%207,000%20a%20month&why.expense=The%20user%20said%20they%20spend%20roughly%205,000%20a%20month,%20so%20one%20expense%20total%20in%20Simple&note=Melbourne,%20October%202026
```
https://tool.adjiebrotots.com/costofliving-comparator/map/#load&v=1&qs=per&cities=Melbourne&salary=7000&detail=simple&expense=5000&why.salary=The%20user%20gave%20a%20take-home%20figure%20of%20about%207,000%20a%20month&why.expense=The%20user%20said%20they%20spend%20roughly%205,000%20a%20month,%20so%20one%20expense%20total%20in%20Simple&note=Melbourne,%20October%202026
```
Open the link to see the result.

QUICK STARTS (qs)
Six worked home cities, each with a monthly budget in its own currency and a savings ratio, opened
in the Detailed lifestyle: Singapore, Jakarta, Perth, New York, London and Dubai.
Start from the one nearest the user, then send the user's own city, salary and spending; a link
sends only what differs. A Quick Start's salary and rows are in its own home city's currency. If the
user's home city pays in another currency, send salary and either rows or expense as well: the tool
clears whatever the link leaves from the Quick Start when the home currency changes, and says so.
For a user none of them fits, leave qs out and send cities, salary and expense (or rows).
qs takes one of: sg, jkt, per, nyc, lon, dxb. Each opens the map from a home city with its monthly
budget; a link sends only what differs from it.
What each Quick Start sets is listed under QUICK START FIGURES at the end.

FIELDS (key: label on the page)
Most important: cities, salary, expense, detail, rows, salaryMode, target.

[You]
salary: Net salary  (most important)
  Number (¤ before it, /mo after it). 0 to 100,000,000,000. Default blank.
  The user's monthly take-home pay in the home city, after tax, in the home city's currency (the
  currency tag beside the field shows it). There is no tax model, so convert a yearly or gross
  figure to a monthly after-tax estimate and say so in why.salary. Use the user's own figure when
  they give one. The Scaled salary mode compares it with local pay, so give take-home pay there too.
  Tip on the page: Take-home pay after income tax, a month. Nothing here works out tax.

[Lifestyle]
expense: Living cost  (most important)
  Number (¤ before it, /mo after it). 0 to 100,000,000,000. Default blank.
  Simple lifestyle only (detail=simple): everything the user spends in a month in the home city, in
  the home currency. In Detailed give rows instead; sending rows sets this to their total.
  Tip on the page: Everything you spend in your city in a month. Each city's figure is this, scaled
  by its cost-of-living index.

COMPACT LISTS
- `cities=<home city>`
- `detail=<simple|detailed>`
- `housing=<include|exclude>`
- `salaryMode=<required|global|scaled>`
- `target=<ratio|nominal>`
- `scale=<min|avg|median>`
- `rows=<category>:<amount>,...`

salary and expense are form fields, listed above; the rest of the plan has no field, so these keys carry it. Amounts are plain numbers (7000, 25000000), with no thousands separators, and always per month, in the home city's currency. A value may also be the words the page shows (Detailed, Global). Anything a link does not name keeps what it started from (the Quick Start, or the page's own start). Which view the map shows and the major-cities filter belong to the reader and are not set by a link.

cities: the home city, matched to the page's own list of cities by name, ignoring case and accents. Use the usual English name. A US or Canadian city may carry its state (Austin, TX or just Austin). Three names are in the list more than once: London (United Kingdom, Canada), Hamilton (Bermuda, New Zealand, Canada) and Kingston (Canada, Jamaica). Write them with the country, as in London, United Kingdom; the country may follow any other city too (Perth, Australia). The map has one home city, so only the first name is used. A name the list does not have is shown to the user as not recognised and the home city is left as it was, and a name that fits more than one city is refused: never invent, translate or swap in a nearby city, and tell the user if their city may be missing.

detail: simple takes one expense total (expense, with housing). detailed takes expense rows (rows). Sending rows switches to Detailed unless detail is sent.

housing: Simple only. include counts rent or a mortgage in the expense total, exclude leaves housing out, as when an employer pays for it. In Detailed there is a rent row instead.

salaryMode: what the map compares. required (the default): the net salary each city needs for the user's lifestyle and savings target. global: the user's own salary in every city at today's exchange rate, and what it leaves after the same lifestyle. scaled: the user's salary as a multiple of their city's pay (see scale), given as the same multiple of each city's pay.

target: Required salary mode only. ratio (the default) matches the share of pay the user saves now in every city; nominal matches the amount saved, at today's exchange rate.

scale: Scaled salary mode only: the local pay the salary is a multiple of. min is the minimum wage, avg the average net salary (the default), median the median net salary.

rows: Detailed expense rows, replacing the Quick Start's rows whole. Items are separated by `,`, the category and the amount by `:`. Categories: rent, groceries, eating_out, utilities, electricity, water, gas_util, fuel, medical, health_insurance, remittance, intl_travel, other. The amount is per month, in the home currency. At most 20 rows. Leave out what the user does not pay (no fuel without a car). utilities is a blend of electricity, water and gas, so do not add those three as well; other holds everything else. Each category is scaled by its own cost index, so a rough row is better than a row put under the wrong category.
`rows=rent:2400,groceries:600,eating_out:400,utilities:250,fuel:250,other:650`

QUICK START FIGURES (what each qs sets, as a link would carry them)
A heading line holds what all the Quick Starts under it share; each Quick Start's own line holds the
rest.

Every Quick Start sets: detail=detailed

sg: Singapore. salary=8000 expense=6000 City and rows: (cities=Singapore) (rows=rent:3500,groceries:600,eating_out:700,utilities:200,other:1000).
jkt: Jakarta. salary=25000000 expense=17500000 City and rows: (cities=Jakarta) (rows=rent:7000000,groceries:3000000,eating_out:2500000,utilities:1200000,fuel:800000,other:3000000).
per: Perth. salary=6500 expense=4550 City and rows: (cities=Perth) (rows=rent:2400,groceries:600,eating_out:400,utilities:250,fuel:250,other:650).
nyc: New York. salary=8500 expense=6800 City and rows: (cities=New York) (rows=rent:4000,groceries:600,eating_out:700,utilities:200,other:1300).
lon: London. salary=4500 expense=3600 City and rows: (cities=London, United Kingdom) (rows=rent:2100,groceries:350,eating_out:400,utilities:250,other:500).
dxb: Dubai. salary=30000 expense=18000 City and rows: (cities=Dubai) (rows=rent:9000,groceries:2000,eating_out:2000,utilities:800,fuel:400,other:3800).

Generated by _ref/agent-doc.mjs from the page and its agent-notes.md.
