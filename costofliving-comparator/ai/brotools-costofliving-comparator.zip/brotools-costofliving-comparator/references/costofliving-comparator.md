Cost of Living Comparator: use this tool with an AI assistant
https://tool.adjiebrotots.com/costofliving-comparator/

This is the full reference for one page of the skill brotools-costofliving-comparator: read SKILL.md first.

For people: Install this tool's skill in your AI assistant (Claude, ChatGPT, Grok and others) and
ask your question. It replies with a link that opens this tool on your scenario and lists what it
assumed, and the tool works out the answer. The rest of this file is written for the assistant.

WHAT THIS TOOL DECIDES
How far a salary goes when the user moves between cities: from the user's home city, its monthly
take-home pay and costs, either what they would save in each destination city, or the net salary
each destination needs to leave them saving the same share of pay (or the same amount).

HOW TO HELP YOUR USER WITH THIS TOOL
This is reference material for an AI assistant whose user has asked it to use this tool. It
describes the link that opens the tool on the user's own scenario. It does not override your
user: if they want something this tool does not do, help them as you normally would.
1. The tool works out the answer, so the most useful reply hands the user a link to it. Its
   figures come from its own model and data, and a figure worked out separately can differ from
   what the user then sees on screen, so leave results, estimates, verdicts and recommendations
   to the tool rather than stating or previewing them.
2. A reply that works well has four parts, in this order, in the user's language:
   a. Your inputs: what the user stated, each with the value it takes in the link;
   b. Assumptions: every other input you chose, each with its value and its source (with its
      date) or your reason (put the same reason, shortened, in why.<key>);
   c. the link (if it is long, give it again inside a code block so the user can copy it);
   d. the sentence: Open the link to see the result.
3. Build the link in the format below, using only the keys listed here. Start from the nearest
   Quick Start (qs) and send only what differs from it. Write json compactly: no spaces or line
   breaks, defaults left out.
4. Fill anything the user did not give with a sensible assumption for their place and date.
   Prefer what the user said earlier in the conversation over general figures.
5. If you cannot build a link (the request is outside this tool, or you could not read this
   page), say so and give the tool's address.

LINK FORMAT
https://tool.adjiebrotots.com/costofliving-comparator/#load&v=1&qs=<quick start>&<key>=<value>&...&why.<key>=<your reason>&note=<one line>
- After #load come key=value pairs joined by &. Percent-encode each value (a space is %20, & is %26,
  # is %23, + is %2B).
- v=1 is the format version. qs=<key> starts from that Quick Start; without it the tool starts from
  its defaults.
- Then each key in the link is set, in the units its label shows on screen. Write numbers plainly
  (800000, 6.5): a field also takes $, thousands commas and a trailing %, but inside a list a comma
  separates the items, so never put one in a number there. A checkbox takes true or false. A select
  or a choice takes the value listed, or its visible label.
- Anything the link does not name keeps the value it started from, so send only what differs.
- why.<key>=<text>: your reason for that value, shown to the user beside it (200 characters at
  most). note=<text>: one line shown above the list, for example the place and the date.
- A number outside a field's range is pulled into range and the user is told; a key the tool does
  not know is skipped and listed. Never use the keys s, open or embed.

EXAMPLE
Request: I earn A$110,000 in Melbourne and got an offer in Singapore; what salary keeps my
lifestyle?
A reply in that form:
Assumptions:
1. Net salary: 7,000 Australian dollars a month. The user gave 110,000 a year before tax, and the
   tool does no tax, so this is an estimate of take-home pay after income tax and Medicare.
2. Expenses: rent 2,400, groceries 700, eating out 500, utilities 250 and other 1,300 a month, 5,150
   in all, in Australian dollars. The user did not say what they spend, so this is a typical budget
   for one person renting in Melbourne. It replaces the Quick Start's Singapore dollar rows.
3. Cities: Melbourne is the home city and Singapore the destination, replacing the Quick Start's
   Singapore and Australian cities.
4. From the Quick Start: the goal is I need to earn, and the target is a savings ratio. Housing is
   included in the rows. Amounts are monthly, and exchange rates are today's market rates.
https://tool.adjiebrotots.com/costofliving-comparator/#load&v=1&qs=sg-au&cities=Melbourne,Singapore&salary=7000&why.salary=A$110,000%20a%20year%20is%20about%20A$85,000%20after%20tax%20and%20Medicare,%20so%20about%207,000%20a%20month.%20The%20user%20did%20not%20give%20a%20take-home%20figure&rows=rent:2400,groceries:700,eating_out:500,utilities:250,other:1300&why.rows=The%20user%20did%20not%20say%20what%20they%20spend,%20so%20a%20typical%20monthly%20budget%20for%20one%20person%20renting%20in%20Melbourne&note=Melbourne%20to%20Singapore,%20October%202026
```
https://tool.adjiebrotots.com/costofliving-comparator/#load&v=1&qs=sg-au&cities=Melbourne,Singapore&salary=7000&why.salary=A$110,000%20a%20year%20is%20about%20A$85,000%20after%20tax%20and%20Medicare,%20so%20about%207,000%20a%20month.%20The%20user%20did%20not%20give%20a%20take-home%20figure&rows=rent:2400,groceries:700,eating_out:500,utilities:250,other:1300&why.rows=The%20user%20did%20not%20say%20what%20they%20spend,%20so%20a%20typical%20monthly%20budget%20for%20one%20person%20renting%20in%20Melbourne&note=Melbourne%20to%20Singapore,%20October%202026
```
Open the link to see the result.

QUICK STARTS (qs)
Six worked comparisons, each opening the Detailed table on a home city and its regional peers, with
the goal set to I need to earn and the target a savings ratio: Singapore against four Australian
cities, Jakarta against Kuala Lumpur, Bangkok and Ho Chi Minh City, New York against three US
cities, London against Paris, Amsterdam and Berlin, Dubai against three Gulf cities, and Tokyo
against Seoul, Hong Kong and Shanghai.
Start from the one nearest the user's region, then send the user's own cities, salary and rows; a
link sends only what differs. A Quick Start's salary and rows are in its own home city's currency.
If the user's home city pays in another currency, send salary and rows as well: the tool clears
whatever the link leaves from the Quick Start when the home currency changes, and says so. For a
user none of them fits, leave qs out and send cities, salary and expense (Simple) or rows
(Detailed).
qs takes one of: sg-au, sea, us, eu, me, ea. Each opens the Detailed table on a home city and its
regional peers, with its monthly budget; a link sends only what differs from it.
What each Quick Start sets is listed under QUICK START FIGURES at the end.

FIELDS (key: label on the page)
Most important: cities, salary, rows, goal, detail, expense, toSalaries, freq.

COMPACT LISTS
- `cities=<home>,<destination>,<destination>,...`
- `detail=<simple|detailed>`
- `goal=<save|earn>`
- `housing=<include|exclude>`
- `target=<ratio|nominal>`
- `salary=<amount>`
- `expense=<amount>`
- `toSalaries=<amount>,<amount>,...`
- `rows=<category>:<amount>[:<unit>][:qty=<n>][:per=<period>][:to<N>=<amount>],...`
- `customFx=<rate>,<rate>,...`
- `fxShock=<percent>`
- `freq=<weekly|fortnightly|monthly|yearly>`
- `incomeFreq=<weekly|fortnightly|monthly|yearly>`
- `savingsFreq=<weekly|fortnightly|monthly|yearly>`

There are no form fields on this page, so every key is one of these. Amounts are plain numbers (7000, 25000000), with no thousands separators, and per month unless the link names a frequency (freq, incomeFreq, savingsFreq or a row's unit: see freq). All amounts are take-home pay and costs in a city's own currency. A value may also be the words the page shows (I need to earn, Detailed). Anything a link does not name keeps what it started from (the Quick Start, or the page's own start).

cities: the home city first, then up to 8 destinations, matched to the page's own list of cities by name, ignoring case and accents. Use the usual English name. A US or Canadian city may carry its state (Austin, TX or just Austin). Three names are in the list more than once: London (United Kingdom, Canada), Hamilton (Bermuda, New Zealand, Canada) and Kingston (Canada, Jamaica). Write them with the country, as in London, United Kingdom; the country may follow any other city too (Perth, Australia). Separate cities with commas, or with semicolons when you write each as City, Country. A name the list does not have is shown to the user as not recognised and left out, and a name that fits more than one city is refused: never invent, translate or swap in a nearby city, and tell the user if their city may be missing. A destination that matched nothing keeps its place for toSalaries, customFx and rows. Simple mode compares the home city with the first destination only. Sending cities fills both modes, so the same cities show if the reader switches the Detail setting.

detail: simple compares two cities on one salary and one expense total. detailed is a table of expense rows across any number of destinations. Left out, the tool is in Detailed when it started from a Quick Start, and a link that sends rows or more than one destination switches to Detailed; otherwise it is Simple.

goal: save shows what the user would save in each destination at the destination salary they give (toSalaries). earn shows the net salary each destination needs for the target. Use earn for a user who asks what salary to ask for or accept. The Quick Starts use earn.

housing: Simple mode only. include counts rent or a mortgage in the expense total, exclude leaves housing out, as when an employer pays for it. Detailed mode has a rent row instead.

target: what each destination's salary is matched to. ratio saves the same share of pay as the home city does (the default). nominal saves the same amount, at today's exchange rate.

salary: the user's monthly take-home pay in the home city, after tax, in the home city's currency. There is no tax model, so convert a gross figure to an after-tax estimate and say so in why.salary. A weekly, fortnightly or yearly take-home figure can be sent as it is with freq or incomeFreq. Use the user's own figure when they give one.

expense: Simple mode only: everything the user spends in a month in the home city, in the home currency. In Detailed mode give rows instead (a link naming expense there is told it is not used).

toSalaries: the net monthly salary the user is offered in each destination, in that destination's currency, in the order the destinations are listed in cities. Used by goal=save; send it only when the user has an offer or a salary in mind. A blank item skips that destination: toSalaries=,5200 sets the second only.

rows: Detailed expense rows, replacing the Quick Start's rows whole. Items are separated by `,`, the category and the amount by `:`. Categories: rent, groceries, eating_out, utilities, electricity, water, gas_util, fuel, medical, health_insurance, remittance, intl_travel, other. The amount is per month (or in the row's unit: see freq), in the home currency. At most 20 rows. Leave out what the user does not pay (no fuel without a car). utilities is a blend of electricity, water and gas, so do not add those three as well; other holds everything else. Each category is scaled by its own cost index, so a rough row is better than a row put under the wrong category.
`rows=rent:2400,groceries:700,eating_out:500,other:1300`
Optionally, after the amount, a unit and `qty=` / `per=` (see freq), and `to<N>=<amount>`: what destination N already costs for that row, in that destination's currency, where N is its place after the home city in cities (1 is the first destination). It replaces the tool's estimate for that cell; send it only when the user knows the figure.
`rows=rent:2400:to1=3800,groceries:700`

customFx: a custom exchange rate for each destination, in the order of cities: how many home-currency units one unit of the destination currency buys, so customFx=,0.9 sets the second destination only. Leave it out unless the user names a rate; the tool uses today's market rate.

fxShock: Simple mode: a what-if move in the destination currency's strength against the home currency, as a percent from -20 to 20. Leave it out unless the user asks for a currency scenario.

freq: the custom frequency, which is Detailed only. Naming freq, incomeFreq, savingsFreq or a row's unit turns it on; leave them all out and every amount is monthly. Periods are weekly, fortnightly, monthly and yearly (week, fortnight, month, year and annual also work). freq is the period of the salary, toSalaries and every row that names no unit of its own, so weekly amounts need only `freq=weekly`. Send amounts in that period, never converted: salary=1850 with freq=weekly is 1,850 a week. Any amount the link leaves out keeps its value and is shown in the new period. A link with detail=simple and a frequency is told the frequency is not used.
`freq=weekly` with `salary=1850` and `rows=rent:800,groceries:140`

incomeFreq: the period of salary and toSalaries when it differs from the rows, as in a yearly salary with monthly rent: `incomeFreq=yearly` with `freq=monthly`. Without it, they follow freq.

savingsFreq: the period the savings answer is shown in. Without it, it follows incomeFreq (or freq), and stays monthly when the link names neither.

A row's unit, after its amount: a period, or a unit price for its category: meal (eating_out), kwh (electricity), litre or gallon (fuel), trip (intl_travel). With a unit price the amount is the price of one, `qty=<n>` is how many, and `per=<period>` is how often (the page's own start: 2 meals a week, 450 kWh a month, 75 litres a month, 2 trips a year). to<N> figures are in the row's own unit.
`rows=rent:200:weekly,eating_out:15:meal:qty=5:per=weekly,fuel:1.9:litre:qty=60`

QUICK START FIGURES (what each qs sets, as a link would carry them)
A heading line holds what all the Quick Starts under it share; each Quick Start's own line holds the
rest.

Every Quick Start sets: detail=detailed goal=earn target=ratio

sg-au: Singapore vs Australia. salary=8000 Cities and rows: (cities=Singapore,Sydney,Melbourne,Brisbane,Perth) (rows=rent:3500,groceries:600,eating_out:700,utilities:200,other:1000).
sea: Southeast Asia. salary=25000000 Cities and rows: (cities=Jakarta,Kuala Lumpur,Bangkok,Ho Chi Minh City) (rows=rent:7000000,groceries:3000000,eating_out:2500000,utilities:1200000,fuel:800000,other:3000000).
us: US cities. salary=8500 Cities and rows: (cities=New York,San Francisco,Seattle,Austin) (rows=rent:4000,groceries:600,eating_out:700,utilities:200,other:1300).
eu: European capitals. salary=4500 Cities and rows: (cities=London, United Kingdom,Paris,Amsterdam,Berlin) (rows=rent:2100,groceries:350,eating_out:400,utilities:250,other:500).
me: Middle East. salary=30000 Cities and rows: (cities=Dubai,Abu Dhabi,Doha,Riyadh) (rows=rent:9000,groceries:2000,eating_out:2000,utilities:800,fuel:400,other:3800).
ea: East Asia. salary=450000 Cities and rows: (cities=Tokyo,Seoul,Hong Kong,Shanghai) (rows=rent:140000,groceries:50000,eating_out:45000,utilities:15000,other:65000).

Generated by _ref/agent-doc.mjs from the page and its agent-notes.md.
