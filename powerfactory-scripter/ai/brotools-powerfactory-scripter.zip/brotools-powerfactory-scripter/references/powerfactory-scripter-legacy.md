PowerFactory Scripter: Legacy Form: use this tool with an AI assistant
https://tool.adjiebrotots.com/powerfactory-scripter/legacy/

This is the full reference for one page of the skill brotools-powerfactory-scripter: read SKILL.md first.

For people: Install this tool's skill in your AI assistant (Claude, ChatGPT, Grok and others) and
ask your question. It replies with a link that opens this tool on your scenario and lists what it
assumed, and the tool works out the answer. The rest of this file is written for the assistant.

WHAT THIS TOOL DECIDES
Which kind of PowerFactory study a Python script runs: a sweep of input values, an optimisation, a
run of scenarios from a file, or an outage screening (N-1 or N-2), in which study type (load flow,
RMS, EMT or harmonic) and with what options. The tool writes one ready-to-run script from the form,
and the user downloads it. It does not run PowerFactory or work out a study result. The script comes
from the tool, so a link to it gives the user the whole script.

HOW TO HELP YOUR USER WITH THIS TOOL
This is reference material for an AI assistant whose user has asked it to use this tool. It
describes the link that opens the tool on the user's own scenario. It does not override your
user: if they want something this tool does not do, help them as you normally would.
1. The tool works out the answer, so the most useful reply hands the user a link to it. Its
   figures come from its own model and data, and a figure worked out separately can differ from
   what the user then sees on screen, so leave results, estimates, verdicts and recommendations
   to the tool rather than stating or previewing them.
2. A reply that works well has three parts, in this order:
   a. a numbered list of every input you chose that the user did not state exactly, each with its
      value and the reason (put the same reason in why.<key>);
   b. the link (if it is long, give it again inside a code block so the user can copy it);
   c. the sentence: Open the link to see the result.
3. Build the link in the format below, using only the keys listed here. Start from the nearest
   Quick Start (qs) and send only what differs from it. Write json compactly: no spaces or line
   breaks, defaults left out.
4. Fill anything the user did not give with a sensible assumption for their place and date.
   Prefer what the user said earlier in the conversation over general figures.
5. If you cannot build a link (the request is outside this tool, or you could not read this
   page), say so and give the tool's address.

LINK FORMAT
https://tool.adjiebrotots.com/powerfactory-scripter/legacy/#load&v=1&qs=<quick start>&<key>=<value>&...&why.<key>=<your reason>&note=<one line>
- After #load come key=value pairs joined by &. Percent-encode each value (a space is %20, & is %26,
  # is %23, + is %2B).
- v=1 is the format version. qs=<key> starts from that Quick Start; without it the tool starts from
  its defaults.
- Then each key in the link is set, in the units its label shows on screen. Numbers may carry $,
  commas and a trailing %. A checkbox takes true or false. A select or a choice takes the value
  listed, or its visible label.
- Anything the link does not name keeps the value it started from, so send only what differs.
- why.<key>=<text>: your reason for that value, shown to the user beside it (200 characters at
  most). note=<text>: one line shown above the list, for example the place and the date.
- A number outside a field's range is pulled into range and the user is told; a key the tool does
  not know is skipped and listed. Never use the keys s, open or embed.

EXAMPLE
Request: using tool.adjiebrotots.com/powerfactory-scripter/legacy, write me a PowerFactory script
that finds the generator dispatch giving the lowest system losses, using differential evolution with
up to 100 tries, as a notebook
A reply in that form:
1. Study: the Minimum System Losses Quick Start (qs=sample-02-minimum-system-losses): an
   optimisation of the G2 and G3 dispatch on the IEEE 9-bus system, minimising the total network
   losses.
2. Search method: differential evolution (optim-algorithm), as the user asked.
3. Tries: at most 100 (optim-max-iter), as the user allows.
4. Output: a notebook (coding-style) rather than a plain script.
5. Study type, project user, output folder and the rest: left as the Quick Start has them, so it
   runs a load flow as the user the script is run by and writes next to the script.
https://tool.adjiebrotots.com/powerfactory-scripter/legacy/#load&v=1&qs=sample-02-minimum-system-losses&optim-algorithm=differential_evolution&why.optim-algorithm=The%20search%20method%20the%20user%20asked%20for&optim-max-iter=100&why.optim-max-iter=The%20user%20allows%20up%20to%20100%20tries&coding-style=notebook&why.coding-style=The%20user%20wants%20a%20notebook&note=Minimum%20system%20losses,%20differential%20evolution,%20notebook
```
https://tool.adjiebrotots.com/powerfactory-scripter/legacy/#load&v=1&qs=sample-02-minimum-system-losses&optim-algorithm=differential_evolution&why.optim-algorithm=The%20search%20method%20the%20user%20asked%20for&optim-max-iter=100&why.optim-max-iter=The%20user%20allows%20up%20to%20100%20tries&coding-style=notebook&why.coding-style=The%20user%20wants%20a%20notebook&note=Minimum%20system%20losses,%20differential%20evolution,%20notebook
```
Open the link to see the result.

QUICK STARTS (qs)
The Quick Starts are worked examples on the IEEE 9-bus system, listed with their input and output
variables under QUICK START FIGURES. A link cannot change those tables, so pick the one whose study
is closest to what the user wants and set the fields on top of it. Its fields are put back to its
own values first, so name each field the user wants different. Without qs the form opens as it
starts, with one input and one output variable to fill in.
For a study none of them is near (other inputs or outputs, a study built from steps), use the
Workflow Builder, which takes a whole workflow in a link: its reference is
references/powerfactory-scripter-builder.md in this skill (page powerfactory-scripter/builder).
qs takes one of: sample-01-transmission-loss-factor, sample-02-minimum-system-losses,
sample-03-rotor-angle-stability, sample-04-n1-line-contingency. Each loads a worked example with its
own input and output variables; the fields a link sets go on top of it.
What each Quick Start sets is listed under QUICK START FIGURES at the end.

FIELDS (key: label on the page)
Most important: problem-type, study-type, tstop, optim-algorithm, optim-max-iter, coding-style.

[Other]
pf-username: Username
  Text. Default blank.
  The PowerFactory user to log in as. Leave it out unless the user gives it: empty means their own.
  Tip on the page: PowerFactory login username passed to GetApplication(). Leave blank only if
  single-user mode is configured.
output-dir: Output Directory
  Text. Default blank.
  The folder results are written to. Leave it out unless the user gives it: empty means next to the
  script.
  Tip on the page: Folder where results are written. The /graph and /raw subfolders appear
  automatically when timeseries outputs are used.
problem-type: Problem Type  (most important)
  One of: brute_force (Brute Force), optimisation (Optimisation), custom (Custom), contingency
  (Contingency). Default brute_force.
  What the script does. brute_force runs every combination of the input variables' values (a sweep).
  optimisation searches the input variables' ranges for the best value of the output named in
  optim-objective. custom reads its scenarios from the file in scenario-file-path. contingency takes
  out each element of the outage list in turn (N-1, or pairs with contingency-n). The inputs and
  outputs come with the Quick Start, so pick the Quick Start whose problem type is the one wanted.
  Tip on the page: Brute Force: runs every combination of the input values. Total runs = the product
  of the number of values per input.
study-type: Study Type  (most important)
  One of: steady_state (Steady State), dynamic_rms (Dynamic RMS), dynamic_emt (Dynamic EMT),
  harmonic (Harmonic). Default steady_state.
  The calculation each run makes in PowerFactory: steady_state (load flow), dynamic_rms, dynamic_emt
  or harmonic. It must suit the Quick Start's outputs: a time series output needs a dynamic study.
  Tip on the page: Steady State: a load flow (ElmLdf) on every iteration. Timeseries outputs are not
  available.
tstop: Stop Time (s)  (most important)
  Number. 0 to 3,600, step 0.01. Default 20.
  Where a dynamic (RMS or EMT) simulation stops, in seconds from its start. Only used by a dynamic
  study type. Typical 10 to 20 for RMS and a fraction of a second to a few seconds for EMT. A Quick
  Start with a dynamic study type, or a study-type of dynamic_rms or dynamic_emt without a tstop,
  opens on that study type's usual 20 s (RMS) or 0.25 s (EMT); send tstop to change it.
  Tip on the page: How long the simulation runs, in seconds (ComSim.tstop). Typically 20 s for RMS
  and 0.25 s for EMT.
coding-style: Coding Style  (most important)
  One of: python_file (Python File), notebook (Notebook Style). Default python_file.
  python_file is a plain script; notebook is the same code in cells for Jupyter.
  Tip on the page: Python File: wraps everything in main(), ready to run as a plain script. Notebook
  Style: splits the code into labelled cells for Jupyter or VS Code.
scenario-file-path: Scenario File Path
  Text. Default blank.
  Only for the custom problem type: the path of the spreadsheet or CSV with the scenarios, as the
  script's computer sees it. Leave it out unless the user gives it.
  Tip on the page: Path to the Excel scenario file (.xlsx). Download the template above for the
  required 3-row header format.
contingency-n: Contingency Type
  One of: 1 (N-1), 2 (N-2). Default 1.
  Only for the contingency problem type: 1 takes out one element at a time, 2 takes out pairs.
  Tip on the page: N-1: one element is tripped per run. N-2: two elements are tripped together per
  run.
contingency-combine: Combine element types
  Checkbox: true or false. Default false.
  Only for the contingency problem type with N-2 and two or more element types in the outage list.
  Ticked: a pair may mix types, such as a line with a generator. Unticked: pairs form within one
  type.
  Tip on the page: Ticked: an N-2 pair may mix types, such as a line with a generator. Unticked:
  pairs form within one type only.
optim-sense: Sense
  One of: minimise (Minimise), maximise (Maximise). Default minimise.
  Only for the optimisation problem type: minimise or maximise the objective.
  Tip on the page: Minimise: the objective goes to the algorithm as it is. Maximise: it is negated
  internally, since every scipy algorithm minimises.
optim-objective: Objective
  One of: (blank) (— select output variable —). Default blank.
  Only for the optimisation problem type: the name of one of the Quick Start's output variables
  (QUICK START FIGURES names them under objective). Leave it out to keep the Quick Start's.
  Tip on the page: Scalar output variable to optimise. Must be defined first in the Output Variables
  section.
optim-algorithm: Algorithm  (most important)
  One of: placeholder (Manual (Placeholder)), scipy_nelder_mead (Nelder-Mead — Simplex (scipy)),
  scipy_powell (Powell — Directional Set (scipy)), scipy_lbfgsb (L-BFGS-B — Quasi-Newton (scipy)),
  scipy_slsqp (SLSQP — Sequential Least Squares (scipy)), scipy_cobyla (COBYLA — Constraint
  Approximation (scipy)), differential_evolution (Differential Evolution — Global (scipy)),
  gp_minimize (Bayesian Optimisation (scikit-optimize)). Default placeholder.
  Only for the optimisation problem type: the search method. placeholder (Manual) writes a TODO for
  the user's own search. The scipy ones are local searches; differential_evolution and gp_minimize
  (Bayesian) search the whole range and suit a result with several local minima.
  Tip on the page: Manual (Placeholder): the generated code builds evaluate_one_case() for you, but
  leaves the search loop empty for you to write.
optim-max-iter: Max Iterations  (most important)
  Number. 1 to 10,000. Default 50.
  Only for the optimisation problem type: the most tries the search makes. Typical 30 to 200.
  Tip on the page: Not used in Manual mode: your own search loop decides how many runs happen.
iterate-study-cases: Iterate through study cases
  Checkbox: true or false. Default false.
  Run the whole study once for each study case in the project.
  Tip on the page: Activate each study case before running the sweep. Useful for N-1 contingency
  analysis.
iterate-operating-scenarios: Iterate through operating scenarios
  Checkbox: true or false. Default false.
  Run the whole study once for each operating scenario.
  Tip on the page: Activate each operating scenario before running. Combines with study case
  iteration.
use-progress-bar: Use progress bar (tqdm)
  Checkbox: true or false. Default true.
  Show a progress bar (tqdm) while the script runs. On by default.
  Tip on the page: Shows live progress and an estimated finish time using tqdm. Requires pip install
  tqdm.
open-pf-window: Open PowerFactory window
  Checkbox: true or false. Default false.
  Open the PowerFactory window while the script runs (slower). Off by default.
  Tip on the page: Show the PF GUI (app.Show()) while running. Default is headless (app.Hide()) for
  speed.
save-intermediate: Save intermediate results every X minutes
  Checkbox: true or false. Default false.
  Save the results every save-interval-minutes while a long run goes on, so a stop does not lose
  them.
save-interval-minutes: Interval (min)
  Number. 1 to 1,440. Default 30.
  Only with save-intermediate on: the minutes between saves.
  Tip on the page: How often partial results are written, in minutes. 10–30 min suits a run lasting
  several hours.

QUICK START FIGURES (what each qs sets, as a link would carry them)
A heading line holds what all the Quick Starts under it share; each Quick Start's own line holds the
rest.

Every Quick Start sets: coding-style=python_file tstop=20 optim-sense=minimise contingency-n=1 contingency-combine=false iterate-study-cases=false iterate-operating-scenarios=false use-progress-bar=true open-pf-window=false save-intermediate=false save-interval-minutes=30

sample-01-transmission-loss-factor: Transmission Loss Factor. problem-type=brute_force study-type=steady_state optim-algorithm=placeholder optim-max-iter=50 Tables: inputs G2_dispatch (G2.ElmSym, pgini, 120 to 200, step 20); G3_dispatch (G3.ElmSym, pgini, 45 to 125, step 20). outputs G1_dispatch (G1.ElmSym, m:P:bus1, maximum); Line_5_7_MW (Line 5-7.ElmLne, m:P:bus1, maximum); Line_7_8_MW (Line 7-8.ElmLne, m:P:bus1, maximum).
sample-02-minimum-system-losses: Minimum System Losses. problem-type=optimisation study-type=steady_state optim-algorithm=gp_minimize optim-max-iter=60 Tables: inputs G2_dispatch (G2.ElmSym, pgini, 50 to 160); G3_dispatch (G3.ElmSym, pgini, 20 to 105). outputs total_losses (*.ElmNet, c:LossP, maximum); G1_dispatch (G1.ElmSym, m:P:bus1, maximum). objective minimise total_losses.
sample-03-rotor-angle-stability: Rotor Angle Stability. problem-type=brute_force study-type=dynamic_rms optim-algorithm=placeholder optim-max-iter=50 Tables: inputs fault_clearing_time (Switch Event.EvtSwitch, e:time, 0.1 to 1, step 0.1). outputs G2_rotor_angle_max (G2.ElmSym, c:firel, maximum); G2_rotor_angle_min (G2.ElmSym, c:firel, minimum); G3_rotor_angle_max (G3.ElmSym, c:firel, maximum); G3_rotor_angle_min (G3.ElmSym, c:firel, minimum); stability_verdict (maximum).
sample-04-n1-line-contingency: N-1 Line Contingency. problem-type=contingency study-type=steady_state optim-algorithm=placeholder optim-max-iter=50 Tables: outages *.ElmLne. outputs bus_voltage (*.ElmTerm, m:u, maximum); loading (*.ElmLne, c:loading, maximum).

Generated by _ref/agent-doc.mjs from the page and its agent-notes.md.
