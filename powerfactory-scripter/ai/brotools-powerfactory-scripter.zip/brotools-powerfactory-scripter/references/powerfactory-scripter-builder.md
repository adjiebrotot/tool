PowerFactory Workflow Builder: use this tool with an AI assistant
https://tool.adjiebrotots.com/powerfactory-scripter/builder/

This is the full reference for one page of the skill brotools-powerfactory-scripter: read SKILL.md first.

For people: Install this tool's skill in your AI assistant (Claude, ChatGPT, Grok and others) and
ask your question. It replies with a link that opens this tool on your scenario and lists what it
assumed, and the tool works out the answer. The rest of this file is written for the assistant.

WHAT THIS TOOL DECIDES
Which study the PowerFactory Python script runs, and in what order: a workflow of blocks (load flow,
N-1 contingencies, short circuit, RMS or EMT simulation, checks, loops, results tables and graphs),
the project and study case it opens and where its results go. The tool writes one ready-to-run
script for DIgSILENT PowerFactory 2024 from that workflow, and the user downloads it. It does not
run PowerFactory or work out a study result. The script comes from the tool, so a link to it gives
the user the whole script.

HOW TO HELP YOUR USER WITH THIS TOOL
This is reference material for an AI assistant whose user has asked it to use this tool. It
describes the link that opens the tool on the user's own scenario. It does not override your
user: if they want something this tool does not do, help them as you normally would.
1. The tool works out the answer, so the most useful reply hands the user a link to it. Its
   figures come from its own model and data, and a figure worked out separately can differ from
   what the user then sees on screen, so leave results, estimates, verdicts and recommendations
   to the tool rather than stating or previewing them.
2. A reply that works well has three parts, in this order:
   a. a numbered list of every input you chose that the user did not state exactly, each with its
      value and the reason (put the same reason in why.<key>);
   b. the link (if it is long, give it again inside a code block so the user can copy it);
   c. the sentence: Open the link to see the result.
3. Build the link in the format below, using only the keys listed here. Start from the nearest
   Quick Start (qs) and send only what differs from it. Write json compactly: no spaces or line
   breaks, defaults left out.
4. Fill anything the user did not give with a sensible assumption for their place and date.
   Prefer what the user said earlier in the conversation over general figures.
5. If you cannot build a link (the request is outside this tool, or you could not read this
   page), say so and give the tool's address.

LINK FORMAT
https://tool.adjiebrotots.com/powerfactory-scripter/builder/#load&v=1&qs=<quick start>&<key>=<value>&...&why.<key>=<your reason>&note=<one line>
- After #load come key=value pairs joined by &. Percent-encode each value (a space is %20, & is %26,
  # is %23, + is %2B).
- v=1 is the format version. qs=<key> starts from that Quick Start; without it the tool starts from
  its defaults.
- Then each key in the link is set, in the units its label shows on screen. Numbers may carry $,
  commas and a trailing %. A checkbox takes true or false. A select or a choice takes the value
  listed, or its visible label.
- Anything the link does not name keeps the value it started from, so send only what differs.
- why.<key>=<text>: your reason for that value, shown to the user beside it (200 characters at
  most). note=<text>: one line shown above the list, for example the place and the date.
- A number outside a field's range is pulled into range and the user is told; a key the tool does
  not know is skipped and listed. Never use the keys s, open or embed.

EXAMPLE
Request: using tool.adjiebrotots.com/powerfactory-scripter/builder, write me a PowerFactory script
for the Nine-bus System project that runs an N-1 screening on the lines only and saves the results
tables as Excel files
A reply in that form:
1. Study: the N-1 screening Quick Start (qs=n-1): a base load flow, then each outage in turn with a
   load flow after it, and a results table of the highest line loading and lowest busbar voltage.
2. Outages: lines only, so the transformers are not taken out (blk.n5.trafos).
3. Project: Nine-bus System, exactly as the user wrote it.
4. Tables: saved as Excel files rather than CSV (blk.n1.tableFmt).
5. Study case, output folder and the rest of the Start block: left as the Quick Start has them, so
   the script uses the project's active study case and writes next to itself.
https://tool.adjiebrotots.com/powerfactory-scripter/builder/#load&v=1&qs=n-1&blk.n1.project=Nine-bus%20System&why.blk.n1.project=The%20project%20the%20user%20named,%20as%20they%20wrote%20it&blk.n5.trafos=false&why.blk.n5.trafos=The%20user%20wants%20lines%20only,%20so%20transformers%20are%20not%20taken%20out&blk.n1.tableFmt=xlsx&why.blk.n1.tableFmt=The%20user%20wants%20the%20results%20as%20Excel%20files&note=N-1%20screening%20of%20the%20lines,%20Nine-bus%20System,%20Excel%20tables
```
https://tool.adjiebrotots.com/powerfactory-scripter/builder/#load&v=1&qs=n-1&blk.n1.project=Nine-bus%20System&why.blk.n1.project=The%20project%20the%20user%20named,%20as%20they%20wrote%20it&blk.n5.trafos=false&why.blk.n5.trafos=The%20user%20wants%20lines%20only,%20so%20transformers%20are%20not%20taken%20out&blk.n1.tableFmt=xlsx&why.blk.n1.tableFmt=The%20user%20wants%20the%20results%20as%20Excel%20files&note=N-1%20screening%20of%20the%20lines,%20Nine-bus%20System,%20Excel%20tables
```
Open the link to see the result.

QUICK STARTS (qs)
A Quick Start is a worked example workflow: it opens on the canvas and its script is written at
once. They are listed with their blocks under QUICK START FIGURES; the id at the start of a block is
what blk.<id>.<setting> names. Pick the one closest to the study the user describes and change what
differs. Every Quick Start has its Start block at n1.
Without qs the Builder opens on an empty workflow with just a Start block. For a study no Quick
Start is near, send the workflow in json. Leave the project and study case empty unless the user
names them: the project is typed exactly as PowerFactory's Data Manager shows it, and an invented
one makes the script stop. The user types it into the Start block, which says so while it is empty.
The script is written as soon as the workflow is in, so run has no effect here.
qs takes one of: headroom, ldf-cases, n-1, shc-buses, find-limit, frt, cct, hosting-capacity,
pv-curve, rms-batch. Each opens a worked example workflow. Change its blocks by id with
blk.<id>.<setting> (the reference lists each one's blocks), or send a whole workflow in json.
What each Quick Start sets is listed under QUICK START FIGURES at the end.

FIELDS (key: label on the page)

COMPACT LISTS
- `template=<id>`
- `blk.<id>.<setting>=<value>`
- `graph.<key>=<value>`

`template=<id>` is another name for qs=<id>. Use qs.

`blk.<id>.<setting>` changes one setting of one block on the canvas. The id is the block's id (n5): the Quick Starts list theirs, a json workflow names its own, and blk.start.<setting> reaches the Start block whatever its id. The setting is the key in the block's Settings line under REFERENCE: BLOCK TYPES (any case). The value is what the block shows: a number, in the unit its setting gives; yes or no (true and false work too); a choice, written as its value or the words shown for it; or text. A text with spaces is written with %20. An element setting (a PowerFactory element picked by class and name, written element in the reference) takes a part: blk.n7.el.name=L* (a * matches anything), blk.n7.el.cls=ElmLne, blk.n7.el.match=all (one, first or all). blk.<id>.label renames the block. A table of rows (the columns of a results table, a list of values) cannot be set this way: send json. A block the workflow does not have, a setting a block does not have, a choice it does not offer or a number that is not one is reported and skipped; a number outside its range is pulled into it and reported. Send one key per setting, and a why.<key> beside each.

The Start block holds the study's settings: project and studyCase (the PowerFactory names, empty keeps the active study case), outputDir (the folder results go in, empty is the script's own), tableFmt (csv, xlsx or both), fNominal (auto, 50 or 60), runMode (auto, engine or inside), undoChanges (put changed values back at the end), fastMode and connectTimeout (seconds).

`graph.<key>` sets how every graph the script draws looks. graph.template starts from a whole style (brotools, brotools-night, minimal, report, slides, ieee, elsevier, matlab, matplotlib or office) and replaces any graph key before it, so write it first. Then, in any order: font_size (5 to 30), title_size (5 to 48), line_width (0.3 to 8), width and height (the saved picture's size in inches, 2 to 30 and 1.5 to 20), dpi (50 to 600), legend (bottom, top, right, inside or none), grid_axes (both, y, x or none), grid_style (solid, dashed or dotted), frame (left-bottom, box, bottom or none), ticks (out, in or none), markers (auto, always or never), line_styles (solid or vary), title_align (center or left), also_save (svg or pdf; leave it out for PNG only), and yes or no for title_bold, thousands, legend_frame and transparent. Leave the graph style out unless the user asks for it.

JSON
`json=<workflow>` replaces the whole workflow with one of your own, in the form Save writes. Use it only for a study no Quick Start is near; to change a Quick Start, patch it. A qs before it is replaced. Write it compactly (no spaces or line breaks) and leave out everything the Builder fills in itself: x and y (it lays the blocks out left to right along the wires), every setting that is at its default, edge ids and the view.

{"name":"<name>","nodes":[<block>,<block>,...],"edges":[<wire>,<wire>,...]}

- A block is {"id":"n2","type":"<type>","label":"<optional name>","s":{<settings that differ>}}. The id is required and unique (n1, n2, ...). The type is one under REFERENCE: BLOCK TYPES. A setting is written as its type shows: a number, true or false, a choice's value, text; an element as {"cls":"ElmLne","name":"*","match":"all"}; a table as a list of rows, each with an id (c1, c2, ...) and the columns the reference names.
- There is exactly one block of type start (n1 in every Quick Start); one is added if there is none, and it holds the project and study case.
- A wire is {"from":"n2","out":"ok","to":"n3","in":"in"}: an output port of one block into an input port of another, by the ids in the reference's Wires line. A flow wire (the order of steps) goes from a flow out to the flow in, which is "in"; most steps lead on with "next". A data wire goes from an output to an input whose type fits.
- A block of a kind the reference does not list, a second Start, and a wire to a port that is not there or does not fit are left out and reported. The Python code block can be placed, but its code stays at its default, and apiPath stays empty.
- Up to 300 blocks and 1500 wires.
A small study: load flow, then the lowest busbar voltage into a results table (send project and study case with blk.n1.* or in the Start block's s):
{"name":"Voltage screen","nodes":[{"id":"n1","type":"start"},{"id":"n2","type":"pf.ldf"},{"id":"n3","type":"pf.get","label":"Busbar voltage","s":{"el":{"cls":"ElmTerm","name":"*","match":"all"},"attr":"m:u"}},{"id":"n4","type":"out.table.add","s":{"table":"Voltage","cols":[{"id":"c1","name":"Lowest voltage (p.u.)"},{"id":"c2","name":"Lowest at"}]}}],"edges":[{"from":"n1","out":"next","to":"n2","in":"in"},{"from":"n2","out":"ok","to":"n3","in":"in"},{"from":"n3","out":"next","to":"n4","in":"in"},{"from":"n3","out":"min","to":"n4","in":"c1"},{"from":"n3","out":"at_min","to":"n4","in":"c2"}]}

QUICK START FIGURES (what each qs sets, as a link would carry them)
A heading line holds what all the Quick Starts under it share; each Quick Start's own line holds the
rest.

headroom: Headroom study. Blocks: n1 "Start" (start).
    n3 "Dispatch (MW)" (flow.range) with from 100, to 300, step 50.
    n4 "Create study case" (pf.case.create) with name Headroom {loop values}.
    n5 "Generator A" (pf.dispatch).
    n16 "Save operation scenario" (pf.scen.save).
    n6 "Run load flow" (pf.ldf).
    n7 "Contingency unit" (pf.evt.trip).
    n8 "Run RMS simulation" (pf.rms) with tstop 20, extendTo 60.
    n9 "Settling time" (sig.settle).
    n10 "Settles?" (flow.if).
    n11 "Frequency nadir" (sig.nadir) with extendTo 60.
    n12 "Add row to results table" (out.table.add) with table Headroom.
    n13 "Bus frequency" (out.plot.series) with collect loop, ylabel Frequency.
    n15 "Nadir against dispatch" (out.plot.table) with table Headroom, x Dispatch (MW), ys Nadir (Hz).
ldf-cases: Load flow on every study case. Blocks: n1 "Start" (start).
    n3 "Study case" (pf.case.foreach).
    n4 "Run load flow" (pf.ldf).
    n5 "Busbar voltage" (pf.get) with el.name *, el.match all.
    n6 "Add row to results table" (out.table.add) with table Load flow.
n-1: N-1 screening. Blocks: n1 "Start" (start).
    n3 "Base load flow" (pf.ldf).
    n5 "Contingency" (pf.cont.foreach) with trafos yes.
    n6 "Run load flow" (pf.ldf).
    n7 "Line loading" (pf.get) with el.name *, el.cls ElmLne, el.match all, attr c:loading.
    n13 "Transformer loading" (pf.get) with el.name *, el.cls ElmTr2, el.match all, attr c:loading.
    n8 "Busbar voltage" (pf.get) with el.name *, el.match all.
    n9 "Add row to results table" (out.table.add) with table N-1.
    n11 "Print the worst outage" (flow.log) with text Worst outage: {worst}, with a line loaded to {loading:.1f} %.
    n12 "Worst outage" (out.table.column) with table N-1, col Contingency, pick max, of Highest loading (%), as text.
shc-buses: Short circuit at every busbar. Blocks: n1 "Start" (start).
    n3 "Busbar" (pf.foreach_element) with el.name *.
    n4 "Run short circuit" (pf.shc) with at element.
    n5 "Ikss" (pf.get) with attr m:Ikss, unit kA.
    n6 "Skss" (pf.get) with attr m:Skss, unit MVA.
    n7 "Add row to results table" (out.table.add) with table Short circuit.
    n9 "Fault current at every busbar" (out.plot.xy) with kind bar, xlabel Busbar, ylabel Initial short-circuit current, yunit kA.
    n10 "Busbars" (out.table.column) with table Short circuit, col Busbar, as text.
    n11 "Fault currents" (out.table.column) with table Short circuit, col Ikss (kA).
find-limit: Largest dispatch with a safe nadir. Blocks: n1 "Start" (start).
    n3 "Dispatch (MW)" (opt.limit) with lower 100, upper 800, tol 10, maxSteps 12, onUnknown fail, passIs no.
    n4 "Generator A" (pf.dispatch).
    n5 "Run load flow" (pf.ldf).
    n6 "Contingency unit" (pf.evt.trip).
    n7 "Run RMS simulation" (pf.rms) with tstop 20, extendTo 60.
    n8 "Frequency nadir" (sig.nadir) with extendTo 60.
    n10 "Print the limit" (flow.log) with text Largest dispatch with a safe nadir: {limit:.1f} MW (search {.
    n11 "Search for the largest dispatch" (out.plot.conv) with ylabel Dispatch, unit MW.
frt: Fault ride-through check. Blocks: n1 "Start" (start).
    n3 "Connection point fault" (pf.evt.shc) with duration 0.15.
    n4 "Run RMS simulation" (pf.rms) with tstop 5.
    n5 "LVRT curve" (chk.limit) with against curve, extend yes, goOn yes.
    n8 "Power recovery" (sig.cross) with levelMode pct, hold 0.5.
    n9 "Power recovery time (s)" (chk.verdict) with op le, limit 1, goOn yes.
    n10 "Add row to results table" (out.table.add) with table FRT.
    n12 "Voltage at the connection point" (out.plot.series) with ylabel Voltage.
    n13 "Plant active power" (out.plot.series) with ylabel Active power.
cct: Critical clearing time. Blocks: n1 "Start" (start).
    n3 "Fault duration (s)" (opt.limit) with lower 0.05, upper 0.5, tol 0.01, maxSteps 12.
    n4 "Fault" (pf.evt.shc).
    n5 "Run RMS simulation" (pf.rms) with tstop 5.
    n6 "Rotor angle spread (deg)" (chk.limit) with hi 180, goOn yes.
    n8 "Unstable" (opt.report) with answer fail.
    n10 "Print the CCT" (flow.log) with text Critical clearing time: {cct:.3f} s (search {status}).
    n11 "Search for the critical clearing time" (out.plot.conv) with ylabel Fault duration, unit s.
hosting-capacity: Hosting capacity at every busbar. Blocks: n1 "Start" (start).
    n3 "Connection point" (pf.foreach_element) with el.name *.
    n4 "Generation (MW)" (opt.limit) with upper 1000, tol 5, onUnknown fail.
    n5 "Test generator" (pf.testgen).
    n6 "Run load flow" (pf.ldf).
    n7 "Line loading" (pf.get) with el.name *, el.cls ElmLne, el.match all, attr c:loading.
    n8 "Transformer loading" (pf.get) with el.name *, el.cls ElmTr2, el.match all, attr c:loading.
    n9 "Busbar voltage" (pf.get) with el.name *, el.match all.
    n10 "Line thermal limit" (chk.limit) with hi 100, goOn yes.
    n11 "Transformer thermal limit" (chk.limit) with hi 100, goOn yes.
    n12 "Voltage limits" (chk.limit) with lo 0.9, hi 1.1, goOn yes.
    n13 "Thermal limits" (math.logic).
    n14 "All limits" (math.logic).
    n15 "Add row to results table" (out.table.add) with table Hosting capacity.
    n16 "Hosting capacity at each busbar" (out.plot.table) with table Hosting capacity, x Connection point, ys Hosting capacity (MW), kind bar, ylabel Hosting capacity, yunit MW.
    n17 "Generator dispatch" (pf.get) with el.name *, el.cls ElmSym, el.match all, attr pgini.
    n18 "Total dispatch" (math.sum).
    n19 "Share kept" (math.formula) with expr 1 - p / total.
    n20 "Other generators" (pf.scale) with el.name *, el.cls ElmSym, el.match all, attr pgini.
pv-curve: PV curve by load scaling. Blocks: n1 "Start" (start).
    n3 "Load scaling" (flow.range) with to 3, step 0.05.
    n4 "Loads" (pf.scale) with el.name *, el.match all, attr2 qlini.
    n5 "Run load flow" (pf.ldf).
    n6 "Nose of the curve" (flow.break) with msg The load flow no longer converges: the nose of the PV curve.
    n7 "Busbar voltage" (pf.get) with el.name *, el.match all.
    n8 "Add row to results table" (out.table.add) with table PV curve.
    n9 "PV curve" (out.plot.table) with table PV curve, x Load scaling, ys Lowest voltage (p.u.), ylabel Lowest busbar voltage, yunit p.u..
rms-batch: RMS runs for several fault durations. Blocks: n1 "Start" (start).
    n3 "Fault duration (s)" (flow.list) with values 0.1, 0.15, 0.2, 0.25.
    n4 "Fault" (pf.evt.shc).
    n5 "Run RMS simulation" (pf.rms) with tstop 5.
    n6 "Peak spread" (sig.peak).
    n7 "Rotor angle spread (deg)" (chk.limit) with hi 180, goOn yes.
    n8 "Add row to results table" (out.table.add) with table RMS runs.
    n9 "Rotor angle spread" (out.plot.series) with collect loop, ylabel Rotor angle spread.

REFERENCE: BLOCK TYPES

[Start]
start: Start. Where the workflow begins: the PowerFactory project to open and where the results go. Every workflow has exactly one Start.
  Wires: flow out: next
  Settings: project text; studyCase text; outputDir text; undoChanges yes or no default yes; tableFmt one of csv | xlsx | both default csv; fNominal one of auto | 50 | 60 default auto; runMode one of auto | engine | inside default auto; showPf yes or no default no; fastMode yes or no default yes; connectTimeout number (at least 10) in s default 120; apiPath text; pfUser text

[PowerFactory: cases and data]
pf.element: Element. Finds a PowerFactory element by class and name, or every match of a name with *. Found again after a study case, scenario or variation switch.
  Wires (with default settings; more follow the settings): data out: el:obj
  Settings: el element with cls, name (a * matches anything) and match (one, first or all), default cls ElmTerm; inService yes or no default yes
pf.foreach_element: For each element. Repeats the Each pass steps for every element of a class whose name matches (sorted by name), or for each element of a list wired in.
  Wires: flow in: in; flow out: body, done; data in: items:obj; data out: item:obj, elname:text, index:num, count:num
  Settings: name text; el element with cls, name (a * matches anything) and match (one, first or all), default cls ElmTerm; inService yes or no default yes; attr attribute name such as c:loading; op one of = | != | > | >= | < | <= default =; value text; restore one of pass | end | never default pass; onError one of skip | stop default skip
pf.set: Set attribute. Writes one attribute of an element (or of each element of a list), such as a tap position or a set point. Put back at the end of the pass or the workflow.
  Wires (with default settings; more follow the settings): flow in: in; flow out: next; data in: obj:obj, value:num
  Settings: el element with cls, name (a * matches anything) and match (one, first or all), default cls ElmLod; attr attribute name such as c:loading; vtype one of num | text default num; value number default 0; text text; unit one of none | MW | kW | Mvar | kvar | MVA | kV | kA | A | s | ms default none
pf.get: Read attribute. Reads an attribute or a result (m:u, c:loading ...) of an element or a list of elements, at this step. For a list it also gives the highest, the lowest and where.
  Wires: flow in: in; flow out: next; data in: obj:obj; data out: value:num, max:num, min:num, at_max:obj, at_min:obj, values:list, n:num
  Settings: el element with cls, name (a * matches anything) and match (one, first or all), default cls ElmTerm; attr attribute name such as c:loading default m:u; unit one of none | MW | kW | Mvar | kvar | MVA | kV | kA | A | s | ms default none; total yes or no default no; skip yes or no default yes
pf.dispatch: Set generator dispatch. Sets the active power (and reactive power) of a generator and puts it in service, or dispatches several generators from one row of a case table.
  Wires (with default settings; more follow the settings): flow in: in; flow out: next; data in: gen:obj, p:num, q:num
  Settings: mode one of one | row default one; gen element with cls, name (a * matches anything) and match (one, first or all), default cls ElmSym; p number in MW default 100; q number in Mvar; cols rows with id and col, gen; basis one of total | machine default total; qmode one of keep | pq default keep; unit one of MW | kW | GW default MW; outerComp yes or no default yes
pf.scale: Scale. Multiplies an attribute (for example a load's active power) by a factor of its original value, so scaling by 1.1 twice still gives 1.1 times the original.
  Wires: flow in: in; flow out: next; data in: obj:obj, factor:num
  Settings: el element with cls, name (a * matches anything) and match (one, first or all), default cls ElmLod; attr attribute name such as c:loading default plini; attr2 attribute name such as c:loading; factor number default 1.1
pf.outserv: Take out of / put back in service. Takes an element (or each element of a list) out of service, or puts it back in. Put back at the end of the pass or the workflow.
  Wires: flow in: in; flow out: next; data in: obj:obj
  Settings: el element with cls, name (a * matches anything) and match (one, first or all), default cls ElmLne; action one of out | in default out; outerComp yes or no default no
pf.undo: Put changed values back. Puts back every value the workflow has changed so far (dispatch, service, attributes), each in its own study case and scenario. Loops already do this after each pass.
  Wires: flow in: in; flow out: next
pf.case.activate: Activate study case. Makes a study case active by its name (or the case wired in). Its operation scenario and variations come with it. The start case is active again at the end.
  Wires: flow in: in; flow out: next; data in: case_in:any; data out: case:obj, name:text
  Settings: case text
pf.case.create: Create study case. Makes a copy of the active (or a named) study case, by default with its own operation scenario, and activates it. Use it for one case per pass of a loop.
  Wires: flow in: in; flow out: next; data in: name_in:text, template:any; data out: case:obj, scenario:obj, name:text
  Settings: name text default {active case} {loop values}; template text; scenario one of copy | new | none default copy; exists one of reuse | replace | new default reuse; activate yes or no default yes; keep yes or no default yes
pf.case.foreach: For each study case. Repeats the Each pass steps with each study case active in turn (the names matching a pattern, sorted). The case active before is active again afterwards.
  Wires: flow in: in; flow out: body, done; data in: items:items; data out: case:obj, casename:text, index:num, count:num
  Settings: name text; pattern text default *; restore one of pass | end | never default pass; onError one of skip | stop default skip
pf.scen.activate: Activate operation scenario. Makes an operation scenario active in the active study case, so dispatch and service changes go into it. The start scenario is active again at the end.
  Wires: flow in: in; flow out: next; data in: scen:any; data out: scenario:obj
  Settings: scen text
pf.scen.create: Create operation scenario. Saves the operating state in use now (dispatch, switching, service) as a new operation scenario and activates it, so later changes stay in it.
  Wires: flow in: in; flow out: next; data in: name_in:text; data out: scenario:obj, name:text
  Settings: name text default {active case} {loop values}; exists one of reuse | replace | new default reuse; activate yes or no default yes; keep yes or no default yes
pf.scen.save: Save operation scenario. Saves the changes of the active operation scenario into it, so they stay after the workflow puts changed values back (also at the end of a pass).
  Wires: flow in: in; flow out: next; data out: saved:bool
pf.scen.deactivate: Deactivate operation scenario. Switches the active operation scenario off. Its unsaved changes are dropped unless you choose to save them (PowerFactory's own default is to drop).
  Wires: flow in: in; flow out: next; data out: scenario:obj
  Settings: save yes or no default no
pf.scen.foreach: For each operation scenario. Repeats the Each pass steps with each operation scenario active in turn (names matching a pattern, sorted). The scenario active before comes back afterwards.
  Wires: flow in: in; flow out: body, done; data in: items:items; data out: scenario:obj, scenname:text, index:num, count:num
  Settings: name text; pattern text default *; restore one of pass | end | never default pass; onError one of skip | stop default skip
pf.var.activate: Activate variation. Activates a network variation in the active study case (alone, or with the ones already active). The case gets its own variations back at the end.
  Wires: flow in: in; flow out: next; data in: var_in:any; data out: variation:obj
  Settings: variation text; alone yes or no default no
pf.var.deactivate: Deactivate variation. Deactivates one network variation, or every active one, in the active study case. The case gets its own variations back at the end.
  Wires (with default settings; more follow the settings): flow in: in; flow out: next; data in: var_in:any; data out: count:num
  Settings: which one of one | all default one; variation text
pf.var.create: Create variation. Makes a network variation with one expansion stage at the study time and activates it, so new elements and type changes are recorded in it, not in the base network.
  Wires: flow in: in; flow out: next; data in: name_in:text; data out: variation:obj, name:text
  Settings: name text default {active case} {loop values}; stage text; exists one of reuse | replace | new default reuse; activate yes or no default yes; keep yes or no default yes
pf.var.foreach: For each variation. Repeats the Each pass steps with each network variation active in turn (names matching a pattern, sorted). The case's own variations come back afterwards.
  Wires: flow in: in; flow out: body, done; data in: items:items; data out: variation:obj, varname:text, index:num, count:num
  Settings: name text; pattern text default *; alone yes or no default yes; restore one of pass | end | never default pass; onError one of skip | stop default skip
pf.testgen: Add test generator at a bus. Connects a static generator (constant Q) to a busbar for hosting capacity studies; feed it to Set generator dispatch to change P. Deleted at the end.
  Wires: flow in: in; flow out: next; data in: bus:obj, p:num, q:num; data out: gen:obj
  Settings: bus element with cls, name (a * matches anything) and match (one, first or all), default cls ElmTerm; p number in MW default 0; q number in Mvar default 0; rating number in MVA

[PowerFactory: studies]
pf.ldf: Run load flow. Runs the load flow (ComLdf) of the active study case with its own settings, or with the network type, reactive power limits or taps changed for this run.
  Wires: flow in: in; flow out: ok, fail; data out: converged:bool, slack_mw:num
  Settings: net one of case | ac | unbalanced | dc default case; qlim one of case | on | off default case; taps one of case | on | off default case
pf.hldf: Run harmonic load flow. Runs a harmonic load flow (ComHldf) in the active study case, with the load flow set to the same network type first. THD is then readable on busbars as m:THD.
  Wires: flow in: in; flow out: ok, fail; data out: finished:bool
  Settings: net one of case | balanced | unbalanced default case
pf.shc: Run short circuit. Runs a short-circuit calculation (ComShc) at every busbar or at one element. Results such as m:Ikss (kA) and m:Skss (MVA) are then readable on the faulted busbars.
  Wires (with default settings; more follow the settings): flow in: in; flow out: ok, fail; data in: rf:num, xf:num; data out: finished:bool
  Settings: method one of iec | vde | ansi | complete | iec61363 default iec; fault one of 3ph | 2ph | 1ph | 2phg default 3ph; current one of max | min default max; at one of all | element default all; target element with cls, name (a * matches anything) and match (one, first or all), default cls ElmTerm; rf number in Ohm default 0; xf number in Ohm default 0
pf.rms: Run RMS simulation. Runs an RMS (stability) simulation of the active study case with the events added before it. Each row of Record becomes a time series output.
  Wires (with default settings; more follow the settings): flow in: in; flow out: ok, early, fail; data in: tstop:num, tstart:num, step:num; data out: result:res, t_end:num, status:text
  Settings: tstop number (at least 0) in s default 10; tstart number in s; step number in s; net one of case | sym | rst default case; record rows with id and el, var, combine; caseEvents one of auto | keep | off default auto; fast yes or no default no; extendTo number in s default 0; ufls number in Hz
pf.emt: Run EMT simulation. Runs an EMT (electromagnetic transients) simulation of the active study case with the events added before it. Each Record row is a time series. Keep EMT runs short.
  Wires (with default settings; more follow the settings): flow in: in; flow out: ok, early, fail; data in: tstop:num, tstart:num, step:num; data out: result:res, t_end:num, status:text
  Settings: tstop number (at least 0) in s default 0.5; tstart number in s; step number in s; net one of case | sym | rst default case; record rows with id and el, var, combine; caseEvents one of auto | keep | off default auto; fast yes or no default no; extendTo number in s default 0; ufls number in Hz
sig.series: Read time series from a result. Reads one curve (element and variable) from a simulation result, for curves the Record list of the run block does not have. Recorded during the run automatically.
  Wires (with default settings; more follow the settings): data in: res:res, element:obj; data out: series:series
  Settings: el element with cls, name (a * matches anything) and match (one, first or all), default cls ElmTerm; var attribute name such as c:loading default m:fehz; combine one of none | mean | sum | min | max | spread default none; label text
pf.evt.shc: Add short circuit. Adds a short-circuit event on a busbar or line for the next simulation, cleared after the duration (by clearing the fault, or by opening the faulted line).
  Wires: flow in: in; flow out: next; data in: target:obj, t:num, duration:num, rf:num, xf:num, loc:num; data out: t_fault:num, t_clear:num
  Settings: target element with cls, name (a * matches anything) and match (one, first or all), default cls ElmTerm; t number in s default 1; duration number in s default 0.1; fault one of 3ph | 2ph | 1ph | 2phg default 3ph; phase1 one of a | b | c default a; phase2 one of ab | bc | ca default ab; clear one of fault | trip default fault; rf number in Ohm default 0; xf number in Ohm default 0; loc number in %
pf.evt.switch: Add switch event. Opens (or closes) a breaker, a switch or a whole element (all phases) at a time in the next simulation.
  Wires: flow in: in; flow out: next; data in: element:obj, t:num; data out: t:num
  Settings: el element with cls, name (a * matches anything) and match (one, first or all), default cls ElmCoup; t number in s default 1; action one of open | close default open
pf.evt.trip: Add trip event. Trips a generator (all its parallel machines) or opens another element at a time in the next simulation. Gives the active power tripped.
  Wires: flow in: in; flow out: next; data in: element:obj, t:num; data out: mw:num, t:num
  Settings: el element with cls, name (a * matches anything) and match (one, first or all), default cls ElmSym; t number in s default 1
pf.evt.load: Add load step. Steps a load's active and reactive power by a percentage of its value at a time in the next simulation (a load event).
  Wires: flow in: in; flow out: next; data in: load:obj, t:num, dp:num, dq:num; data out: t:num
  Settings: load element with cls, name (a * matches anything) and match (one, first or all), default cls ElmLod; t number in s default 1; dp number in % default 10; dq number in % default 0
pf.evt.param: Add parameter change. Changes one value of an element (a DSL parameter, a set point, a voltage input) at one time, to a value the workflow works out. For a profile use Add parameter steps.
  Wires: flow in: in; flow out: next; data in: element:obj, t:num, value:num; data out: t:num
  Settings: el element with cls, name (a * matches anything) and match (one, first or all), default cls ElmDsl; t number in s default 1; param attribute name such as c:loading; mode one of absolute | add | times default absolute; value number default 1
pf.evt.steps: Add parameter steps. Changes one value of an element at several times in the next simulation: a voltage profile on an AC voltage source, a set point ramp. Type the steps or drag them.
  Wires: flow in: in; flow out: next; data in: element:obj; data out: t_first:num, t_last:num
  Settings: el element with cls, name (a * matches anything) and match (one, first or all), default cls ElmVac; param attribute name such as c:loading default s:u0; steps rows with id, t and v; mode one of absolute | add | times default absolute
pf.cont.define: Contingencies. Lists N-1 (or N-2) outages of the lines, transformers, generators or other elements in service, for For each contingency. Elements already out are left out.
  Wires: data in: elements:obj; data out: conts:cset
  Settings: lines yes or no default yes; trafos yes or no default no; gens yes or no default no; xnets yes or no default no; query text; order one of 1 | 2 default 1; inService yes or no default yes
pf.cont.foreach: For each contingency. Repeats the Each pass steps for each outage: the base case first, then each line, transformer or other element taken out of service (or opened by an event for a...
  Wires (with default settings; more follow the settings): flow in: in; flow out: body, done; data in: conts:cset; data out: cont:cell, contname:text, elements:obj, index:num, count:num
  Settings: name text; lines yes or no default yes; trafos yes or no default no; gens yes or no default no; xnets yes or no default no; query text; order one of 1 | 2 default 1; inService yes or no default yes; how one of outserv | event default outserv; t number in s default 1; base yes or no default yes; restore one of pass | end | never default pass; onError one of skip | stop default skip

[Power system checks]
sig.despike: Remove spikes. Takes measurement spikes out of a frequency trace (samples far from the running median are removed), such as the jumps an EMT bus frequency shows at a fault.
  Wires: data in: series:series; data out: series:series, n:num, note:text
  Settings: window number (at least 0) in s default 0.2; trigger number (at least 0) in Hz default 0.1; maxStep number (at least 0) in Hz/s default 20; settle number (at least 0) in Hz default 0.02; signal one of auto | frequency | other default auto; nominal number in Hz
sig.nadir: Frequency nadir. The lowest frequency after an event, and whether it turned around (settles) or collapsed, with the UFLS flag. Use it after a trip in an RMS run.
  Wires: data in: series:series, t_event:num, nominal:num, extendTo:num; data out: nadir:num, time:num, turned:bool, verdict:text, ufls:text, minimum:num, min_time:num, still:bool, recovery:num
  Settings: t_event number in s; floorBelow number (at least 0) in Hz default 5; uflsBelow number (at least 0) in Hz default 1; window number (at least 0) in s default 10; minRecovery number (at least 0) in Hz default 0.05; tailGuard number (at least 0) in s default 1; delay number (at least 0) in s default 0; requiresUfls yes or no default yes; nominal number in Hz; extendTo number in s
sig.peak: Peak. The highest (or lowest, or furthest from zero) value of a curve and when it happens, over the whole run or a time range.
  Wires: data in: series:series, after:num, before:num; data out: value:num, time:num
  Settings: kind one of max | min | abs default max; after number in s; before number in s
sig.settle: Settling time. How long a curve takes to settle inside a band around its final value after an event, with rise time and overshoot. A curve still moving at the end does not settle.
  Wires (with default settings; more follow the settings): data in: series:series, t_event:num, band:num; data out: settles:bool, time:num, at:num, initial:num, final:num, rise:num, overshoot:num
  Settings: t_event number in s; bandMode one of pct | abs default pct; band number (at least 0) default 10; hold number (at least 0) in s default 1; reference one of final | given default final; target number; guard number (at least 0) in s default 1
sig.rocof: RoCoF. Rate of change of frequency (Hz/s): the steepest change over a rolling window from the event to the nadir. Wire Nadir time and Verdict from Frequency nadir.
  Wires: data in: series:series, t_event:num, nadir_t:num, verdict:text, nominal:num; data out: rocof:num, time:num, t2:num, basis:text
  Settings: t_event number in s; window number (at least 0) in s default 0.5; fallback one of window | tstop | none default window; searchWindow number (at least 0) in s default 10; absolute yes or no default no; decimals number (0 to 12) default 4; nominal number in Hz
sig.at: Value at time. The value of a curve at a given time, read between samples. At an event instant it is the value just before the event, e.g. the power before a fault.
  Wires: data in: series:series, t:num; data out: value:num
  Settings: t number in s default 0
sig.final: Final value. The value of a curve at the end of the run, or its average over the last seconds, e.g. the voltage after recovery.
  Wires: data in: series:series; data out: value:num
  Settings: last number (at least 0) in s default 0
sig.cross: First time above / below. When a curve first goes above (or below) a level and stays there, e.g. the voltage back to 0.9 p.u., or the power back to 90 % of its value before the fault.
  Wires (with default settings; more follow the settings): data in: series:series, level:num, after:num; data out: time:num, delay:num, found:bool, threshold:num
  Settings: direction one of above | below default above; levelMode one of value | pct default value; level number default 0.9; pct number (at least 0) in % default 90; refT number in s; after number in s; hold number (at least 0) in s default 0
chk.limit: Check limits. Checks a value, a list or a whole curve against a lowest and highest limit, or against a curve such as an FRT envelope, and goes on along Pass or Fail.
  Wires (with default settings; more follow the settings): flow in: in; flow out: pass, fail; data in: x:list, lo:num, hi:num; data out: ok:bool, text:text, margin:num, at:num, worst:num
  Settings: against one of value | curve default value; lo number; hi number; curve rows with id and x, low, high; x0 number in s default 0; extend yes or no default no; after number in s; before number in s; goOn yes or no default no
chk.verdict: Pass / fail. Checks one value against a limit (for example nadir ≥ 49.2 Hz, or UFLS is false) and goes on along Pass or Fail. An empty value takes Fail and says NO DATA.
  Wires (with default settings; more follow the settings): flow in: in; flow out: pass, fail; data in: value:any, limit:num; data out: ok:bool, text:text, margin:num
  Settings: op one of ge | gt | le | lt | eq | ne | true | false default ge; limit number default 0; tol number default 0; goOn yes or no default no

[Results and graphs]
out.table.add: Add row to results table. Adds one row to a results table: the loop values, then one column per value wired in. Drop a wire on "+ drop a value" to add a column. Saved at the end automatically.
  Wires (with default settings; more follow the settings): flow in: in; flow out: next; data in: add:cell
  Settings: table text default Results; cols rows with id and name; ctx yes or no default yes; onSkip yes or no default yes
out.table.save: Save results table. Writes a results table to the run folder as CSV (opens in Excel), an Excel file or both. Connect it to After all passes so it saves once.
  Wires (with default settings; more follow the settings): flow in: in; flow out: next; data out: file:text
  Settings: table text default Results; fmt one of csv | xlsx | both default csv; stem text
out.table.column: Table column. The values of one column of a results table, or its value in the row where another column is highest or lowest: the worst case, the worst line.
  Wires (with default settings; more follow the settings): data out: value:list
  Settings: table text default Results; col text; pick one of all | max | min default all; of text; as one of num | text default num
data.read: Read table from file. Attach a CSV or Excel file: its columns become a named table the rest of the workflow reads, one case per row. Use it for a case workbook or a dispatch table.
  Wires: flow in: in; flow out: next; data out: name:text, n:num
  Settings: table text default Cases; path text; sheet text; layout one of rows | columns default rows; header number (at least 1) default 1; decimalComma yes or no default no
out.plot.series: Draw time series graph. Draws curves over time to a PNG: one graph per pass, or every pass on one graph drawn after the loop. Marks a nadir, limit lines and the run's events.
  Wires (with default settings; more follow the settings): flow in: in; flow out: next; data in: l1:series, add:series, mark:num, mark_t:num, limit:num, t_event:num, note:text; data out: file:text
  Settings: lines rows with id and name; collect one of pass | loop default pass; title text; ylabel text; unit text; limits rows with id and value, label; events yes or no default yes; stem text
out.plot.xy: Draw 2D graph. Draws one or more lists against a list of x values (lines, points or bars) to a PNG, e.g. the nadir of every case against its dispatch.
  Wires (with default settings; more follow the settings): flow in: in; flow out: next; data in: x:items, l1:list, add:list; data out: file:text
  Settings: lines rows with id and name; kind one of line | scatter | bar default line; title text; xlabel text; xunit text; ylabel text; yunit text; limits rows with id and value, label; stem text
out.plot.3d: Draw 3D graph. Draws a value over two swept inputs as a 3D surface (or points) to a PNG, e.g. nadir over generator A and generator B dispatch from a 2-D sweep.
  Wires: flow in: in; flow out: next; data in: x:list, y:list, z:list; data out: file:text
  Settings: kind one of surface | wireframe | scatter default surface; title text; xlabel text; xunit text; ylabel text; yunit text; zlabel text; zunit text; stem text
out.plot.heatmap: Draw heat map. Draws a value over two inputs as coloured cells to a PNG, with the values written in, e.g. line loading per contingency and line.
  Wires: flow in: in; flow out: next; data in: x:items, y:items, z:list; data out: file:text
  Settings: title text; xlabel text; xunit text; ylabel text; yunit text; zlabel text; zunit text; annotate one of auto | yes | no default auto; stem text
out.plot.table: Draw graph from results table. Draws columns of a results table against another column to a PNG, e.g. Nadir (Hz) against Dispatch (MW), one line per study case. Connect it after the loop.
  Wires: flow in: in; flow out: next; data out: file:text
  Settings: table text default Results; x text; ys text, one value per line; kind one of line | scatter | bar default line; group text; title text; ylabel text; yunit text; limits rows with id and value, label; stem text
out.plot.conv: Draw convergence curve. Draws how Optimise or Find limit went to a PNG: the score of every try and the best so far, or each value tried with the bracket narrowing in.
  Wires: flow in: in; flow out: next; data in: history:hist; data out: file:text
  Settings: title text; ylabel text; unit text; kind one of auto | optimise | limit default auto; stem text
out.series.save: Save time series to CSV. Writes curves to a CSV file in the run folder (one time column, one column per curve) to open in Excel or another tool. Inside a loop: one file per pass.
  Wires (with default settings; more follow the settings): flow in: in; flow out: next; data in: l1:series, add:series; data out: file:text
  Settings: lines rows with id and name; stem text

[Flow: loops and decisions]
flow.if: If. Checks a value and goes on along Yes or No. An empty value takes No (and says so in the log).
  Wires (with default settings; more follow the settings): flow in: in; flow out: yes, no; data in: a:any, b:num
  Settings: op one of true | gt | ge | lt | le | eq | ne default true; b number default 0; tol number default 0
flow.range: For a range of numbers. Repeats the Each pass steps for every number from First to Last in steps (both ends included), e.g. 100, 150 ... 300 MW.
  Wires: flow in: in; flow out: body, done; data in: from:num, to:num, step:num; data out: value:num, index:num, count:num
  Settings: name text; from number default 1; to number default 10; step number default 1; restore one of pass | end | never default pass; onError one of skip | stop default skip
flow.list: For each item. Repeats the Each pass steps for every item of a list: values typed here, a list wired in, or the rows of a results table.
  Wires (with default settings; more follow the settings): flow in: in; flow out: body, done; data out: item:num, index:num, count:num
  Settings: name text; source one of values | list | table default values; values text, one value per line default 1, 2, 3; itemType one of num | text | obj default num; table text default Results; cols rows with id and name, type; runCol text; restore one of pass | end | never default pass; onError one of skip | stop default skip
flow.repeat: Repeat N times. Repeats the Each pass steps a set number of times.
  Wires: flow in: in; flow out: body, done; data in: times:num; data out: index:num
  Settings: name text; times number (at least 0) default 3; restore one of pass | end | never default pass; onError one of skip | stop default skip
flow.until: Repeat until. Repeats the Each pass steps until the condition is true at the end of a pass, at most Max passes times.
  Wires: flow in: in; flow out: body, done; data in: cond:bool; data out: index:num, met:bool
  Settings: name text; max number (at least 1) default 20; restore one of pass | end | never default pass; onError one of skip | stop default skip
flow.next: Skip to next pass. Ends this pass of the loop now and goes on with the next pass. The reason goes into the log and the results table.
  Wires: flow in: in
  Settings: msg text
flow.break: Stop the loop. Ends the loop now: no more passes. The steps wired to After all passes run next.
  Wires: flow in: in
  Settings: msg text
flow.stop: Stop the workflow. Stops the whole workflow cleanly: changed values are put back and the tables are saved.
  Wires: flow in: in
  Settings: msg text default Stopped by the workflow
flow.log: Print a message. Writes a line to the log (screen and run.log). Put {name} in the text and wire a value into the input of that name.
  Wires (with default settings; more follow the settings): flow in: in; flow out: next; data in: value:cell
  Settings: text text default Value: {value}; level one of info | warn | error default info
var.set: Remember a value. Keeps a value under a name for later steps, also across loop passes: set it, add to a list, keep the lowest or highest, add up or count.
  Wires (with default settings; more follow the settings): flow in: in; flow out: next; data in: value:any
  Settings: name text default Result; mode one of set | append | min | max | sum | count default set
var.get: Recall a value. Gives back the value Remember a value kept under this name, as it is at the step that uses it.
  Wires (with default settings; more follow the settings): data out: value:num, where:text
  Settings: name text default Result; as one of num | text | list | items | bool | any default num; dflt text

[Values and maths]
val.number: Number. A number you type, such as a limit or a step size. Pin it to put it at the top of the script.
  Wires (with default settings; more follow the settings): data out: value:num
  Settings: value number default 0; unit text
val.text: Text. A text you type, such as a name or a file stem.
  Wires: data out: value:text
  Settings: value text
val.bool: Yes / No. A yes or no you choose, for example to switch part of a workflow on or off with an If.
  Wires: data out: value:bool
  Settings: value yes or no default yes
val.list: List of values. A list you type: numbers or names, one per line or separated by commas.
  Wires (with default settings; more follow the settings): data out: value:list
  Settings: values text, one value per line default 1, 2, 3
val.range: Range of numbers. A list of numbers from First to Last in steps, both ends included, e.g. 0, 0.5 ... 3.
  Wires: data in: from:num, to:num, step:num; data out: value:list
  Settings: from number default 0; to number default 10; step number default 1
math.arith: Arithmetic. Adds, subtracts, multiplies or divides two numbers (or takes the smaller, larger, power or remainder). Empty in gives empty out.
  Wires (with default settings; more follow the settings): data in: a:num, b:num; data out: value:num
  Settings: op one of add | sub | mul | div | pow | min | max | mod default add; a number default 0; b number default 0; each yes or no default no
math.formula: Formula. Works out a formula such as sqrt(p**2 + q**2). Each name in it becomes an input. Knows abs, min, max, round, sqrt, log, log10, exp, pi.
  Wires (with default settings; more follow the settings): data in: a:num, b:num; data out: value:num
  Settings: expr text default a * b; each yes or no default no
math.func: Function. Applies one function to a number: absolute value, round, square root, negate, round down or up, log10, exp.
  Wires (with default settings; more follow the settings): data in: x:num; data out: value:num
  Settings: fn one of abs | round | sqrt | neg | floor | ceil | log10 | exp default abs; x number default 0; digits number (at least 0) default 2; each yes or no default no
math.compare: Compare. Compares two numbers and gives Yes or No (empty when a number is missing).
  Wires: data in: a:num, b:num; data out: value:bool
  Settings: op one of gt | ge | lt | le | eq | ne default gt; a number default 0; b number default 0; tol number default 0
math.logic: And / or / not. Combines yes / no values: both, either, or the opposite. An unknown value stays unknown unless the answer is clear without it.
  Wires (with default settings; more follow the settings): data in: a:bool, b:bool; data out: value:bool
  Settings: op one of and | or | not default and
math.max: Maximum. The largest of the values. Takes a list, a time series (its values) or one number; empty values are left out.
  Wires: data in: values:list; data out: value:num
math.min: Minimum. The smallest of the values. Takes a list, a time series (its values) or one number; empty values are left out.
  Wires: data in: values:list; data out: value:num
math.mean: Average. The average (mean) of the values. Takes a list, a time series (its values) or one number; empty values are left out.
  Wires: data in: values:list; data out: value:num
math.median: Median. The middle value: half of the values are below it. Takes a list, a time series (its values) or one number; empty values are left out.
  Wires: data in: values:list; data out: value:num
math.sum: Sum. All the values added up. Takes a list, a time series (its values) or one number; empty values are left out.
  Wires: data in: values:list; data out: value:num
math.count: Count. How many values there are. Takes a list, a time series (its values) or one number; empty values are left out.
  Wires: data in: values:list; data out: value:num
math.std: Standard deviation. How far the values spread around their average (standard deviation). Takes a list, a time series (its values) or one number; empty values are left out.
  Wires: data in: values:list; data out: value:num
math.percentile: Percentile. The value below which the given percentage of the values lie, e.g. the 95th percentile. Takes a list, a time series (its values) or one number; empty values are left out.
  Wires: data in: values:list, p:num; data out: value:num
  Settings: p number (0 to 100) in % default 95
text.format: Text from a template. Builds a text from a template such as "Dispatch {p} MW". Each {name} becomes an input; {p:.1f} shows 1 decimal.
  Wires (with default settings; more follow the settings): data in: p:cell; data out: value:text
  Settings: template text default Dispatch {p} MW

[Optimise and search]
opt.optimise: Optimise. Tries values of one or more variables to make a score as small (or large) as possible, e.g. the dispatch with the best nadir. Report this try gives each score.
  Wires (with default settings; more follow the settings): flow in: in; flow out: body, done; data in: score:num; data out: v1:num, best_v1:num, score:num, found:bool, history:hist
  Settings: vars rows with id and name, lower, upper, integer; goal one of min | max default min; method one of de | nelder | powell | bounded | grid | bayes default de; maxTries number (at least 1) default 30; gridSteps number (at least 2) default 5; seed number default 1
opt.limit: Find limit. Finds where a study goes from pass to fail by halving the gap between a passing and a failing value, e.g. the largest dispatch that keeps the nadir above a limit.
  Wires: flow in: in; flow out: body, done; data in: lower:num, upper:num, tol:num, maxSteps:num, pass:any; data out: value:num, limit:num, found:bool, status:text, passing:num, failing:num, history:hist
  Settings: name text; lower number default 0; upper number default 100; tol number (at least 0) default 1; maxSteps number (at least 2) default 20; passes one of low | high default low; bracket one of given | halve default given; onUnknown one of stop | fail | pass default stop; integer yes or no default no; passIs one of yes | no default yes
opt.report: Report this try. Tells Optimise or Find limit how this try went: a score, a pass (yes, no, or unknown such as UFLS UNDEFINED), or both. Only works on the Each try route.
  Wires (with default settings; more follow the settings): flow in: in; flow out: next; data in: score:num, pass:any
  Settings: answer one of wired | pass | fail | none default wired; passIs one of yes | no default yes

[Advanced]
adv.python: Python code. Runs your own Python with named inputs and outputs. The code becomes a function of its inputs; set the outputs as variables.
  Wires (with default settings; more follow the settings): flow in: in; flow out: next; data in: i1:any; data out: o1:num
  Settings: inputs rows with id and name; outputs rows with id and name, type; code python (not taken from a link); touches one of none | reads | model | calc default none
note: Note. A note on the canvas for you and your colleagues. It also goes into the script as a comment.
  Wires: none
  Settings: text text, one value per line

Generated by _ref/agent-doc.mjs from the page and its agent-notes.md.
