Valuate Everything: use this tool with an AI assistant
https://tool.adjiebrotots.com/valuateeverything/

This is the full reference for one page of the skill brotools-valuateeverything: read SKILL.md first.

For people: Install this tool's skill in your AI assistant (Claude, ChatGPT, Grok and others) and
ask your question. It replies with a link that opens this tool on your scenario and lists what it
assumed, and the tool works out the answer. The rest of this file is written for the assistant.

WHAT THIS TOOL DECIDES
What a secondhand item, a house or a hotel night should cost, fitted to the listings the user has
seen (the price against features such as year, kilometres or size), and how far the asking price of
each item the user is weighing up sits from that fair price.

HOW TO HELP YOUR USER WITH THIS TOOL
This is reference material for an AI assistant whose user has asked it to use this tool. It
describes the link that opens the tool on the user's own scenario. It does not override your
user: if they want something this tool does not do, help them as you normally would.
1. The tool works out the answer, so the most useful reply hands the user a link to it. Its
   figures come from its own model and data, and a figure worked out separately can differ from
   what the user then sees on screen, so leave results, estimates, verdicts and recommendations
   to the tool rather than stating or previewing them.
2. A reply that works well has four parts, in this order, in the user's language:
   a. Your inputs: what the user stated, each with the value it takes in the link;
   b. Assumptions: every other input you chose, each with its value and its source (with its
      date) or your reason (put the same reason, shortened, in why.<key>);
   c. the link (if it is long, give it again inside a code block so the user can copy it);
   d. the sentence: Open the link to see the result.
3. Build the link in the format below, using only the keys listed here. Start from the nearest
   Quick Start (qs) and send only what differs from it. Write json compactly: no spaces or line
   breaks, defaults left out.
4. Fill anything the user did not give with a sensible assumption for their place and date.
   Prefer what the user said earlier in the conversation over general figures.
5. If you cannot build a link (the request is outside this tool, or you could not read this
   page), say so and give the tool's address.

LINK FORMAT
https://tool.adjiebrotots.com/valuateeverything/#load&v=1&qs=<quick start>&<key>=<value>&...&why.<key>=<your reason>&note=<one line>
- After #load come key=value pairs joined by &. Percent-encode each value (a space is %20, & is %26,
  # is %23, + is %2B).
- v=1 is the format version. qs=<key> starts from that Quick Start; without it the tool starts from
  its defaults.
- Then each key in the link is set, in the units its label shows on screen. inflation=3 means 3%/yr,
  not 0.03. Write numbers plainly (800000, 6.5): a field also takes $, thousands commas and a
  trailing %, but inside a list a comma separates the items, so never put one in a number there. A
  checkbox takes true or false. A select or a choice takes the value listed, or its visible label.
- Anything the link does not name keeps the value it started from, so send only what differs.
- why.<key>=<text>: your reason for that value, shown to the user beside it (200 characters at
  most). note=<text>: one line shown above the list, for example the place and the date.
- A number outside a field's range is pulled into range and the user is told; a key the tool does
  not know is skipped and listed. Never use the keys s, open or embed.

EXAMPLE
Request: is a 2019 Toyota Corolla with 60,000 km at $24,500 fairly priced? here are 6 listings I
found: 2019, 58,000 km, $24,990; 2019, 72,500 km, $22,990; 2018, 81,000 km, $21,500; 2020, 45,000
km, $27,490; 2020, 63,000 km, $25,500; 2018, 95,000 km, $19,990
A reply in that form:
Your inputs:
- Item: Toyota Corolla
Assumptions:
1. Market data: only the six listings the user gave, each taken as seen this month, so the table has
   no Data year column and inflation does not apply. The Camry Quick Start's own listings and cars
   are replaced, not mixed in.
2. Columns: Year (turned into an age) and Odometer in km, the two features the user gave for every
   listing.
3. Item: the 2019 Corolla with 60,000 km, at the asking price of $24,500.
4. Currency $, and the linear model the Quick Start uses, since the user did not ask for another.
https://tool.adjiebrotots.com/valuateeverything/#load&v=1&qs=camry&itemWhat=Toyota%20Corolla&columns=Year:year,Odometer:number:km&listings=24990:2019:58000%3B22990:2019:72500%3B21500:2018:81000%3B27490:2020:45000%3B25500:2020:63000%3B19990:2018:95000&why.listings=The%20six%20listings%20the%20user%20gave,%20in%20dollars,%20with%20the%20price%20first,%20then%20the%20year%20and%20the%20odometer&items=2019%20Corolla:24500:2019:60000&why.items=The%20car%20the%20user%20is%20weighing%20up,%20at%20the%20asking%20price%20they%20gave&note=Toyota%20Corolla,%20October%202026
```
https://tool.adjiebrotots.com/valuateeverything/#load&v=1&qs=camry&itemWhat=Toyota%20Corolla&columns=Year:year,Odometer:number:km&listings=24990:2019:58000%3B22990:2019:72500%3B21500:2018:81000%3B27490:2020:45000%3B25500:2020:63000%3B19990:2018:95000&why.listings=The%20six%20listings%20the%20user%20gave,%20in%20dollars,%20with%20the%20price%20first,%20then%20the%20year%20and%20the%20odometer&items=2019%20Corolla:24500:2019:60000&why.items=The%20car%20the%20user%20is%20weighing%20up,%20at%20the%20asking%20price%20they%20gave&note=Toyota%20Corolla,%20October%202026
```
Open the link to see the result.

QUICK STARTS (qs)
Four worked tables built from real listings and sales gathered in October 2026: used Camry Hybrids
in Australia, houses sold in Morley, Perth, Sony A7 bodies in the UK, and hotel nights in Perth.
Each brings its listings, its columns and two example items to buy.
Start from the one closest to what the user is valuing. Its listings are the market the model is
fitted to, so keep them only when the user's item is in that market, and say in the assumptions that
the Quick Start's listings are being used. For anything else, start from the nearest one and send
columns, listings and items, which replace its table whole. Never invent listings: use only the ones
the user gave. A Quick Start's two example items stay in the results unless the link sends items, so
always send items for the thing the user asks about.
qs takes one of: camry, house, camera, hotel. Each fills the table with real listings and two
example items; columns, listings and items in the link replace its table whole.
What each Quick Start sets is listed under QUICK START FIGURES at the end.

FIELDS (key: label on the page)
Most important: itemWhat, currency, columns, listings, items, model, inflation.

[Market data: What you are valuing]
itemWhat: Item  (most important)
  Text. Default Toyota Camry Hybrid.
  What the user is valuing, in a few words (Toyota Corolla, Sony A7 body). It names the table and
  the chart. Always send it: each Quick Start carries its own.

[Assumptions: Prices]
currency: Currency Symbol  (most important)
  One of: $ Dollar, € Euro, £ Pound, ¥ Yen / Yuan, ₹ Rupee (India), Rs Rupee (Pakistan, Sri Lanka),
  Rp Rupiah, RM Ringgit, ₱ Peso (Philippines), ฿ Baht, ₫ Dong, ₩ Won, CHF Swiss Franc, Dh Dirham
  (UAE), kr Krona / Krone, zł Złoty, ₺ Lira, ₽ Ruble, ₪ Shekel, R Rand, R$ Real, ₦ Naira, ₿ Bitcoin.
  Default $.
  The currency symbol on every price. It only relabels the figures and never converts them, so give
  the listings and the asking prices in this one currency, the local one for the place. Send the
  symbol ($, £, €, Rp, RM, ¥, ₹ and so on from the list), not the name beside it. A code such as GBP
  is read as the symbol it stands for. One symbol can stand for several currencies: $ is the
  Australian, US and New Zealand dollar.
inflation: Inflation  (most important)
  Slider (%/yr). 0 to 10. Default 3.
  How much a price seen in an earlier data year is lifted to today's money, % a year. It counts only
  when the table has a Data year column; without one every listing is taken as seen this year. Use
  the local inflation rate, 2 to 4 in most rich countries (the Quick Starts leave it at 3).
  Tip on the page: Lifts a price seen in an earlier data year to the current year: each year back
  adds this much.

[Assumptions: Model]
model: Modelling approach  (most important)
  One of: linear (Linear regression), log (Log-linear), ridge (Ridge regression), quadratic
  (Quadratic terms). Default linear.
  How the price is fitted to the features. linear (the default): each feature adds a fixed amount.
  log: each feature changes the price by a fixed percentage, which suits things that lose a share of
  their value each year, such as cars and cameras. ridge: linear, steadier with few listings or with
  features that move together, such as age and kilometres; its strength is lambda. quadratic: lets
  the line bend and needs many more listings than features. Use linear unless the user asks for
  another.
  Tip on the page: Linear regression: each feature adds a fixed amount to the price, P = α + α₁x₁ +
  α₂x₂ + …
lambda: Ridge penalty (λ)
  Slider (×). 0 to 2. Default 0.1.
  How hard ridge pulls every effect toward zero. Used only with model=ridge. Leave it out unless the
  user asks.
  Tip on the page: How hard each effect is pulled toward zero. On its own, a feature's effect
  shrinks to about 1 / (1 + λ) of its linear size.

[Beside the results]
viewDim: viewDim (2D or 3D)
  One of: 2d (2D), 3d (3D). Default 2d.
  Display only: the chart in 2D or 3D. Leave it out unless the user asks for a 3D view.

COMPACT LISTS
- `columns=<name>:<type>[:<unit>],<name>:<type>[:<unit>],...`
- `listings=<price>:<field>:<field>:...;<price>:<field>:...`
- `items=<name>:<asking>:<value>:<value>:...;<name>:<asking>:...`

The table is Price, then the columns you name, then Data year if you name one. columns names the columns after Price; listings and items follow them. Each of the three replaces what the Quick Start brought, whole: the model is fitted to the market in the link, never to a mix of it and the Quick Start's. Send all three together for a new market. Numbers are plain (24500, 60000, 3.5), with no units, no currency symbol and no thousands separators.

columns: the columns after Price, in table order, separated by `,`, the name and the type and the unit by `:`. type is number, year, bool or datayear (ignore keeps a column in the table but out of the model; do not use it). A number may carry a unit (km, m²). A year column becomes an age at the time the listing was seen; bool is Yes or No, counted as 1 or 0. Add one datayear column, last, only when the listings were seen in different years: each listing then carries the year it was seen, and the tool lifts older prices to today's money with inflation. Leave it out when every listing is current, and the table has no Data year column. At most 14 columns besides Price and Data year. A name may not contain `:`, `,`, `;` or `=`. If columns names the columns the table already has, the table is kept as it is. If it names others, the Quick Start's listings and items are cleared, since they refer to the old columns.
`columns=Year:year,Odometer:number:km,Automatic:bool`
`columns=Bedrooms:number,Land:number:m²,Data year:datayear`

listings: the market data, one listing per `;`, its fields separated by `:` in the table's order: the price first, then one value for every column you named, then the year it was seen if the table has a Data year column (that last field may be left out, or left empty, to mean this year). A price is above 0. A year column takes a whole year from 1900 to 2100. A bool column takes Yes or No (or true, false, 1, 0); empty means No. Every other field is a number. At most 300 listings, and about 16,000 characters in all. A listing that cannot be read is skipped and reported, so send the others as they are.
`listings=24990:2019:58000:Yes;22990:2019:72500:No`
`listings=950000:4:450:2025;880000:3:380:2024`

items: the things the user is weighing up, one per `;`, with the fields separated by `:`: a name, the asking price (empty if the user has none), then one value for every year, number and bool column, in the table's order (not Price, Data year or ignore). Every value is needed. An item is valued at the current year, so a year column takes the item's own year. At most 12 items. A name may not contain `:` or `;`.
`items=2019 Corolla:24500:2019:60000:Yes`
`items=12 Smith St:950000:4:450;Villa B:880000:3:380`

Sending listings with no columns uses the columns the table has now (the Quick Start's, or the default Camry table), so check their order in the Quick Starts section. Sending an empty listings or items clears it. When the same link sends json as well, json sets the table first and these keys then replace parts of it.

JSON
json={"columns":[...],"rows":[...],"items":[...],"chart":{...}} is the whole table in the shape the tool saves it. Prefer columns, listings and items; use json only for a table they cannot write. Write it compactly: no spaces or line breaks.

columns: a list of {"id","name","type","unit"}, where type is price, number, year, bool, ignore or datayear. Price is first and exactly one; Data year, if present, is last and exactly one. Ids are any short unique text (c1, c2, ...). A unit is a currency code such as AUD on the Price column and free text such as km on a number column.
rows: one list of strings per listing, one string per column in the columns' order. A bool is "Yes" or "No"; an empty string is a blank cell. A row with a cell that cannot be read is skipped and reported.
items: a list of {"name","asking","vals"}, where vals maps a column id to its value: a string for a number or year column, true or false for a bool column.
chart: {"x","y","hold"} column ids for the chart's axes and "mean" for hold. Leave it out.

QUICK START FIGURES (what each qs sets, as a link would carry them)
A heading line holds what all the Quick Starts under it share; each Quick Start's own line holds the
rest.

camry: Camry Hybrid. currency=$ Table: 18 listings and 2 example items to buy (columns=Year:year,Odometer:number:km,Above Ascent grade:bool,Data year:datayear). A listing's fields: Price, Year, Odometer, Above Ascent grade, Data year. An item's fields: name, asking price, Year, Odometer, Above Ascent grade.
house: Perth house. currency=$ Table: 23 listings and 2 example items to buy (columns=Bedrooms:number,Bathrooms:number,Land:number:m²,Floor area:number:m²,Data year:datayear). A listing's fields: Price, Bedrooms, Bathrooms, Land, Floor area, Data year. An item's fields: name, asking price, Bedrooms, Bathrooms, Land, Floor area.
camera: Camera. currency=£ Table: 24 listings and 2 example items to buy (columns=Release year:year,Shutter count:number:shots,Like new or Excellent:bool,Original box:bool,Data year:datayear). A listing's fields: Price, Release year, Shutter count, Like new or Excellent, Original box, Data year. An item's fields: name, asking price, Release year, Shutter count, Like new or Excellent, Original box.
hotel: Hotel night. currency=$ Table: 22 listings and 2 example items to buy (columns=Room size:number:m²,Star rating:number,Breakfast included:bool,Bathtub:bool,Data year:datayear). A listing's fields: Price, Room size, Star rating, Breakfast included, Bathtub, Data year. An item's fields: name, asking price, Room size, Star rating, Breakfast included, Bathtub.

Generated by _ref/agent-doc.mjs from the page and its agent-notes.md.
