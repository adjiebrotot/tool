Finance vs Cash Purchase: use this tool with an AI assistant
https://tool.adjiebrotots.com/financingvscash/

This is the full reference for one page of the skill brotools-financingvscash: read SKILL.md first.

For people: Install this tool's skill in your AI assistant (Claude, ChatGPT, Grok and others) and
ask your question. It replies with a link that opens this tool on your scenario and lists what it
assumed, and the tool works out the answer. The rest of this file is written for the assistant.

WHAT THIS TOOL DECIDES
Whether paying cash for a purchase, or financing it on each loan offer while investing the cash it
frees up, leaves you with more money at the end of each loan, and which offer comes out best.

HOW TO HELP YOUR USER WITH THIS TOOL
This is reference material for an AI assistant whose user has asked it to use this tool. It
describes the link that opens the tool on the user's own scenario. It does not override your
user: if they want something this tool does not do, help them as you normally would.
1. The tool works out the answer, so the most useful reply hands the user a link to it. Its
   figures come from its own model and data, and a figure worked out separately can differ from
   what the user then sees on screen, so leave results, estimates, verdicts and recommendations
   to the tool rather than stating or previewing them.
2. A reply that works well has four parts, in this order, in the user's language:
   a. Your inputs: what the user stated, each with the value it takes in the link;
   b. Assumptions: every other input you chose, each with its value and its source (with its
      date) or your reason (put the same reason, shortened, in why.<key>);
   c. the link (if it is long, give it again inside a code block so the user can copy it);
   d. the sentence: Open the link to see the result.
3. Build the link in the format below, using only the keys listed here. Start from the nearest
   Quick Start (qs) and send only what differs from it. Write json compactly: no spaces or line
   breaks, defaults left out.
4. Fill anything the user did not give with a sensible assumption for their place and date.
   Prefer what the user said earlier in the conversation over general figures.
5. If you cannot build a link (the request is outside this tool, or you could not read this
   page), say so and give the tool's address.

LINK FORMAT
https://tool.adjiebrotots.com/financingvscash/#load&v=1&qs=<quick start>&<key>=<value>&...&why.<key>=<your reason>&note=<one line>
- After #load come key=value pairs joined by &. Percent-encode each value (a space is %20, & is %26,
  # is %23, + is %2B).
- v=1 is the format version. qs=<key> starts from that Quick Start; without it the tool starts from
  its defaults.
- Then each key in the link is set, in the units its label shows on screen. baseRf=4.5 means
  4.5%/yr, not 0.045. Write numbers plainly (800000, 6.5): a field also takes $, thousands commas
  and a trailing %, but inside a list a comma separates the items, so never put one in a number
  there. A checkbox takes true or false. A select or a choice takes the value listed, or its visible
  label.
- Anything the link does not name keeps the value it started from, so send only what differs.
- why.<key>=<text>: your reason for that value, shown to the user beside it (200 characters at
  most). note=<text>: one line shown above the list, for example the place and the date.
- A number outside a field's range is pulled into range and the user is told; a key the tool does
  not know is skipped and listed. Never use the keys s, open or embed.

EXAMPLE
Request: should I pay cash for a $45,000 car or take a 5-year loan at 7.9% and invest the cash?
A reply in that form:
Your inputs:
- Cash Purchase Cost: $45,000
Assumptions:
1. Cash on hand: 60,000, which the user did not state, kept at the car Quick Start's level so the
   cash covers the price.
2. The loan: a single offer over 5 years at 7.9% a year, repaid monthly, with no deposit and no fees
   because the user mentioned none. It replaces the car Quick Start's three offers.
3. Interest on spare cash: 4.5% a year, a typical savings or term deposit rate, used for the cash
   that is invested instead of spent.
https://tool.adjiebrotots.com/financingvscash/#load&v=1&qs=car&purchaseCost=45000&availableCash=60000&why.availableCash=The%20user%20did%20not%20say%20how%20much%20cash%20they%20hold,%20so%20a%20round%20amount%20above%20the%20price,%20as%20the%20car%20Quick%20Start%20assumes&offers=5-year%20loan%20at%207.9%25:financeRate=7.9:termYears=5&why.offers=One%20loan%20over%205%20years%20at%207.9%25%20a%20year,%20paid%20monthly%20with%20nothing%20down%20and%20no%20fees,%20since%20none%20were%20mentioned&baseRf=4.5&why.baseRf=A%20typical%20savings%20or%20term%20deposit%20rate%20for%20the%20cash%20that%20is%20invested%20instead&note=Car%20purchase,%20October%202026
```
https://tool.adjiebrotots.com/financingvscash/#load&v=1&qs=car&purchaseCost=45000&availableCash=60000&why.availableCash=The%20user%20did%20not%20say%20how%20much%20cash%20they%20hold,%20so%20a%20round%20amount%20above%20the%20price,%20as%20the%20car%20Quick%20Start%20assumes&offers=5-year%20loan%20at%207.9%25:financeRate=7.9:termYears=5&why.offers=One%20loan%20over%205%20years%20at%207.9%25%20a%20year,%20paid%20monthly%20with%20nothing%20down%20and%20no%20fees,%20since%20none%20were%20mentioned&baseRf=4.5&why.baseRf=A%20typical%20savings%20or%20term%20deposit%20rate%20for%20the%20cash%20that%20is%20invested%20instead&note=Car%20purchase,%20October%202026
```
Open the link to see the result.

QUICK STARTS (qs)
Six worked comparisons: a house, a car, a phone on a plan, a 0% credit card, an Indonesian motorbike
and furniture on a payment holiday. Each sets the purchase cost, cash, rates and loan offers for its
case.
Start from the one closest to the user's purchase, then send the user's own figures (purchaseCost,
availableCash) and offers for the loans they were quoted. Send offers whenever the user names a
loan: it replaces the Quick Start's offers whole. For a purchase none of them fits, leave qs out and
send every field that matters.
qs takes one of: house, car, phone, card, motorbike, deferred. Each sets the purchase, cash and
rates and brings its own loan offers; offers= in the link replaces them.
What each Quick Start sets is listed under QUICK START FIGURES at the end.

FIELDS (key: label on the page)
Most important: purchaseCost, availableCash, offers, baseRf, currencySymbol, offerPricing,
rateConvention.

[Purchase]
currencySymbol: Currency Symbol  (most important)
  One of: $ Dollar, € Euro, £ Pound, ¥ Yen / Yuan, ₹ Rupee (India), Rs Rupee (Pakistan, Sri Lanka),
  Rp Rupiah, RM Ringgit, ₱ Peso (Philippines), ฿ Baht, ₫ Dong, ₩ Won, CHF Swiss Franc, Dh Dirham
  (UAE), kr Krona / Krone, zł Złoty, ₺ Lira, ₽ Ruble, ₪ Shekel, R Rand, R$ Real, ₦ Naira, ₿ Bitcoin.
  Default $.
  The currency every amount on the page is in. It only relabels the figures and never converts them,
  so give every amount in this one currency, the local one for the place (Sydney $, Jakarta Rp,
  London £).

[Purchase: Purchase]
purchaseCost: Cash Purchase Cost  (most important)
  Number ($ before it). 0 to 1,000,000,000,000. Default 50,000.
  The cash price of the thing being bought, today. Use the user's price. Every loan offer finances
  this price, less its own down payment.
offerPricing: Price Each Loan Offer Separately  (most important)
  Checkbox: true or false. Default false.
  Off, every offer pays the cash price. On, each offer carries its own price (priceType and
  priceValue in offers), for a store that quotes one price for cash and another on a plan. Turn it
  on only when the offers really differ on price.
  Tip on the page: On: each loan offer gets its own price, as an amount, a % of the cash price or a
  % off. Off: every offer pays the cash price.
availableCash: Available Cash  (most important)
  Number ($ before it). 0 to 1,000,000,000,000. Default 50,000.
  The cash the user holds today. It must be at least purchaseCost, or the tool cannot compare and
  shows a warning instead. Cash left after paying is invested at baseRf, in both the cash and the
  financing case. Use the user's figure; otherwise a round amount above the price, as the Quick
  Starts do.
  Tip on the page: Cash on hand today. It must cover the cash purchase cost, since this compares
  financing against genuinely paying cash.

[Assumptions: Cash and rates]
baseRf: Risk-Free Rate  (most important)
  Slider (%/yr). 0 to 20. Default 4.5.
  What spare cash earns, % a year, like a savings account or term deposit. Use the local deposit
  rate for the place and date (about 4 to 5 in Australia and the USA in late 2026, higher in
  Indonesia and India). With the loan rate it decides the answer.
  Tip on the page: What your spare cash earns in a safe place, like a savings account. Every
  scenario and the cash purchase use it.
rateConvention: Rate Convention  (most important)
  One of: ear (Effective annual (EAR)), nominal (Nominal annual (APR)). Default ear.
  How a yearly loan rate becomes a rate per repayment. ear: the yearly rate compounds, the tool's
  default. nominal: the rate is divided by the repayments in a year, as a US APR or an Indonesian
  flat quote reads. Use nominal when the lender states the rate per month or per period (the
  motorbike Quick Start does); otherwise leave it.
  Tip on the page: Effective (EAR): compound conversion to the repayment period. A 12% loan charges
  0.949% a month. Loans only, never the cash rate.

[Assumptions: Prices]
inflationRate: Inflation
  Number (%/yr after it). 0 to 30, step 0.1. Default 2.5.
  Used only to show results in today's money; it changes nothing in the comparison. Typical 2 to 3,
  the local inflation target.
  Tip on the page: How fast prices rise each year. It never changes the loans or the cash, only how
  their figures read in today's money.

[Beside the results]
inflationToggle: Show in today's money
  Checkbox: true or false. Default false.
  Display only: true shows results in today's money. Leave it out.
  Tip on the page: The loans are the same either way. On: every figure in today's money. Off: in the
  money of each date, as the lender quotes it. Offers ending on different dates compare fairly in
  today's money.
optTarget: Optimization Target
  One of: netBenefit (Highest Net Benefit), lowestInterest (Lowest Total Interest), lowestCost
  (Lowest Financing Cost). Default netBenefit.
  Which offer the Best Strategy tile picks. netBenefit: the one that leaves the most money.
  lowestInterest: the least interest paid. lowestCost: the least total finance cost. Leave it out
  unless the user asks for a different ranking.
chartMetric: Chart Metric
  One of: wealth (Ending Wealth Over Time), netBenefit (Net Benefit vs Cash), investmentValue
  (Investment Value Over Time), loanBalance (Loan Balance Over Time). Default wealth.
  Display only: which line the chart draws. Leave it out.

COMPACT LISTS
- `offers=<name>:<field>=<value>:<field>=<value>,<name>:<field>=<value>,...`

The list is the loan offers the tool compares, and it replaces the Quick Start's offers whole. Items are separated by `,`, the name and each field by `:`, both typed as they are; a name may not contain `:`, `,` or `=` (leave them out). Each field is `<field>=<value>`, in any order, and a field left out takes the default of a new offer. Numbers are plain (7.9, 45070), with no thousands separators. At most 12 offers. The first offer is the one the editor shows.

Fields of an offer (the names an offer is saved under):
`loanType`: annuity (the default: equal repayments that clear the loan), flat (interest on the original amount, rate quoted per period), interestOnly (interest only for ioPeriods, then the principal), balloon (equal repayments with residualPct of the loan left to pay at the end), knownPayment (only the repayment is quoted and the tool solves the rate), bullet (all interest and principal in one lump at the end), deferred (nothing paid for ioPeriods, interest added to the debt, then equal repayments).
`freq`: weekly, fortnightly, monthly (the default) or yearly. How often repayments fall.
`termPeriods`: the number of repayments, 1 to 3000, so 60 is five years when monthly. Or use termYears, the term in years, turned into repayments for freq; with both, termPeriods wins. Left out, the term is five years.
`financeRate`: the loan's rate, % a year, 0 to 30 (default 5). Not used for knownPayment.
`downPaymentPct`: the deposit, % of the offer's price, 0 to 100 (default 0). The rest is the loan.
`feeAmt` and `feeType`: an origination fee, an amount (feeType=fixed, the default) or a % of the loan (feeType=pct); an amount written with % (3%) is pct. feeTreatment: upfront (paid from cash, the default), capitalise (added to the loan) or discount (deducted from the advance).
`adminFee`: a fixed fee on every repayment, 0 to 1000000000 (default 0).
`knownPayment`: the repayment each period, for knownPayment only.
`ioPeriods`: repayments before normal instalments begin, for interestOnly and deferred; default the whole term. The holiday of a deferred start.
`residualPct`: the share of the loan left to pay at the end, 0 to 99, for balloon only.
`priceType` and `priceValue`: this offer's own price, used only when offerPricing=true. priceType amount: priceValue is an amount. pct: a % of the cash price. discount (the default): a % off the cash price. Send offerPricing=true with them.
`ratePeriods`: a rate schedule in place of financeRate, for every type but flat and knownPayment: `<to>@<rate>/<to>@<low>-<high>/...`. Each period ends at repayment number `<to>`, counted from the first repayment (a payment holiday included) and in repayments of freq, not years; `<low>-<high>` is a floating rate, which the tool runs at its low, middle and high rate and draws as a band. The last period always runs to the end of the term, whatever its `<to>`. Rates 0 to 40. A 30-year monthly loan fixed at 5.8% for 2 years, then floating between 5% and 8.5%: `30yr fixed then variable:termPeriods=360:ratePeriods=24@5.8/360@5-8.5`
`paymentPeriods`: a repayment schedule in place of knownPayment, for knownPayment only: `<to>@<amount>/<to>@<amount>/...`, ends counted as in ratePeriods, the last running to the end of the term.

A 36 month loan at 8.4% with 10% down and a 400 fee, against a 60 month one at 9%:
`offers=3yr loan:financeRate=8.4:termPeriods=36:downPaymentPct=10:feeAmt=400,5yr loan:financeRate=9:termYears=5:downPaymentPct=10:feeAmt=400`
A store plan that quotes only the instalment, 24 payments of 82 on an 1800 purchase:
`offers=24 x 82:loanType=knownPayment:knownPayment=82:termPeriods=24`

QUICK START FIGURES (what each qs sets, as a link would carry them)
A heading line holds what all the Quick Starts under it share; each Quick Start's own line holds the
rest.

Every Quick Start sets: inflationRate=2.5 optTarget=netBenefit

house: House, fixed vs float. currencySymbol=$ purchaseCost=650000 offerPricing=false availableCash=700000 baseRf=4.5 rateConvention=ear inflationToggle=true chartMetric=wealth Loan: 3 loan offers (offers=30yr fixed 6.10 percent:financeRate=6.1:termPeriods=360:downPaymentPct=20:feeAmt=600:adminFee=10,30yr 2yr fixed then variable:termPeriods=360:ratePeriods=24@5.8/360@5-8.5:downPaymentPct=20:feeAmt=600:adminFee=10,15yr fixed 5.85 percent:financeRate=5.85:termPeriods=180:downPaymentPct=20:feeAmt=600:adminFee=10).
car: Car, 3yr or balloon. currencySymbol=$ purchaseCost=45000 offerPricing=false availableCash=60000 baseRf=4.5 rateConvention=ear inflationToggle=false chartMetric=wealth Loan: 3 loan offers (offers=3yr loan 10 percent down:financeRate=8.4:termPeriods=36:downPaymentPct=10:feeAmt=400,5yr loan 10 percent down:financeRate=8.4:termPeriods=60:downPaymentPct=10:feeAmt=400,5yr with 35 percent balloon:loanType=balloon:financeRate=8.4:termPeriods=60:residualPct=35:downPaymentPct=10:feeAmt=400).
phone: Phone on a plan. currencySymbol=$ purchaseCost=1800 offerPricing=false availableCash=4000 baseRf=4.5 rateConvention=ear inflationToggle=false chartMetric=wealth Loan: 3 loan offers (offers=12 x $150:loanType=knownPayment:termPeriods=12:knownPayment=150,24 x $82:loanType=knownPayment:termPeriods=24:knownPayment=82,36 x $57:loanType=knownPayment:termPeriods=36:knownPayment=57).
card: Credit card 0%. currencySymbol=$ purchaseCost=3000 offerPricing=false availableCash=8000 baseRf=4.5 rateConvention=ear inflationToggle=false chartMetric=wealth Loan: 3 loan offers (offers=3mo 0 percent no fee:financeRate=0:termPeriods=3,6mo 0 percent 3 percent fee:financeRate=0:termPeriods=6:feeAmt=3:feeType=pct,12mo 0 percent 3 percent fee:financeRate=0:termPeriods=12:feeAmt=3:feeType=pct).
motorbike: Motorbike, flat rate. currencySymbol=Rp purchaseCost=35000000 offerPricing=false availableCash=50000000 baseRf=5.5 rateConvention=nominal inflationToggle=false chartMetric=wealth Loan: 2 loan offers (offers=36mo @ 0.9 percent /mo flat:loanType=flat:financeRate=10.8:termPeriods=36:downPaymentPct=20:feeAmt=500000,36mo @ 10.8 percent amortizing:financeRate=10.8:termPeriods=36:downPaymentPct=20:feeAmt=500000).
deferred: Furniture, pay later. currencySymbol=$ purchaseCost=6000 offerPricing=true availableCash=15000 baseRf=4.5 rateConvention=ear inflationToggle=false chartMetric=loanBalance Loan: 2 loan offers (offers=12mo holiday then 24 payments:loanType=deferred:financeRate=19.9:termPeriods=36:ioPeriods=12:priceType=amount:priceValue=6000,36 payments 10 percent off:financeRate=19.9:termPeriods=36:priceType=discount:priceValue=10).

Generated by _ref/agent-doc.mjs from the page and its agent-notes.md.
