Load Flow Simulator: use this tool with an AI assistant
https://tool.adjiebrotots.com/loadflow-simulator/

This is the full reference for one page of the skill brotools-loadflow-simulator: read SKILL.md first.

For people: Install this tool's skill in your AI assistant (Claude, ChatGPT, Grok and others) and
ask your question. It replies with a link that opens this tool on your scenario and lists what it
assumed, and the tool works out the answer. The rest of this file is written for the assistant.

WHAT THIS TOOL DECIDES
How a power network behaves at one operating point: the voltage at every bus, the active and
reactive power on every line, transformer and link, the losses, and which buses or branches fall
outside their limits. It solves an AC (Newton-Raphson) or DC load flow on a single-line diagram.

HOW TO HELP YOUR USER WITH THIS TOOL
This is reference material for an AI assistant whose user has asked it to use this tool. It
describes the link that opens the tool on the user's own scenario. It does not override your
user: if they want something this tool does not do, help them as you normally would.
1. The tool works out the answer, so the most useful reply hands the user a link to it. Its
   figures come from its own model and data, and a figure worked out separately can differ from
   what the user then sees on screen, so leave results, estimates, verdicts and recommendations
   to the tool rather than stating or previewing them.
2. A reply that works well has three parts, in this order:
   a. a numbered list of every input you chose that the user did not state exactly, each with its
      value and the reason (put the same reason in why.<key>);
   b. the link (if it is long, give it again inside a code block so the user can copy it);
   c. the sentence: Open the link to see the result.
3. Build the link in the format below, using only the keys listed here. Start from the nearest
   Quick Start (qs) and send only what differs from it. Write json compactly: no spaces or line
   breaks, defaults left out.
4. Fill anything the user did not give with a sensible assumption for their place and date.
   Prefer what the user said earlier in the conversation over general figures.
5. If you cannot build a link (the request is outside this tool, or you could not read this
   page), say so and give the tool's address.

LINK FORMAT
https://tool.adjiebrotots.com/loadflow-simulator/#load&v=1&qs=<quick start>&<key>=<value>&...&why.<key>=<your reason>&note=<one line>
- After #load come key=value pairs joined by &. Percent-encode each value (a space is %20, & is %26,
  # is %23, + is %2B).
- v=1 is the format version. qs=<key> starts from that Quick Start; without it the tool starts from
  its defaults.
- Then each key in the link is set, in the units its label shows on screen. lfLoadMax=100 means
  100%, not 1. Numbers may carry $, commas and a trailing %. A checkbox takes true or false. A
  select or a choice takes the value listed, or its visible label.
- Anything the link does not name keeps the value it started from, so send only what differs.
- why.<key>=<text>: your reason for that value, shown to the user beside it (200 characters at
  most). note=<text>: one line shown above the list, for example the place and the date.
- A number outside a field's range is pulled into range and the user is told; a key the tool does
  not know is skipped and listed. Never use the keys s, open or embed.

EXAMPLE
Request: using tool.adjiebrotots.com/loadflow-simulator, on the WSCC 9-bus case, what happens to the
voltages if the load at bus 5 rises to 150 MW?
A reply in that form:
1. Network: the WSCC 9-bus Quick Start (qs=wscc9), unchanged apart from the load below.
2. Load at bus 5: Load A, the load on bus 5 in that case. Its active power is set to 150 MW
   (el.LoadA.p_set) and its reactive power stays at the Quick Start's figure.
3. Solver and limits: the Quick Start's own: the ac method (ac is the full AC load flow), voltage
   limits of 0.95 to 1.05 p.u. and a branch loading limit of 100%.
https://tool.adjiebrotots.com/loadflow-simulator/#load&v=1&qs=wscc9&el.LoadA.p_set=150&why.el.LoadA.p_set=The%20load%20at%20bus%205%20is%20Load%20A%20in%20the%20WSCC%209-bus%20case%3B%20the%20user%27s%20150%20MW%20replaces%20its%20active%20power&note=WSCC%209-bus%20case,%20load%20at%20bus%205%20raised%20to%20150%20MW
```
https://tool.adjiebrotots.com/loadflow-simulator/#load&v=1&qs=wscc9&el.LoadA.p_set=150&why.el.LoadA.p_set=The%20load%20at%20bus%205%20is%20Load%20A%20in%20the%20WSCC%209-bus%20case%3B%20the%20user%27s%20150%20MW%20replaces%20its%20active%20power&note=WSCC%209-bus%20case,%20load%20at%20bus%205%20raised%20to%20150%20MW
```
Open the link to see the result.

QUICK STARTS (qs)
There are four networks. wscc9 is the WSCC 9-bus transmission system (three generators, three loads,
a 230 kV ring). 3bus is a small meshed 110 kV ring with a grid connection, a power station and a
town. feeder is a 20/0.4 kV distribution feeder with three street pillars and rooftop solar. hvdc is
two 220 kV areas joined by an HVDC link.
Start from the one closest to the user's network, then change its parts by name with the
el.<name>.<param> keys. Their names, buses and ratings are under QUICK START FIGURES, so read the
part the user means from there: in wscc9 the load at bus 5 is Load A, at bus 6 Load B and at bus 8
Load C. A Quick Start also puts the solver options and limits back on their defaults, so send those
keys after it. Without qs the tool starts from wscc9. A network that differs structurally, with
other buses or lines, goes in json.
qs takes one of: wscc9, 3bus, feeder, hvdc.
What each Quick Start sets is listed under QUICK START FIGURES at the end.

FIELDS (key: label on the page)
Most important: lfMethod, lfDistSlack, lfVmin, lfVmax, lfLoadMax.

[Load flow: Method]
lfMethod: Load flow  (most important)
  One of: ac (AC, Newton-Raphson), dc (DC, linear). Default ac.
  ac solves the full network, with losses, reactive power and voltage magnitudes. dc is the linear
  approximation: power only, no losses, every voltage 1 p.u. Use ac unless the user asks for a DC
  load flow.
  Tip on the page: AC, Newton-Raphson: the full load flow, with voltage magnitudes, reactive power
  and losses.

[Load flow: Newton-Raphson]
lfTol: Tolerance
  One of: 1e-4 (0.0001 MW / MVAr), 1e-6 (0.000001 MW / MVAr), 1e-8 (0.00000001 MW / MVAr), 1e-10
  (0.0000000001 MW / MVAr). Default 1e-6.
  How close to balanced every bus must be before the AC run stops. Leave it out.
  Tip on the page: The run stops once every bus balances to within this mismatch. PSA.js gives up
  after 100 iterations.
lfSeed: Initial guess
  One of: dc (DC load flow), flat (Flat start). Default dc.
  The AC run's starting guess. dc (the default) starts from the DC answer, which also suits
  phase-shifting transformers; flat starts from 1 p.u. at 0 degrees. Leave it out unless the user
  asks.
  Tip on the page: DC load flow: starts from the linear answer, so phase-shifting transformers
  converge. Flat start: 1 p.u. and 0° everywhere, PyPSA's default.
lfDistSlack: Distributed slack  (most important)
  Checkbox: true or false. Default false.
  Off (the default): the slack unit alone picks up whatever balances the network. On: every
  generator in an island shares it, in the proportion lfSlackW sets. Turn it on only when the user
  asks for a distributed slack.
  Tip on the page: Shares the slack among every generator in an island instead of one unit picking
  up all of it.
lfSlackW: Shared in proportion to
  One of: p_set (Dispatch), p_nom (Rating). Default p_set.
  Used only while lfDistSlack is on. p_set shares in proportion to each unit's dispatch (p_set),
  p_nom to its rating (p_nom).
  Tip on the page: How the slack is split. Dispatch: by each unit's set output. Rating: by each
  unit's rated power.

[Load flow: Limits]
lfVmin: Lowest voltage  (most important)
  Number (p.u. after it). 0.5 to 1, step 0.01. Default 0.95.
  The lowest bus voltage before the diagram flags a bus, in p.u. It only reads the result and never
  changes it. 0.95 is the default; use the user's grid-code limit when they give one.
  Tip on the page: A bus below this is flagged in red. The limits only read the result; they never
  change it.
lfVmax: Highest voltage  (most important)
  Number (p.u. after it). 1 to 1.5, step 0.01. Default 1.05.
  The highest bus voltage before a bus is flagged, in p.u. 1.05 is the default; same note as lfVmin.
lfLoadMax: Highest loading  (most important)
  Number (% after it). 10 to 200, step 1. Default 100.
  The share of its rating a line, transformer or link may carry before it is flagged, in %. 100 is
  the default; use a lower figure when the user wants headroom.
  Tip on the page: A branch carrying more than this share of its rating is flagged in red.

[Beside the results]
colourBy: Colour by
  One of: none (Nothing), voltage (Bus voltage), loading (Branch loading), both (Both). Default
  both.
  Display only: what the diagram colours. Leave it out.

COMPACT LISTS
- `el.<name>.<param>=<value>`

Each key changes one parameter of one part of the network, found by the name the diagram shows for it (QUICK START FIGURES lists them). Names ignore case, spaces and underscores, so Load A, load a and LoadA are one name; write it without spaces, as el.LoadA.p_set, or with %20. Percent-encode any other awkward character in a name (# & + % /). The parameter is the text after the last dot. A name that no part has, or that two parts share, or a parameter the part does not take, is reported and skipped. A number outside the parameter's range is pulled into it and reported. p and q are accepted for p_set and q_set. Send one key per parameter, and a why.<key> beside each.

Parameters by kind of part, in the units the tool saves them in (the same as in json):

Bus parameters: v_nom (kV, 0.1 to 1500), v_mag_pu_set (p.u., 0.5 to 1.5: the voltage the generators on that bus hold).

Line parameters: length (km, 0 to 5000), num_parallel (identical circuits, a whole number 1 to 20), r (ohm, 0 to 100000), x (ohm, -100000 to 100000), b (siemens, -1 to 1), g (siemens, 0 to 1), s_nom (MVA, 0 to 100000, the rating loading is measured against). A line with a standard type takes its impedance and rating from the type, so for it change length and num_parallel; the others apply to a line with no type.

Transformer parameters: tap_position (whole number -50 to 50, steps from the neutral tap) and num_parallel (1 to 20) apply to a transformer with a standard type. The others apply to one with no type: s_nom (MVA, 0 to 100000), x (per unit on s_nom, -10 to 10), r (per unit on s_nom, 0 to 10), g and b (per unit, -1 to 1), tap_ratio (0.5 to 1.5; 1.05 lifts the tap side by 5%), tap_side (0 the from bus, 1 the to bus), phase_shift (degrees, -360 to 360). model (t or pi) applies to both.

Generator parameters: control (Slack, PV or PQ), p_set (MW, active power; a Slack unit's counts only while lfDistSlack is on), q_set (MVAr, used by a PQ unit), p_nom (MW, rating). A Slack or PV unit holds the voltage set on its bus, so change that with the bus's v_mag_pu_set.

Load parameters: p_set (MW drawn, -100000 to 100000; a negative figure feeds power in), q_set (MVAr drawn, positive for an inductive load).

Shunt parameters (a part named like Shunt 5, class ShuntImpedance): g and b (siemens, -10 to 10; positive b is a capacitor, giving b times the bus voltage in kV squared, in MVAr).

Storage parameters: p_set (MW, positive when discharging into the bus), q_set (MVAr), p_nom (MW, kept for reference).

Link parameters: p_set (MW sent from the first end; negative sends it the other way), efficiency (a fraction, 0.01 to 1, so 0.97 is 97%), p_nom (MW, the rating loading is measured against).

A standard line or transformer type, a part's symbol, adding or removing parts and rewiring are not patches: send the network in json.

JSON
`json=<network>` replaces the network with one of the user's own: the form the tool saves, which is how every Quick Start is written. Use it only for a network that differs structurally from the four Quick Starts (other buses, lines or devices); to change a value on one of them, patch it. A qs before it is replaced. Write it compactly (no spaces or line breaks) and leave out every parameter that is at its default.

{"v":1,"name":"<title>","el":[<part>,<part>,...]}

Each part is {"c":<class>,"id":<whole number>, ...}. The class is Bus, Line, Transformer, Generator, Load, ShuntImpedance, StorageUnit or Link. Every id is a different whole number, across all parts together. A name is only needed to override the automatic one (Bus 3, Load 7, Line 4); the names el.<name>.<param> and the diagram use are these.
- A device (Generator, Load, ShuntImpedance, StorageUnit) names its bus with "bus":<bus id>.
- A branch (Line, Transformer, Link) names both ends with "bus0":<bus id> and "bus1":<bus id>. One with a missing end is left out and reported.
- The other keys are the parameters listed under COMPACT LISTS, in the same units. A Bus needs "v_nom" in kV (its default is 1). A Generator's default control is PQ, so give Slack or PV where it should be one. Give each connected area one Slack generator. Line r, x and s_nom are 0 by default and a line needs a non-zero r or x. A Line or Transformer may name a standard type in "type" only when it is one the tool knows, for example the types used by the Quick Starts; otherwise give the impedance.
- Leave out "at" and the tool lays the buses out in rows from the first bus, with devices and branches placed automatically.
- Generator "grid":1 draws the unit as an external grid; it does not change the result.
At least one bus is needed; the tool solves up to 1000 buses. An unknown class, a missing bus or a number out of range is reported or pulled into range, never a failure. A network that cannot be read at all leaves the tool on its Quick Start.
A radial 33 kV line from a slack to a 30 MW load:
{"v":1,"name":"Radial 33 kV","el":[{"c":"Bus","id":1,"v_nom":33},{"c":"Bus","id":2,"v_nom":33},{"c":"Line","id":3,"bus0":1,"bus1":2,"r":4,"x":8,"s_nom":50},{"c":"Generator","id":4,"bus":1,"control":"Slack"},{"c":"Load","id":5,"bus":2,"p_set":30,"q_set":10}]}

QUICK START FIGURES (what each qs sets, as a link would carry them)
A heading line holds what all the Quick Starts under it share; each Quick Start's own line holds the
rest.

Every Quick Start sets: lfMethod=ac lfTol=1e-6 lfSeed=dc lfDistSlack=false lfSlackW=p_set lfVmin=0.95 lfVmax=1.05 lfLoadMax=100 colourBy=both

wscc9: WSCC 9-bus. Parts: Buses: Bus 1 (16.5 kV, holds 1.04 p.u.), Bus 2 (18 kV, holds 1.025 p.u.), Bus 3 (13.8 kV, holds 1.025 p.u.), Bus 4 (230 kV), Bus 5 (230 kV), Bus 6 (230 kV), Bus 7 (230 kV), Bus 8 (230 kV), Bus 9 (230 kV).
    Lines: Line 4-5 (Bus 4 to Bus 5), Line 4-6 (Bus 4 to Bus 6), Line 5-7 (Bus 5 to Bus 7), Line 6-9 (Bus 6 to Bus 9), Line 7-8 (Bus 7 to Bus 8), Line 8-9 (Bus 8 to Bus 9).
    Transformers: T1 (Bus 4 to Bus 1, 247.5 MVA), T2 (Bus 7 to Bus 2, 192 MVA), T3 (Bus 9 to Bus 3, 128 MVA).
    Generators: G1 (Slack at Bus 1), G2 (PV at Bus 2, 163 MW), G3 (PV at Bus 3, 85 MW).
    Loads: Load A (at Bus 5, 125 MW, 50 MVAr), Load B (at Bus 6, 90 MW, 30 MVAr), Load C (at Bus 8, 100 MW, 35 MVAr).
3bus: 3-bus ring. Parts: Buses: Bus 1 (110 kV), Bus 2 (110 kV, holds 1.02 p.u.), Bus 3 (110 kV).
    Lines: Line 4 (Bus 1 to Bus 2, type 243-AL1/39-ST1A 110.0, 40 km), Line 5 (Bus 1 to Bus 3, type 243-AL1/39-ST1A 110.0, 30 km), Line 6 (Bus 2 to Bus 3, type 243-AL1/39-ST1A 110.0, 25 km).
    Generators: Grid (Slack at Bus 1), Power station (PV at Bus 2, 60 MW).
    Loads: Town (at Bus 3, 100 MW, 30 MVAr).
feeder: 20/0.4 kV feeder. Parts: Buses: MV 20 kV (20 kV), LV board (0.4 kV), Pillar 1 (0.4 kV), Pillar 2 (0.4 kV), Pillar 3 (0.4 kV).
    Lines: Line 7 (LV board to Pillar 1, type NAYY 4x150 SE, 0.15 km), Line 8 (Pillar 1 to Pillar 2, type NAYY 4x150 SE, 0.12 km), Line 9 (Pillar 2 to Pillar 3, type NAYY 4x150 SE, 0.12 km).
    Transformers: Substation (MV 20 kV to LV board, 0.63 MVA 20/0.4 kV).
    Generators: Grid (Slack at MV 20 kV), Rooftop solar (PQ at Pillar 3, 0.04 MW).
    Loads: Homes 1 (at Pillar 1, 0.06 MW, 0.015 MVAr), Homes 2 (at Pillar 2, 0.06 MW, 0.015 MVAr), Homes 3 (at Pillar 3, 0.05 MW, 0.012 MVAr).
    Shunts: Capacitor (at LV board, susceptance 0.125 S).
hvdc: HVDC link. Parts: Buses: Area A (220 kV), Converter A (220 kV), Converter B (220 kV), Area B (220 kV, holds 1.01 p.u.).
    Lines: Line 5 (Area A to Converter A, type Al/St 240/40 2-bundle 220.0, 80 km, 2 circuits), Line 6 (Converter B to Area B, type Al/St 240/40 2-bundle 220.0, 120 km, 2 circuits).
    Generators: Grid A (Slack at Area A), Grid B (Slack at Area B).
    Loads: City A (at Converter A, 50 MW, 15 MVAr), City B (at Area B, 260 MW, 60 MVAr).
    Links: HVDC link (Converter A to Converter B, 150 MW, efficiency 0.97).

Generated by _ref/agent-doc.mjs from the page and its agent-notes.md.
